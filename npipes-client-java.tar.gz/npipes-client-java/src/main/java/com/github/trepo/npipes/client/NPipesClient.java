package com.github.trepo.npipes.client;

import com.github.trepo.npipes.Query;
import com.github.trepo.npipes.Status;
import com.github.trepo.npipes.Step;
import com.github.trepo.npipes.Traversal;
import com.github.trepo.npipes.gson.StepTypeAdapter;
import com.github.trepo.vgraph.VGraph;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.mashape.unirest.http.HttpResponse;
import com.mashape.unirest.http.Unirest;
import com.mashape.unirest.http.exceptions.UnirestException;

import java.util.HashMap;

/**
 * @author John Clark.
 */
public class NPipesClient {

    private static final Gson gson = new GsonBuilder()
            .registerTypeHierarchyAdapter(Step.class, new StepTypeAdapter())
            .setPrettyPrinting()
            .create();

    private int maxLoops = 5;

    public NPipesClient() {

    }

    public NPipesClient(int loopTimeout) {
        maxLoops = loopTimeout;
    }

    public void execute(Query query, VGraph graph) {
        boolean complete = false;
        int loops = 0;
        Query externalQuery;

        while (!complete) {

            // Increment Loops
            loops++;

            // Complete starts as true, and is set to false if we execute anything
            complete = true;

            // If we have exceeded our maximum loop count, timeout all remaining traversals
            if (loops > maxLoops) {
                for (Traversal traversal: query.getTraversals().values()) {
                    if (traversal.getStatus() == Status.RUNNING ||
                            traversal.getStatus().getFamily() == Status.Family.REDIRECTION) {
                        traversal.setStatus(Status.TIMEOUT);
                    }
                }
            }

            // Check if there are traversals to execute locally
            for (Traversal traversal: query.getTraversals().values()) {
                if (traversal.getStatus() == Status.RUNNING) {
                    complete = false;
                }
            }

            // If we have local traversals, execute them
            if (!complete) {
                executeLocalQuery(query, graph);
            }

            // Scan for and group up external requests
            HashMap<String, Query> outstandingQueries = new HashMap<>();
            for (Traversal traversal: query.getTraversals().values()) {
                if (traversal.getStatus().getFamily() == Status.Family.REDIRECTION) {
                    String repo = traversal.getPath().get(traversal.getPath().size()-1).getRepo();
                    if (!outstandingQueries.containsKey(repo)) {
                        outstandingQueries.put(repo, new Query());
                    }
                    traversal.setStatus(Status.RUNNING); // Restart traversal in external repo
                    outstandingQueries.get(repo).addTraversal(traversal);
                    complete = false;
                }
            }

            // Make external requests
            if (!outstandingQueries.isEmpty()) {

                for (String repo: outstandingQueries.keySet()) {
                    externalQuery = executeRemoteQuery(outstandingQueries.get(repo), repo);

                    // Merge requests back in
                    for (Traversal traversal: externalQuery.getTraversals().values()) {
                        // TODO If redirection to this repository, change from redirection to running
                        query.addTraversal(traversal);
                    }
                }
            }
        }
    }

    private Query executeLocalQuery(Query query, VGraph graph) {
        query.execute(graph);
        return query;
    }

    private Query executeRemoteQuery(Query query, String repository) {

        try {
            HttpResponse<String> response = Unirest.post(repository + "/npipes/query")
                    .header("Content-Type", "application/json")
                    .body(gson.toJson(query))
                    .asString();

            //System.out.println(response.getBody());

            Query returnedQuery = gson.fromJson(response.getBody(), Query.class);

            for (Traversal returnedTraversal: returnedQuery.getTraversals().values()) {
                query.addTraversal(returnedTraversal);
            }

        } catch (UnirestException e) {
            e.printStackTrace();

            for (Traversal traversal: query.getTraversals().values()) {
                traversal.setStatus(Status.REMOTE_ERROR);
            }
        }

        return query;
    }
}

# vGraph API
The JAVA API Interfaces for [vGraph](https://github.com/trepo/vgraph). For an actual implementation see [vgraph-java](https://github.com/trepo/vgraph-java).

# Maven
Hosted on [Maven Central](http://search.maven.org/#search%7Cga%7C1%7Ca%3A%22vgraph%22).

````xml
<dependency>
  <groupId>com.github.trepo</groupId>
  <artifactId>vgraph-api</artifactId>
  <version>0.2.0</version>
</dependency>
````

# Javadoc
Viewable online [here](http://www.javadoc.io/doc/com.github.trepo/vgraph-api). Many thanks to [javadoc.io](http://www.javadoc.io) for the hosting.

# Tests
There is comprehensive unit tests available by running `mvn test`.

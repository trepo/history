package com.github.trepo.vgraph;

/**
 * @author John Clark.
 */
public class LogEntry {

    /**
     * The Commit ID.
     */
    private String id;

    /**
     * When this Commit was created.
     */
    private Long timestamp;

    /**
     * The author of this Commit.
     */
    private String author;

    /**
     * The author's email address.
     */
    private String email;

    /**
     * The Commit message.
     */
    private String message;

    /**
     * Get the Commit's ID.
     * @return The Commit's ID.
     */
    public String getId() {
        return id;
    }

    /**
     * Set the Commit's ID.
     * @param commitId The ID.
     * @return This LogEntry.
     */
    public LogEntry setId(String commitId) {
        id = commitId;
        return this;
    }

    /**
     * Get the Commit's Timestamp.
     * @return The Commit's Timestamp.
     */
    public Long getTimestamp() {
        return timestamp;
    }

    /**
     * Set the Commit's timestamp.
     * @param commitTimestamp The timestamp.
     * @return This LogEntry.
     */
    public LogEntry setTimestamp(Long commitTimestamp) {
        timestamp = commitTimestamp;
        return this;
    }

    /**
     * Get the Commit's author.
     * @return The Commit's author.
     */
    public String getAuthor() {
        return author;
    }

    /**
     * Set the Commit's author.
     * @param commitAuthor The author.
     * @return This LogEntry.
     */
    public LogEntry setAuthor(String commitAuthor) {
        author = commitAuthor;
        return this;
    }

    /**
     * Get the Commit's email.
     * @return The Commit's email.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set the Commit's email.
     * @param commitEmail The email.
     * @return This LogEntry.
     */
    public LogEntry setEmail(String commitEmail) {
        email = commitEmail;
        return this;
    }

    /**
     * Get the Commit's message.
     * @return The Commit's message.
     */
    public String getMessage() {
        return message;
    }

    /**
     * Set the Commit's message.
     * @param commitMessage The message.
     * @return This LogEntry.
     */
    public LogEntry setMessage(String commitMessage) {
        message = commitMessage;
        return this;
    }
}

package com.github.trepo.vgraph;

import com.google.gson.Gson;
import org.apache.commons.codec.digest.DigestUtils;

import java.util.Date;
import java.util.Map;
import java.util.TreeMap;
import java.util.UUID;
import java.util.regex.Pattern;

/**
 * @author John Clark.
 */
public final class SpecialProperty {
    /**
     * The key for an ID.
     */
    public static final String ID = "__id";

    /**
     * The key for a label.
     */
    public static final String LABEL = "__label";

    /**
     * The regex pattern for a label value.
     */
    public static final Pattern LABEL_PATTERN = Pattern.compile("[A-Za-z][A-Za-z_]{0,254}");

    /**
     * The key for a hash.
     */
    public static final String HASH = "__hash";

    /**
     * The key for a repo.
     */
    public static final String REPO = "__repo";

    /**
     * The regex pattern for a repo value.
     */
    public static final Pattern REPO_PATTERN = Pattern.compile("[\\S]{1,255}");

    /**
     * The key for deleted.
     */
    public static final String DELETED = "__deleted";

    /**
     * The key for the original properties.
     */
    public static final String ORIGINAL = "__original";

    /**
     * For serialization.
     */
    private static final Gson GSON = new Gson();

    /**
     * Private Constructor to prevent instantiation.
     */
    private SpecialProperty() {
        // Never called.
    }

    /**
     * Generate a new ID.
     * @return A new UUIDv4.
     */
    public static String generateId() {
        return UUID.randomUUID().toString();
    }

    /**
     * Validates an id.
     * @param id The id to validate.
     * @return True if the id is valid, false otherwise.
     */
    public static boolean isValidId(String id) {
        if (id == null) {
            return false;
        }
        try {
            UUID uuid = UUID.fromString(id);
            if (uuid.version() != 4) {
                return false;
            }
        } catch (IllegalArgumentException e) {
            return false;
        }
        return true;
    }

    /**
     * Validates a label.
     * @param label The label to validate.
     * @return True if the label is valid, false otherwise.
     */
    public static boolean isValidLabel(String label) {
        return label != null && LABEL_PATTERN.matcher(label).matches();
    }

    /**
     * Validates a repo.
     * @param repo The repo to validate.
     * @return True if the label is valid, false otherwise.
     */
    public static boolean isValidRepo(String repo) {
        return repo != null && REPO_PATTERN.matcher(repo).matches();
    }

    /**
     * Get the current timestamp.
     * @return The current timestamp.
     */
    public static long generateTimestamp() {
        return new Date().getTime();
    }

    /**
     * Calculate the SHA-1 hash of the ordered json output of an elements regular properties.
     * @param properties The properties to be used to calculate the hash.
     * @return The SHA-1 hash of the regular properties string.
     */
    public static String calculateHash(Map<String, Object> properties) {
        // We use a TreeMap to enforce order.
        Map<String, Object> obj = new TreeMap<>();

        // Loop through the keys and add the regular keys to the final object
        for (Map.Entry<String, Object> entry: properties.entrySet()) {
            obj.put(entry.getKey(), entry.getValue());
        }

        return DigestUtils.sha1Hex(GSON.toJson(obj));
    }
}

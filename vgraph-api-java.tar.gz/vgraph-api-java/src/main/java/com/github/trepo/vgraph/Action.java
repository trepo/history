package com.github.trepo.vgraph;

/**
 * @author John Clark.
 */
public final class Action {

    /**
     * The string representing create in a commit.
     */
    public static final String CREATE = "create";

    /**
     * The string representing create in a commit.
     */
    public static final String UPDATE = "update";

    /**
     * The string representing delete in a commit.
     */
    public static final String DELETE = "delete";

    /**
     * Private Constructor to prevent instantiation.
     */
    private Action() {
        // Never called.
    }

    /**
     * Validates an action.
     * @param action The action to validate.
     * @return True if the action is valid, false otherwise.
     */
    public static boolean isValidAction(String action) {
        return action != null && (action.equals(CREATE) || action.equals(UPDATE) || action.equals(DELETE));
    }
}

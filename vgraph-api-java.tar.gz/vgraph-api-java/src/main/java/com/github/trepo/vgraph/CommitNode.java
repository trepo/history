package com.github.trepo.vgraph;

import java.util.Map;

/**
 * @author John Clark.
 */
public class CommitNode {

    /**
     * The Node's ID.
     */
    private String id;

    /**
     * The Node's Label.
     */
    private String label;

    /**
     * The Action to apply.
     */
    private String action;

    /**
     * If this Node is a Boundary.
     */
    private Boolean boundary;

    /**
     * This Node's Repository.
     */
    private String repo;

    /**
     * The Node's Hash.
     */
    private String hash;

    /**
     * This Node's Original Properties.
     */
    private Map<String, Object> original;

    /**
     * This Node's Properties.
     */
    private Map<String, Object> properties;

    /**
     * Get the Node's ID.
     * @return The Node's ID
     */
    public String getId() {
        return id;
    }

    /**
     * Set the Node's ID.
     * @param nodeId The ID.
     * @return This CommitNode.
     */
    public CommitNode setId(String nodeId) {
        id = nodeId;
        return this;
    }

    /**
     * Get the Node's label.
     * @return The Node's label.
     */
    public String getLabel() {
        return label;
    }

    /**
     * Set the Node's label.
     * @param nodeLabel The label.
     * @return This CommitNode.
     */
    public CommitNode setLabel(String nodeLabel) {
        label = nodeLabel;
        return this;
    }

    /**
     * Get the CommitNode's action.
     * @return The commitNode's action.
     */
    public String getAction() {
        return action;
    }

    /**
     * Set the CommitNode's action.
     * @param nodeAction The action.
     * @return This CommitNode.
     */
    public CommitNode setAction(String nodeAction) {
        action = nodeAction;
        return this;
    }

    /**
     * Get whether or not the CommitNode is a boundary.
     * @return True if the CommitNode is a boundary.
     */
    public Boolean isBoundary() {
        return boundary;
    }

    /**
     * Set the Node's boundary.
     * @param nodeBoundary The boundary.
     * @return This CommitNode.
     */
    public CommitNode setBoundary(Boolean nodeBoundary) {
        boundary = nodeBoundary;
        return this;
    }

    /**
     * Get the Node's repository identifier.
     * @return The Node's repository identifier.
     */
    public String getRepo() {
        return repo;
    }

    /**
     * Set the Node's repo.
     * @param nodeRepo The repo.
     * @return This CommitNode.
     */
    public CommitNode setRepo(String nodeRepo) {
        repo = nodeRepo;
        return this;
    }

    /**
     * Get the Node's Hash.
     * @return The Node's Hash.
     */
    public String getHash() {
        return hash;
    }

    /**
     * Set the Node's Hash.
     * @param nodeHash The hash.
     * @return This CommitNode.
     */
    public CommitNode setHash(String nodeHash) {
        hash = nodeHash;
        return this;
    }

    /**
     * Get the Node's original properties.
     * @return The Node's original properties.
     */
    public Map<String, Object> getOriginal() {
        return original;
    }

    /**
     * Set the Node's original properties.
     * @param nodeOriginal The Node's original properties.
     * @return This CommitNode.
     */
    public CommitNode setOriginal(Map<String, Object> nodeOriginal) {
        original = nodeOriginal;
        return this;
    }

    /**
     * Get the Node's properties.
     * @return The Node's properties.
     */
    public Map<String, Object> getProperties() {
        return properties;
    }

    /**
     * Set the Node's properties.
     * @param nodeProperties The Node's properties.
     * @return This CommitNode.
     */
    public CommitNode setProperties(Map<String, Object> nodeProperties) {
        properties = nodeProperties;
        return this;
    }

    /**
     * Validate this CommitNode.
     */
    public void validate() {

        // id
        if (id == null) {
            throw new VGraphException("id is null");
        }
        if (!SpecialProperty.isValidId(id)) {
            throw new VGraphException("id is invalid");
        }

        // label
        if (label == null) {
            throw new VGraphException("label is null");
        }
        if (!SpecialProperty.isValidLabel(label)) {
            throw new VGraphException("label is invalid");
        }

        // action
        if (action == null) {
            throw new VGraphException("action is null");
        }
        if (!Action.isValidAction(action)) {
            throw new VGraphException("action is invalid");
        }

        // boundary
        if (boundary == null) {
            throw new VGraphException("boundary is null");
        }

        // repo
        if (boundary) {
            if (repo == null) {
                throw new VGraphException("repo is not set for a boundary node");
            }
        } else {
            if (repo != null) {
                throw new VGraphException("repo is set for a non-boundary node");
            }
        }

        // original
        if (boundary) {
            if (original != null) {
                throw new VGraphException("original is set for a boundary node");
            }
        } else {
            if (action.equals(Action.CREATE)) {
                if (original != null) {
                    throw new VGraphException("original is set when action is create");
                }
            } else {
                if (original == null) {
                    throw new VGraphException("original is null");
                }
                for (Map.Entry<String, Object> entry: original.entrySet()) {
                    if (!Property.isValidKey(entry.getKey())) {
                        throw new VGraphException("original contains an invalid key: " + entry.getKey());
                    }
                    if (!Property.isValidValue(entry.getValue())) {
                        throw new VGraphException("original contains an invalid value for key: " + entry.getKey());
                    }
                }
            }
        }

        // properties
        if (boundary) {
            if (properties != null) {
                throw new VGraphException("properties is set for a boundary node");
            }
        } else {
            if (action.equals(Action.DELETE)) {
                if (properties != null) {
                    throw new VGraphException("properties is set when action is delete");
                }
            } else {
                if (properties == null) {
                    throw new VGraphException("properties is null");
                }
                for (Map.Entry<String, Object> entry: properties.entrySet()) {
                    if (!Property.isValidKey(entry.getKey())) {
                        throw new VGraphException("properties contains an invalid key: " + entry.getKey());
                    }
                    if (!Property.isValidValue(entry.getValue())) {
                        throw new VGraphException("properties contains an invalid value for key: " + entry.getKey());
                    }
                }
            }
        }

        // hash
        if (boundary) {
            if (hash != null) {
                throw new VGraphException("hash is set for a boundary node");
            }
        } else {
            if (action.equals(Action.DELETE)) {
                if (hash != null) {
                    throw new VGraphException("hash is set when action is delete");
                }
            } else {
                if (hash == null) {
                    throw new VGraphException("hash is null");
                }
                if (!hash.equals(SpecialProperty.calculateHash(properties))) {
                    throw new VGraphException("hash is invalid");
                }
            }
        }
    }


    /**
     * CommitNodes are equal if they have the same ID regardless of the action.
     * @param o The object to compare to this object.
     * @return True if this and the passed in object are the same.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CommitNode that = (CommitNode) o;

        if (id == null) {
            return super.equals(that);
        } else {
            return id.equals(that.id);
        }

    }

    /**
     * The HashCode for this object is the id's HashCode.
     * @return The ID's HashCode.
     */
    @Override
    public int hashCode() {
        if (id == null) {
            return super.hashCode();
        } else {
            return id.hashCode();
        }
    }
}

package com.github.trepo.vgraph;

import java.util.Map;

/**
 * @author John Clark.
 */
public class CommitEdge {

    /**
     * The Edge's ID.
     */
    private String id;

    /**
     * The Edge's Label.
     */
    private String label;

    /**
     * The Edge's From Node.
     */
    private String from;

    /**
     * The Edge's To Node.
     */
    private String to;

    /**
     * The Action to apply.
     */
    private String action;

    /**
     * The Edge's Hash.
     */
    private String hash;

    /**
     * This Edge's Original Properties.
     */
    private Map<String, Object> original;

    /**
     * This Edge's Properties.
     */
    private Map<String, Object> properties;

    /**
     * Get the Edge's ID.
     * @return The Edge's ID
     */
    public String getId() {
        return id;
    }

    /**
     * Set the Edge's ID.
     * @param edgeId The ID.
     * @return This CommitEdge.
     */
    public CommitEdge setId(String edgeId) {
        id = edgeId;
        return this;
    }

    /**
     * Get the Edge's label.
     * @return The Edge's label.
     */
    public String getLabel() {
        return label;
    }

    /**
     * Set the Edge's label.
     * @param edgeLabel The label.
     * @return This CommitEdge.
     */
    public CommitEdge setLabel(String edgeLabel) {
        label = edgeLabel;
        return this;
    }

    /**
     * Get the Edge's from node.
     * @return The Edge's from.
     */
    public String getFrom() {
        return from;
    }

    /**
     * Set the Edge's from node.
     * @param edgeFrom The from.
     * @return This CommitEdge.
     */
    public CommitEdge setFrom(String edgeFrom) {
        from = edgeFrom;
        return this;
    }

    /**
     * Get the Edge's to node.
     * @return The Edge's to.
     */
    public String getTo() {
        return to;
    }

    /**
     * Set the Edge's to node.
     * @param edgeTo The to.
     * @return This CommitEdge.
     */
    public CommitEdge setTo(String edgeTo) {
        to = edgeTo;
        return this;
    }

    /**
     * Get the CommitEdge's action.
     * @return The CommitEdge's action.
     */
    public String getAction() {
        return action;
    }

    /**
     * Set the CommitEdge's action.
     * @param edgeAction The action.
     * @return This CommitEdge.
     */
    public CommitEdge setAction(String edgeAction) {
        action = edgeAction;
        return this;
    }

    /**
     * Get the Edge's Hash.
     * @return The Edge's Hash.
     */
    public String getHash() {
        return hash;
    }

    /**
     * Set the Edge's Hash.
     * @param edgeHash The hash.
     * @return This CommitEdge.
     */
    public CommitEdge setHash(String edgeHash) {
        hash = edgeHash;
        return this;
    }

    /**
     * Get the Edge's original properties.
     * @return The Edge's original properties.
     */
    public Map<String, Object> getOriginal() {
        return original;
    }

    /**
     * Set the Edge's original properties.
     * @param edgeOriginal The Edge's original properties.
     * @return This CommitEdge.
     */
    public CommitEdge setOriginal(Map<String, Object> edgeOriginal) {
        original = edgeOriginal;
        return this;
    }

    /**
     * Get the Edge's properties.
     * @return The Edge's properties.
     */
    public Map<String, Object> getProperties() {
        return properties;
    }

    /**
     * Set the Edge's properties.
     * @param edgeProperties The Edge's properties.
     * @return This CommitEdge.
     */
    public CommitEdge setProperties(Map<String, Object> edgeProperties) {
        properties = edgeProperties;
        return this;
    }

    /**
     * Validate this CommitEdge.
     */
    public void validate() {

        // id
        if (id == null) {
            throw new VGraphException("id is null");
        }
        if (!SpecialProperty.isValidId(id)) {
            throw new VGraphException("id is invalid");
        }

        // label
        if (label == null) {
            throw new VGraphException("label is null");
        }
        if (!SpecialProperty.isValidLabel(label)) {
            throw new VGraphException("label is invalid");
        }

        // from
        if (from == null) {
            throw new VGraphException("from is null");
        }
        if (!SpecialProperty.isValidId(from)) {
            throw new VGraphException("from is invalid");
        }

        // to
        if (to == null) {
            throw new VGraphException("to is null");
        }
        if (!SpecialProperty.isValidId(to)) {
            throw new VGraphException("to is invalid");
        }

        // action
        if (action == null) {
            throw new VGraphException("action is null");
        }
        if (!Action.isValidAction(action)) {
            throw new VGraphException("action is invalid");
        }

        // original
        if (action.equals(Action.CREATE)) {
            if (original != null) {
                throw new VGraphException("original is set when action is create");
            }
        } else {
            if (original == null) {
                throw new VGraphException("original is null");
            }
            for (Map.Entry<String, Object> entry: original.entrySet()) {
                if (!Property.isValidKey(entry.getKey())) {
                    throw new VGraphException("original contains an invalid key: " + entry.getKey());
                }
                if (!Property.isValidValue(entry.getValue())) {
                    throw new VGraphException("original contains an invalid value for key: " + entry.getKey());
                }
            }
        }

        // properties
        if (action.equals(Action.DELETE)) {
            if (properties != null) {
                throw new VGraphException("properties is set when action is delete");
            }
        } else {
            if (properties == null) {
                throw new VGraphException("properties is null");
            }
            for (Map.Entry<String, Object> entry: properties.entrySet()) {
                if (!Property.isValidKey(entry.getKey())) {
                    throw new VGraphException("properties contains an invalid key: " + entry.getKey());
                }
                if (!Property.isValidValue(entry.getValue())) {
                    throw new VGraphException("properties contains an invalid value for key: " + entry.getKey());
                }
            }
        }

        // hash
        if (action.equals(Action.DELETE)) {
            if (hash != null) {
                throw new VGraphException("hash is set when action is delete");
            }
        } else {
            if (hash == null) {
                throw new VGraphException("hash is null");
            }
            if (!hash.equals(SpecialProperty.calculateHash(properties))) {
                throw new VGraphException("hash is invalid");
            }
        }
    }

    /**
     * CommitEdges are equal if they have the same ID regardless of the action.
     * @param o The object to compare to this object.
     * @return True if this and the passed in object are the same.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        CommitEdge that = (CommitEdge) o;

        if (id == null) {
            return super.equals(that);
        } else {
            return id.equals(that.id);
        }

    }

    /**
     * The HashCode for this object is the id's HashCode.
     * @return The ID's HashCode.
     */
    @Override
    public int hashCode() {
        if (id == null) {
            return super.hashCode();
        } else {
            return id.hashCode();
        }
    }
}

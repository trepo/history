package com.github.trepo.vgraph;

import java.util.List;

/**
 * A versioned property graph.
 * @author John Clark.
 */
public interface VGraph {

    /**
     * Add a new Node to the Graph.
     * @param label The node's label.
     * @return The added node.
     */
    Node addNode(String label);

    /**
     * Mark a node as deleted.
     * @param id The ID of the node.
     */
    void removeNode(String id);

    /**
     * Get a Node from the graph.
     * @param id The ID of the node.
     * @return The node (which may be a boundary), or null if no node exists.
     */
    Node getNode(String id);

    /**
     * Gets an Iterable for all of the nodes in the graph.
     * @return An Iterable.
     */
    Iterable<Node> getNodes();

    /**
     * Gets all nodes that contain a particular key/value combination.
     * @param key The regular key.
     * @param value The value.
     * @return A filtered Iterable for all of the nodes in the graph.
     */
    Iterable<Node> getNodes(String key, Object value);

    /**
     * Adds an Edge to the Graph.
     * @param from The Node the edge goes from.
     * @param to The Node the edge goes to.
     * @param label The label on the Edge.
     * @return The added Edge.
     */
    Edge addEdge(Node from, Node to, String label);

    /**
     * Marks an edge as deleted.
     * @param id The ID to delete.
     */
    void removeEdge(String id);

    /**
     * Gets an edge from the graph.
     * @param id The Edge's ID.
     * @return The edge, or null if not found.
     */
    Edge getEdge(String id);

    /**
     * Gets an Iterable for all of the edges in the graph.
     * @return An Iterable for all of the edges in the graph
     */
    Iterable<Edge> getEdges();

    /**
     * Gets an Iterable for all of the edges in the graph filtered by key and value.
     * @param key The key to filter on.
     * @param value The value to filter on.
     * @return An Iterable for all of the nodes matching key/value in the graph.
     */
    Iterable<Edge> getEdges(String key, Object value);

    /**
     * Gets information about the graph.
     * @return Info.
     */
    Info info();

    /**
     * Gets N log entries starting at offset.
     * @param number The number of entries to return.
     * @param offset The number of commits to skip.
     * @return A List of log entries.
     */
    List<LogEntry> log(Integer number, Integer offset);

    /**
     * Gets the status of vGraph.
     * @return The Status.
     */
    Commit status();

    /**
     * Undo all non-committed changes.
     */
    void reset();

    /**
     * Create a Commit.
     * @param author The Committer's author.
     * @param email The Committer's email.
     * @param message A message to associate with this commit.
     * @return The commit object.
     */
    Commit commit(String author, String email, String message);

    /**
     * Undo any changes back to the referenced commit.
     * @param id The ID of the Commit.
     * @return A list of Commit IDs that were undone.
     */
    List<String> undo(String id);

    /**
     * Patch the graph using a commit.
     * @param commit The commit to apply to the graph.
     */
    void patch(Commit commit);

    /**
     * Clone the entire graph, including history.
     * @return All of the commits.
     */
    Iterable<Commit> cloneGraph();

    /**
     * Clone a subset of the graph, including history.
     * @param nodes The list of nodes to include in this clone.
     * @return A list of Commits.
     */
    Iterable<Commit> cloneGraph(Iterable<Node> nodes);

    /**
     * Create a copy of the graph. This does not preserve history.
     * @param author The author.
     * @param email The author's email.
     * @param message The new commit message.
     * @return A new Commit.
     */
    Commit copy(String author, String email, String message);

    /**
     * Create a copy of a subset of this graph. This does not preserve history.
     * @param nodes The list of nodes to include in this copy.
     * @param author The author.
     * @param email The author's email.
     * @param message The new commit message.
     * @return A new Commit.
     */
    Commit copy(Iterable<Node> nodes, String author, String email, String message);

    /**
     * Takes commit from another repository and reformats it to work for this repository.
     * @param commit The commit to reformat.
     * @param author The author.
     * @param email The author's email.
     * @param message The new commit message.
     * @return A new Commit.
     */
    Commit merge(Commit commit, String author, String email, String message);
}

package com.github.trepo.vgraph;

import java.util.Set;

/**
 * @author John Clark.
 */
public interface Element {

    /**
     * Gets the Element's ID.
     * @return The ID.
     */
    String getId();

    /**
     * Gets the Element's Label.
     * @return The Label.
     */
    String getLabel();

    /**
     * Gets the Element's Hash.
     * @return The Hash (which may be null)
     */
    String getHash();

    /**
     * Returns a Set of property keys.
     * Note that this does NOT include special property keys.
     * @return The Set of Property Keys.
     */
    Set<String> getPropertyKeys();

    /**
     * Gets a Property from the Element.
     * @param key The Property Key to retrieve.
     * @return The Property, or Null if not present.
     */
    Object getProperty(String key);

    /**
     * Sets a Property on the Element.
     * @param key The Property key.
     * @param value The value.
     */
    void setProperty(String key, Object value);

    /**
     * Removes a Property.
     * @param key The Property to remove.
     */
    void removeProperty(String key);

}

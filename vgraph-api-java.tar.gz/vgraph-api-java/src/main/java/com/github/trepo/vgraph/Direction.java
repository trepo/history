package com.github.trepo.vgraph;

/**
 * @author John Clark.
 */
public enum Direction {
    /**
     * In.
     */
    IN,

    /**
     * Out.
     */
    OUT,

    /**
     * Both.
     */
    BOTH
}

package com.github.trepo.vgraph;

import java.util.List;
import java.util.regex.Pattern;

/**
 * @author John Clark.
 */
public final class Property {

    /**
     * The regex pattern for a property key.
     */
    public static final Pattern KEY_PATTERN = Pattern.compile("[A-Za-z][A-Za-z0-9_]{0,254}");

    /**
     * Private Constructor to prevent instantiation.
     */
    private Property() {
        // Never called.
    }

    /**
     * Validates a key.
     * @param key The key to validate.
     * @return True if key is valid, false otherwise.
     */
    public static boolean isValidKey(String key) {
        return key != null && KEY_PATTERN.matcher(key).matches();
    }

    /**
     * Validates a Value.
     * Valid types are either a SimpleValue or a list of SimpleValues.
     * @param value The value to validate.
     * @return True if the regular value is valid, false otherwise.
     */
    public static boolean isValidValue(Object value) {

        // If this is a list, make sure its subtype is valid
        if (value != null && value instanceof List<?>) {
            List<?> list = (List<?>) value;

            String type = null;

            for (Object elem: list) {
                // If sub element is not allowed
                if (!isValidSimpleValue(elem)) {
                    return false;
                }
                // Prevent mixed types
                if (type == null) {
                    type = elem.getClass().getName();
                }
                if (!type.equals(elem.getClass().getName())) {
                    return false;
                }
            }
            // If the list is empty there is nothing we can do to check the type.
            return true;
        } else {
            return isValidSimpleValue(value);
        }

    }

    /**
     * Check for the allowed simple types.
     * Valid types are Boolean, Character, Integer, Double, Long, Float, and String.
     * @param value The object to check.
     * @return True if the value is valid, false otherwise.
     */
    private static boolean isValidSimpleValue(Object value) {

        if (value == null) {
            return false;
        }

        switch(value.getClass().getName()) {
            case "java.lang.Boolean":
            case "java.lang.Character":
            case "java.lang.Integer":
            case "java.lang.Double":
            case "java.lang.Long":
            case "java.lang.Float":
            case "java.lang.String":
                return true;
            default:
                return false;
        }
    }
}

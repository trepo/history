package com.github.trepo.vgraph;

/**
 * @author John Clark.
 */
public interface Edge extends Element {

    /**
     * Gets the Node in the specified Direction.
     * @param direction The direction to look when retrieving the Node.
     * @return The Node.
     */
    Node getNode(Direction direction);
}

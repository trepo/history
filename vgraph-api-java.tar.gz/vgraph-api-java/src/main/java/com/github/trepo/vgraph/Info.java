package com.github.trepo.vgraph;

/**
 * @author John Clark.
 */
public class Info {

    /**
     * The current vGraph data/api version.
     */
    private String version;

    /**
     * The repository identifier.
     */
    private String repo;

    /**
     * The latest Commit ID.
     */
    private String commit;

    /**
     * If there are no uncommitted changes.
     */
    private Boolean clean;

    /**
     * A no-args constructor.
     */
    public Info() {
        // Do nothing
    }

    /**
     * Create a new vGraph Info.
     * @param vGraphVersion The version.
     * @param vGraphRepo The repo.
     * @param lastCommit The commit.
     * @param vGraphClean The value of clean.
     */
    public Info(String vGraphVersion, String vGraphRepo, String lastCommit, Boolean vGraphClean) {
        version = vGraphVersion;
        repo = vGraphRepo;
        commit = lastCommit;
        clean = vGraphClean;
    }

    /**
     * Gets the current vGraph version.
     * @return The vGraph version.
     */
    public String getVersion() {
        return version;
    }

    /**
     * Set the version.
     * @param vGraphVersion The version.
     * @return This Info.
     */
    public Info setVersion(String vGraphVersion) {
        version = vGraphVersion;
        return this;
    }

    /**
     * Gets the repository identifier of this vGraph instance.
     * @return The repository identifier.
     */
    public String getRepo() {
        return repo;
    }

    /**
     * Set the repo.
     * @param vGraphRepo The repo.
     * @return This Info.
     */
    public Info setRepo(String vGraphRepo) {
        repo = vGraphRepo;
        return this;
    }

    /**
     * Gets the latest Commit ID.
     * @return The latest Commit ID.
     */
    public String getCommit() {
        return commit;
    }

    /**
     * Set the commit.
     * @param lastCommit The commit.
     * @return This Info.
     */
    public Info setCommit(String lastCommit) {
        commit = lastCommit;
        return this;
    }

    /**
     * If there are any uncommitted changes to vGraph.
     * @return True if there are no uncommitted changes, false otherwise.
     */
    public Boolean isClean() {
        return clean;
    }

    /**
     * Set clean.
     * @param vGraphClean Clean.
     * @return This Info.
     */
    public Info setClean(Boolean vGraphClean) {
        clean = vGraphClean;
        return this;
    }
}

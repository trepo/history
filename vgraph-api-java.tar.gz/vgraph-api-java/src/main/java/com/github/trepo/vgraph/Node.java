package com.github.trepo.vgraph;

/**
 * @author John Clark.
 */
public interface Node extends Element {

    /**
     * Gets the Node's Repo.
     * @return The Repo Identifier.
     */
    String getRepo();

    /**
     * Returns true if this node is a boundary, false otherwise.
     * @return True if this is a boundary node.
     */
    boolean isBoundary();

    /**
     * Adds an edge from this Node to the provided node.
     * @param label The label you wish to create.
     * @param to The Node to create the Edge to.
     * @return The created Edge.
     */
    Edge addEdge(Node to, String label);

    /**
     * Gets a list of Edges that match the given direction and labels.
     * @param direction The direction of the Edges to return.
     * @param labels The labels of the Edges to return.
     * @return An Iterable of Edges.
     */
    Iterable<Edge> getEdges(Direction direction, String... labels);

    /**
     * Gets a list of Nodes that match the given direction and labels.
     * @param direction The direction of the Nodes to return.
     * @param labels The labels of the Edges to follow.
     * @return An Iterable of Nodes.
     */
    Iterable<Node> getNodes(Direction direction, String... labels);
}

package com.github.trepo.vgraph;

/**
 * Meta Property keys and values.
 * @author John Clark.
 */
public final class MetaProperty {

    /**
     * The meta element key.
     */
    public static final String KEY = "__meta";

    /**
     * The value of the meta key for the root node.
     */
    public static final String ROOT = "_root";

    /**
     * The meta property key that stores the vGraph API version.
     */
    public static final String ROOT_VERSION = "_version";

    /**
     * The value of the meta key for a commit node.
     */
    public static final String COMMIT_NODE = "_commit";

    /**
     * The meta property key that stores the commit id.
     */
    public static final String COMMIT_ID = "_id";

    /**
     * The meta property key that stores the commit repo.
     */
    public static final String COMMIT_REPO = "_repo";

    /**
     * The meta property key that stores the commit timestamp.
     */
    public static final String COMMIT_TIMESTAMP = "_timestamp";

    /**
     * The meta property key that stores the commit author.
     */
    public static final String COMMIT_AUTHOR = "_author";

    /**
     * The meta property key that stores the commit email.
     */
    public static final String COMMIT_EMAIL = "_email";

    /**
     * The meta property key that stores the commit message.
     */
    public static final String COMMIT_MESSAGE = "_message";

    /**
     * The meta property key that stores the commit nodes.
     */
    public static final String COMMIT_NODES = "_nodes";

    /**
     * The meta property key that stores the commit edges.
     */
    public static final String COMMIT_EDGES = "_edges";

    /**
     * The value of the meta key for a commit edge.
     * Also used as the label for a commit edge.
     */
    public static final String COMMIT_EDGE = "_commit_edge";


    /**
     * Private Constructor to prevent instantiation.
     */
    private MetaProperty() {
        // Never called.
    }
}

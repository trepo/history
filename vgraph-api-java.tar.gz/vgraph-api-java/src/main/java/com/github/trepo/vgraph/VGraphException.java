package com.github.trepo.vgraph;

/**
 * The base Exception class for vGraph.
 * @author John Clark.
 */
public class VGraphException extends RuntimeException {

    /**
     * Create a VGraphException.
     * @param s The message.
     */
    public VGraphException(String s) {
        super(s);
    }

    /**
     * Create a VGraphException.
     * @param s The message.
     * @param e The exception.
     */
    public VGraphException(String s, Exception e) {
        super(s, e);
    }
}

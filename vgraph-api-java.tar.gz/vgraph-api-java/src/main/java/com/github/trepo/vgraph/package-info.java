/**
 * The API for vGraph.
 * @author John Clark.
 */
package com.github.trepo.vgraph;

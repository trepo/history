package com.github.trepo.vgraph;

import java.util.HashSet;
import java.util.Set;

/**
 * @author John Clark.
 */
public class Commit {

    /**
     * The Commit version.
     */
    private Integer version;

    /**
     * The Commit ID.
     */
    private String id;

    /**
     * The previous Commit ID.
     */
    private String prev;

    /**
     * The repository this Commit was created for.
     */
    private String repo;

    /**
     * When this Commit was created.
     */
    private Long timestamp;

    /**
     * The author of this Commit.
     */
    private String author;

    /**
     * The author's email address.
     */
    private String email;

    /**
     * The Commit message.
     */
    private String message;

    /**
     * The Commit's Nodes.
     */
    private Set<CommitNode> nodes;

    /**
     * The Commit's Edges.
     */
    private Set<CommitEdge> edges;

    /**
     * Get the Commit's Version.
     * @return The Commit's Version.
     */
    public Integer getVersion() {
        return version;
    }

    /**
     * Set the Commit's Version.
     * @param commitVersion The Version.
     * @return This Commit.
     */
    public Commit setVersion(Integer commitVersion) {
        version = commitVersion;
        return this;
    }

    /**
     * Get the Commit's ID.
     * @return The Commit's ID.
     */
    public String getId() {
        return id;
    }

    /**
     * Set the Commit's ID.
     * @param commitId The ID.
     * @return This Commit.
     */
    public Commit setId(String commitId) {
        id = commitId;
        return this;
    }

    /**
     * Get the Commit's Previous Commit ID.
     * @return The Previous Commit ID.
     */
    public String getPrev() {
        return prev;
    }

    /**
     * Set the Commit's Previous ID.
     * @param previousCommitId The ID.
     * @return This Commit.
     */
    public Commit setPrev(String previousCommitId) {
        prev = previousCommitId;
        return this;
    }

    /**
     * Get the Commit's Repository Identifier.
     * @return The Commit's Repository Identifier.
     */
    public String getRepo() {
        return repo;
    }

    /**
     * Set the Commit's Repo.
     * @param commitRepo The repo.
     * @return This Commit.
     */
    public Commit setRepo(String commitRepo) {
        repo = commitRepo;
        return this;
    }

    /**
     * Get the Commit's Timestamp.
     * @return The Commit's Timestamp.
     */
    public Long getTimestamp() {
        return timestamp;
    }

    /**
     * Set the Commit's timestamp.
     * @param commitTimestamp The timestamp.
     * @return This Commit.
     */
    public Commit setTimestamp(Long commitTimestamp) {
        timestamp = commitTimestamp;
        return this;
    }

    /**
     * Get the Commit's author.
     * @return The Commit's author.
     */
    public String getAuthor() {
        return author;
    }

    /**
     * Set the Commit's author.
     * @param commitAuthor The author.
     * @return This Commit.
     */
    public Commit setAuthor(String commitAuthor) {
        author = commitAuthor;
        return this;
    }

    /**
     * Get the Commit's email.
     * @return The Commit's email.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Set the Commit's email.
     * @param commitEmail The email.
     * @return This Commit.
     */
    public Commit setEmail(String commitEmail) {
        email = commitEmail;
        return this;
    }

    /**
     * Get the Commit's message.
     * @return The Commit's message.
     */
    public String getMessage() {
        return message;
    }

    /**
     * Set the Commit's message.
     * @param commitMessage The message.
     * @return This Commit.
     */
    public Commit setMessage(String commitMessage) {
        message = commitMessage;
        return this;
    }

    /**
     * Get the Commit's CommitNodes.
     * @return The Commit's CommitNodes.
     */
    public Set<CommitNode> getNodes() {
        return nodes;
    }

    /**
     * Set the Commit's commitNodes.
     * @param commitNodes The commitNodes.
     * @return This Commit.
     */
    public Commit setNodes(Set<CommitNode> commitNodes) {
        nodes = commitNodes;
        return this;
    }

    /**
     * Get the Commit's CommitEdges.
     * @return The Commit's CommitEdges.
     */
    public Set<CommitEdge> getEdges() {
        return edges;
    }

    /**
     * Set the Commit's commitEdges.
     * @param commitEdges The commitEdges.
     * @return This Commit.
     */
    public Commit setEdges(Set<CommitEdge> commitEdges) {
        edges = commitEdges;
        return this;
    }

    /**
     * Validate this CommitNode.
     */
    public void validate() {

        // version
        if (version == null) {
            throw new VGraphException("version is null");
        }
        if (version != 1) {
            throw new VGraphException("version is invalid");
        }

        // id
        if (id == null) {
            throw new VGraphException("id is null");
        }
        if (!SpecialProperty.isValidId(id)) {
            throw new VGraphException("id is invalid");
        }

        // prev
        if (prev != null && !SpecialProperty.isValidId(prev)) {
            throw new VGraphException("prev is invalid");
        }

        // repo
        if (repo == null) {
            throw new VGraphException("repo is null");
        }

        // timestamp
        if (timestamp == null) {
            throw new VGraphException("timestamp is null");
        }

        // author
        if (author == null) {
            throw new VGraphException("author is null");
        }

        // email
        if (email == null) {
            throw new VGraphException("email is null");
        }

        // message
        if (message == null) {
            throw new VGraphException("message is null");
        }

        // nodes
        if (nodes == null) {
            throw new VGraphException("nodes is null");
        }
        // Keep track of the node ids we've seen so far.
        // This is to help verify that the edges reference nodes that exist.
        HashSet<String> nodeIds = new HashSet<>();
        for (CommitNode node: nodes) {
            // Validate node
            try {
                node.validate();
            } catch (VGraphException e) {
                throw new VGraphException("invalid node: " + node.getId() + " - " + e.getMessage());
            }
            // Add node id
            nodeIds.add(node.getId());
        }

        // edges
        if (edges == null) {
            throw new VGraphException("edges is null");
        }
        for (CommitEdge edge: edges) {
            // Validate edge
            try {
                edge.validate();
            } catch (VGraphException e) {
                throw new VGraphException("invalid edge: " + edge.getId() + " - " + e.getMessage());
            }
            // ensure from exists if action is not delete
            if (!edge.getAction().equals(Action.DELETE)) {
                if (!nodeIds.contains(edge.getFrom())) {
                    throw new VGraphException("invalid edge: " + edge.getId()
                            + " - from node " + edge.getFrom() + " does not exist");
                }
                // ensure to exists
                if (!nodeIds.contains(edge.getTo())) {
                    throw new VGraphException("invalid edge: " + edge.getId()
                            + " - to node " + edge.getTo() + " does not exist");
                }
            }
        }
    }

    /**
     * Commits are equal if they have the same ID regardless of the action.
     * @param o The object to compare to this object.
     * @return True if this and the passed in object are the same.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        Commit that = (Commit) o;

        if (id == null) {
            return super.equals(that);
        } else {
            return id.equals(that.id);
        }

    }

    /**
     * The HashCode for this object is the id's HashCode.
     * @return The ID's HashCode.
     */
    @Override
    public int hashCode() {
        if (id == null) {
            return super.hashCode();
        } else {
            return id.hashCode();
        }
    }
}

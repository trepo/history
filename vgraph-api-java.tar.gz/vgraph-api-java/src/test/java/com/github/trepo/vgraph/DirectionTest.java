package com.github.trepo.vgraph;

import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class DirectionTest {

    @Test
    public void works() {
        assertThat(Direction.IN).isNotNull();
        assertThat(Direction.OUT).isNotNull();
        assertThat(Direction.BOTH).isNotNull();
    }
}

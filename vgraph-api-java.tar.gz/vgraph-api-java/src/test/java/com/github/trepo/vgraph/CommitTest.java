package com.github.trepo.vgraph;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class CommitTest {

    private HashSet<CommitNode> nodes;
    private HashSet<CommitEdge> edges;

    @BeforeTest
    public void setup() {
        nodes = new HashSet<>();
        nodes.add(new CommitNode()
                        .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                        .setLabel("node_label")
                        .setAction(Action.CREATE)
                        .setBoundary(false)
                        .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                        .setProperties(new HashMap<String, Object>())
        );
        nodes.add(new CommitNode()
                        .setId("a30f16cb-e49f-458e-a5aa-096faf2cd90d")
                        .setLabel("node_label")
                        .setAction(Action.CREATE)
                        .setBoundary(false)
                        .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                        .setProperties(new HashMap<String, Object>())
        );

        edges = new HashSet<>();
        edges.add(new CommitEdge()
                        .setId("11681960-11b3-4968-b3df-cac322260a06")
                        .setLabel("EDGE")
                        .setFrom("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                        .setTo("a30f16cb-e49f-458e-a5aa-096faf2cd90d")
                        .setAction(Action.CREATE)
                        .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                        .setProperties(new HashMap<String, Object>())
        );
    }

    /**
     * getters & setters
     */
    @Test
    public void getters_setters_shouldWork() {

        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(edges);

        assertThat(commit.getVersion()).isEqualTo(1);
        assertThat(commit.getId()).isEqualTo("793ce0ab-ea1c-4465-ad17-91606b7f70e7");
        assertThat(commit.getPrev()).isEqualTo("b08f7061-ee08-4f24-b11b-7b15a0a5627b");
        assertThat(commit.getRepo()).isEqualTo("repo");
        assertThat(commit.getTimestamp()).isEqualTo(1412817717000L);
        assertThat(commit.getAuthor()).isEqualTo("author");
        assertThat(commit.getEmail()).isEqualTo("email");
        assertThat(commit.getMessage()).isEqualTo("message");
        assertThat(commit.getNodes()).isEqualTo(nodes);
        assertThat(commit.getEdges()).isEqualTo(edges);
    }

    /**
     * validate
     */
    @Test
    public void validate_shouldErrorOnNullVersion() {
        Commit commit = new Commit()
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("version is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidVersion() {
        Commit commit = new Commit()
                .setVersion(0)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("version is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnNullId() {
        Commit commit = new Commit()
                .setVersion(1)
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("id is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidId() {
        Commit commit = new Commit()
                .setVersion(1)
                .setId("1234")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("id is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidPrev() {
        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("1234")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("prev is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnNullRepo() {
        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("repo is null");
        }
    }

    @Test
    public void validate_shouldErrorOnNullTimetamp() {
        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("timestamp is null");
        }
    }

    @Test
    public void validate_shouldErrorOnNullAuthor() {
        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("author is null");
        }
    }

    @Test
    public void validate_shouldErrorOnNullEmail() {
        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("email is null");
        }
    }

    @Test
    public void validate_shouldErrorOnNullMessage() {
        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setNodes(nodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("message is null");
        }
    }

    @Test
    public void validate_shouldErrorOnNullNodes() {
        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("nodes is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidNode() {
        HashSet<CommitNode> localNodes = new HashSet<>();
        localNodes.add(new CommitNode()
                        .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                        .setLabel("node_label")
                        .setAction(Action.CREATE)
                        .setBoundary(false)
                        .setHash("1234")
                        .setProperties(new HashMap<String, Object>())
        );
        localNodes.add(new CommitNode()
                        .setId("a30f16cb-e49f-458e-a5aa-096faf2cd90d")
                        .setLabel("node_label")
                        .setAction(Action.CREATE)
                        .setBoundary(false)
                        .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                        .setProperties(new HashMap<String, Object>())
        );

        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(localNodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("invalid node: 4e78dce2-acfa-4856-9da4-f81cbec8b0bf - hash is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnNullEdges() {
        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("edges is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidEdge() {
        HashSet<CommitEdge> localEdges = new HashSet<>();
        localEdges.add(new CommitEdge()
                        .setId("11681960-11b3-4968-b3df-cac322260a06")
                        .setLabel("__invalid")
                        .setFrom("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                        .setTo("a30f16cb-e49f-458e-a5aa-096faf2cd90d")
                        .setAction(Action.CREATE)
                        .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                        .setProperties(new HashMap<String, Object>())
        );

        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(localEdges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("invalid edge: 11681960-11b3-4968-b3df-cac322260a06 - label is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnMissingFrom() {
        HashSet<CommitNode> localNodes = new HashSet<>();
        localNodes.add(new CommitNode()
                        .setId("a30f16cb-e49f-458e-a5aa-096faf2cd90d")
                        .setLabel("node_label")
                        .setAction(Action.CREATE)
                        .setBoundary(false)
                        .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                        .setProperties(new HashMap<String, Object>())
        );

        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(localNodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("invalid edge: 11681960-11b3-4968-b3df-cac322260a06 - from node 4e78dce2-acfa-4856-9da4-f81cbec8b0bf does not exist");
        }
    }

    @Test
    public void validate_shouldErrorOnMissingTo() {
        HashSet<CommitNode> localNodes = new HashSet<>();
        localNodes.add(new CommitNode()
                        .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                        .setLabel("node_label")
                        .setAction(Action.CREATE)
                        .setBoundary(false)
                        .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                        .setProperties(new HashMap<String, Object>())
        );

        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(localNodes)
                .setEdges(edges);

        try {
            commit.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("invalid edge: 11681960-11b3-4968-b3df-cac322260a06 - to node a30f16cb-e49f-458e-a5aa-096faf2cd90d does not exist");
        }
    }

    @Test
    public void validate_shouldWorkForDeleteEdgeOnly() {
        HashSet<CommitEdge> localEdges = new HashSet<>();
        localEdges.add(new CommitEdge()
                        .setId("11681960-11b3-4968-b3df-cac322260a06")
                        .setLabel("edge_label")
                        .setFrom("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                        .setTo("a30f16cb-e49f-458e-a5aa-096faf2cd90d")
                        .setAction(Action.DELETE)
                        .setOriginal(new HashMap<String, Object>())
        );

        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(new HashSet<CommitNode>())
                .setEdges(localEdges);

        commit.validate();
    }

    @Test
    public void validate_shouldWork() {
        Commit commit = new Commit()
                .setVersion(1)
                .setId("793ce0ab-ea1c-4465-ad17-91606b7f70e7")
                .setPrev("b08f7061-ee08-4f24-b11b-7b15a0a5627b")
                .setRepo("repo")
                .setTimestamp(1412817717000L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(edges);

        commit.validate();
    }

    /**
     * equals
     */
    @Test
    public void equals_shouldReturnTrueWithSelf() {
        Commit commit = new Commit().setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf");

        assertThat(commit.equals(commit)).isEqualTo(true);
    }

    @Test
    public void equals_shouldReturnFalseWithNull() {
        Commit commit = new Commit().setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf");

        assertThat(commit.equals(null)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithDifferentClass() {
        Commit commit = new Commit().setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf");

        assertThat(commit.equals(new Date())).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithDifferentCommit() {
        Commit commit1 = new Commit().setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf");

        Commit commit2 = new Commit().setId("9cea5fbe-1ffd-4ef7-b08b-40d278bbb0f9");

        assertThat(commit1.equals(commit2)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnTrueWithSameCommitEdge() {
        Commit commit1 = new Commit().setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf");

        Commit commit2 = new Commit().setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf");

        assertThat(commit1.equals(commit2)).isEqualTo(true);
        assertThat(commit2.equals(commit1)).isEqualTo(true);
    }

    @Test
    public void equals_shouldReturnFalseWithNullId() {
        Commit commit1 = new Commit();
        Commit commit2 = new Commit();

        assertThat(commit1.equals(commit2)).isEqualTo(false);
    }

    /**
     * hashCode
     */
    @Test
    public void hashCode_shouldReturnSameHashCodeAsID() {
        Commit commit = new Commit().setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf");

        assertThat(commit.hashCode()).isEqualTo(commit.getId().hashCode());
    }

    @Test
    public void hashCode_shouldNotFailOnNullId() {
        Commit commit = new Commit();

        assertThat(commit.hashCode()).isNotNull();
    }
}

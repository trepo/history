package com.github.trepo.vgraph;

import org.testng.annotations.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.UUID;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class SpecialPropertyTest {

    /**
     * constructor
     */
    @Test
    public void class_isProperlyFinal() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class<?> thisClass = SpecialProperty.class;

        // Final and only 1 constructor
        assertThat(Modifier.isFinal(thisClass.getModifiers())).isEqualTo(true);
        assertThat(thisClass.getDeclaredConstructors().length).isEqualTo(1);

        // Make sure constructor is private
        final Constructor<?> constructor = thisClass.getDeclaredConstructor();
        assertThat(constructor.isAccessible()).isEqualTo(false);
        assertThat(Modifier.isPrivate(constructor.getModifiers())).isEqualTo(true);
        constructor.setAccessible(true);
        constructor.newInstance();
        constructor.setAccessible(false);

        // All methods must be static
        for (final Method method : SpecialProperty.class.getMethods()) {
            if (!Modifier.isStatic(method.getModifiers())
                    && method.getDeclaringClass().equals(thisClass)) {
                fail("Non static method:"+method);
            }
        }
    }

    /**
     * static properties
     */
    @Test
    public void static_properties_shouldBePresent() {
        assertThat(SpecialProperty.ID).isNotNull();
        assertThat(SpecialProperty.LABEL).isNotNull();
        assertThat(SpecialProperty.LABEL_PATTERN).isNotNull();
        assertThat(SpecialProperty.HASH).isNotNull();
        assertThat(SpecialProperty.REPO).isNotNull();
        assertThat(SpecialProperty.REPO_PATTERN).isNotNull();
        assertThat(SpecialProperty.DELETED).isNotNull();
        assertThat(SpecialProperty.ORIGINAL).isNotNull();
    }

    /**
     * generateId
     */
    @Test
    public void generateId_shouldWork() {
        String id = SpecialProperty.generateId();

        assertThat(id.length()).isEqualTo(36);

        UUID uuid = UUID.fromString(id);
        assertThat(uuid.version()).isEqualTo(4);
    }

    /**
     * isValidId
     */
    @Test
    public void isValidId_shouldFalseOnNull() {
        assertThat(SpecialProperty.isValidId(null)).isFalse();
    }

    @Test
    public void isValidId_shouldFalseOnInvalidUUID() {
        assertThat(SpecialProperty.isValidId("1234")).isFalse();
    }

    @Test
    public void isValidId_shouldFalseOnWrongUUIDVersion() {
        // version 1 uuid
        assertThat(SpecialProperty.isValidId("ed381c0c-c1b4-11e4-8dfc-aa07a5b093db")).isFalse();
    }

    @Test
    public void isValidId_shouldWork() {
        assertThat(SpecialProperty.isValidId("86d690a0-2d17-49a5-a08d-2fb7b6021299")).isTrue();
    }

    /**
     * isValidLabel
     */
    @Test
    public void isValidLabel_shouldFalseOnNull() {
        assertThat(SpecialProperty.isValidLabel(null)).isFalse();
    }

    @Test
    public void isValidLabel_shouldFalseOnInvalid() {
        assertThat(SpecialProperty.isValidLabel("__invalid")).isFalse();
    }

    @Test
    public void isValidLabel_shouldWork() {
        assertThat(SpecialProperty.isValidLabel("valid")).isTrue();
    }

    /**
     * isValidRepo
     */
    @Test
    public void isValidRepo_shouldFalseOnNull() {
        assertThat(SpecialProperty.isValidRepo(null)).isFalse();
    }

    @Test
    public void isValidRepo_shouldFalseOnInvalid() {
        assertThat(SpecialProperty.isValidRepo("")).isFalse();
    }

    @Test
    public void isValidRepo_shouldWork() {
        assertThat(SpecialProperty.isValidRepo("valid")).isTrue();
    }

    /**
     * generateTimestamp
     */
    @Test
    public void generateTimestamp_shouldReturnCorrectTimestamp() {
        long timestamp = SpecialProperty.generateTimestamp();
        assertThat((new Date().getTime())-timestamp).isGreaterThanOrEqualTo(0).isLessThan(500);
    }

    /**
     * calculateHash
     */
    @Test
    public void calculateHash_shouldWork() {
        HashMap<String, Object> m = new HashMap<>();

        assertThat(SpecialProperty.calculateHash(m)).isEqualTo("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        // Should have 1 property
        m.put("prop", "foo");
        assertThat(SpecialProperty.calculateHash(m)).isEqualTo("91af72e0584d81d34a1aa9d47b8227d87611cd1c");

        // Should have 2 properties
        m.put("bool", true);
        assertThat(SpecialProperty.calculateHash(m)).isEqualTo("9d6654ff4cf10fe2edb0646648db914a9e0c655d");

        // And again with 3 (being an array)
        m.put("cars", Arrays.asList("zed", "alpha", "nosorty", "bwahahaha"));
        assertThat(SpecialProperty.calculateHash(m)).isEqualTo("cf975181076e171267358113c09bc1fe0e69a7c3");

        // One final test
        LinkedHashMap<String, Object> l = new LinkedHashMap<>();
        l.put("zed", false);
        l.put("moe", "yup");
        l.put("alpha", Arrays.asList("beta", "gamma", "delta"));
        assertThat(SpecialProperty.calculateHash(l)).isEqualTo("355ee7ba3f2231e64511a528bf3917168b4484a9");

    }
}

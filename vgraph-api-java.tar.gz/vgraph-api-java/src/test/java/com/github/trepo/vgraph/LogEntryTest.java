package com.github.trepo.vgraph;

import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class LogEntryTest {

    /**
     * getters & setters
     */
    @Test
    public void getters_setters_shouldWork() {
        LogEntry logEntry = new LogEntry()
                .setId("1234")
                .setTimestamp(1234L)
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message");

        assertThat(logEntry.getId()).isEqualTo("1234");
        assertThat(logEntry.getTimestamp()).isEqualTo(1234L);
        assertThat(logEntry.getAuthor()).isEqualTo("author");
        assertThat(logEntry.getEmail()).isEqualTo("email");
        assertThat(logEntry.getMessage()).isEqualTo("message");
    }
}

package com.github.trepo.vgraph;

import org.testng.annotations.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class PropertyTest {
    /**
     * constructor
     */
    @Test
    public void class_isProperlyFinal() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class<?> thisClass = Property.class;

        // Final and only 1 constructor
        assertThat(Modifier.isFinal(thisClass.getModifiers())).isEqualTo(true);
        assertThat(thisClass.getDeclaredConstructors().length).isEqualTo(1);

        // Make sure constructor is private
        final Constructor<?> constructor = thisClass.getDeclaredConstructor();
        assertThat(constructor.isAccessible()).isEqualTo(false);
        assertThat(Modifier.isPrivate(constructor.getModifiers())).isEqualTo(true);
        constructor.setAccessible(true);
        constructor.newInstance();
        constructor.setAccessible(false);

        // All methods must be static
        for (final Method method : Property.class.getMethods()) {
            if (!Modifier.isStatic(method.getModifiers())
                    && method.getDeclaringClass().equals(thisClass)) {
                fail("Non static method:"+method);
            }
        }
    }

    /**
     * static properties
     */
    @Test
    public void static_properties_shouldBePresent() {
        assertThat(Property.KEY_PATTERN).isNotNull();
    }

    /**
     * isValidKey
     */
    @Test
    public void isValidKey_shouldFalseOnNull() {
        assertThat(Property.isValidKey(null)).isEqualTo(false);
    }

    @Test
    public void isValidKey_shouldFalseOnInvalid() {
        List<String> tests = Arrays.asList("_A","A@","--","B0GuS!", null);
        for(String test: tests) {
            assertThat(Property.isValidKey(test)).isEqualTo(false);
        }
    }

    @Test
    public void isValidKey_shouldFalseOnLongValue() {
        String label = "1";
        for(int i = 0; i < 51; i++) {
            label += "ABCDE";
        }
        assertThat(Property.isValidKey(label)).isEqualTo(false);
    }

    @Test
    public void isValidKey_shouldWork() {
        List<String> tests = Arrays.asList("A", "ABC", "A_BC", "a____");
        for(String test: tests) {
            assertThat(Property.isValidKey(test)).isEqualTo(true);
        }
    }

    @Test
    public void isValidKey_shouldWorkOn255() {
        String key = "";
        for(int i = 0; i < 51; i++) {
            key += "ABCDE";
        }
        assertThat(Property.isValidKey(key)).isTrue();
    }

    /**
     * isValidValue
     */
    @Test
    public void isValidValue_shouldWorkCorrectly() {

        // Simple types should return true
        assertThat(Property.isValidValue(true)).isEqualTo(true);
        assertThat(Property.isValidValue(new Boolean(false))).isEqualTo(true);
        assertThat(Property.isValidValue('C')).isEqualTo(true);
        assertThat(Property.isValidValue(new Character('C'))).isEqualTo(true);
        assertThat(Property.isValidValue(1)).isEqualTo(true);
        assertThat(Property.isValidValue(new Integer(0))).isEqualTo(true);
        assertThat(Property.isValidValue(1.2)).isEqualTo(true);
        assertThat(Property.isValidValue(new Double(3.14159))).isEqualTo(true);
        assertThat(Property.isValidValue(new Long(3))).isEqualTo(true);
        assertThat(Property.isValidValue(new Float(3.14159))).isEqualTo(true);
        assertThat(Property.isValidValue("string#1")).isEqualTo(true);

        // Null should be false
        assertThat(Property.isValidValue(null)).isEqualTo(false);

        // Empty Array
        List<Object> arr = new ArrayList<>();
        assertThat(Property.isValidValue(arr)).isEqualTo(true);

        // An array with 1 valid element
        arr.add(new Integer(0));
        assertThat(Property.isValidValue(arr)).isEqualTo(true);

        // An array with 2 valid element2
        arr.add(new Integer(3));
        assertThat(Property.isValidValue(arr)).isEqualTo(true);

        // Disallow mixed arrays
        arr.add("bam!");
        assertThat(Property.isValidValue(arr)).isEqualTo(false);

        // Disallow other objects
        assertThat(Property.isValidValue(new Object())).isEqualTo(false);

        // Disallow a list of invalid types
        List<Object> arr2 = new ArrayList<>();
        arr2.add(new Object());
        assertThat(Property.isValidValue(arr2)).isEqualTo(false);
    }
}

package com.github.trepo.vgraph;

import org.testng.annotations.Test;

import java.util.Date;
import java.util.HashMap;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class CommitEdgeTest {

    /**
     * getters & setters
     */
    @Test
    public void getters_setters_shouldWork() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("1234")
                .setOriginal(original)
                .setProperties(properties);

        assertThat(commitEdge.getId()).isEqualTo("4e78dce2-acfa-4856-9da4-f81cbec8b0bf");
        assertThat(commitEdge.getLabel()).isEqualTo("label");
        assertThat(commitEdge.getFrom()).isEqualTo("5687941c-fbed-4be1-9281-5f59dd522c22");
        assertThat(commitEdge.getTo()).isEqualTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c");
        assertThat(commitEdge.getAction()).isEqualTo(Action.UPDATE);
        assertThat(commitEdge.getHash()).isEqualTo("1234");
        assertThat(commitEdge.getOriginal()).isEqualTo(original);
        assertThat(commitEdge.getProperties()).isEqualTo(properties);
    }

    /**
     * validate
     */
    @Test
    public void validate_shouldErrorOnNullId() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("id is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidId() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("1234")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("id is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnNullLabel() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("label is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidLabel() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("__invalid")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("label is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnNullFrom() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("from is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidFrom() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("1234")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("from is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnNullTo() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("to is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidTo() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("1234")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("to is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnNullAction() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("action is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidAction() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction("bogus")
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("action is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnCreateWithOriginal() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.CREATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("original is set when action is create");
        }
    }

    @Test
    public void validate_shouldErrorOnUpdateWithNullOriginal() {

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("original is null");
        }
    }

    @Test
    public void validate_shouldErrorOnDeleteWithInvalidOriginalKey() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("__invalid", true);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.DELETE)
                .setOriginal(original);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("original contains an invalid key: __invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnDeleteWithInvalidOriginalValue() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", null);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.DELETE)
                .setOriginal(original);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("original contains an invalid value for key: testing");
        }
    }

    @Test
    public void validate_shouldErrorOnDeleteWithProperties() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.DELETE)
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("properties is set when action is delete");
        }
    }

    @Test
    public void validate_shouldErrorOnUpdateWithNullProperties() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("properties is null");
        }
    }

    @Test
    public void validate_shouldErrorOnCreateWithInvalidPropertiesKey() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("__invalid", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("properties contains an invalid key: __invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnCreateWithInvalidPropertiesValue() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", null);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("properties contains an invalid value for key: testing");
        }
    }

    @Test
    public void validate_shouldErrorOnDeleteWithHash() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.DELETE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original);
        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("hash is set when action is delete");
        }
    }

    @Test
    public void validate_shouldErrorOnUpdateWithMissingHash() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setOriginal(original)
                .setProperties(properties);
        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("hash is null");
        }
    }

    @Test
    public void validate_shouldErrorOnUpdateWithInvalidHash() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("1234")
                .setOriginal(original)
                .setProperties(properties);
        try {
            commitEdge.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("hash is invalid");
        }
    }

    @Test
    public void validate_shouldWork() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.UPDATE)
                .setHash("7881f7d20b679b02880c181f544809957f6df383")
                .setOriginal(original)
                .setProperties(properties);

        commitEdge.validate();
    }

    /**
     * equals
     */
    @Test
    public void equals_shouldReturnTrueWithSelf() {
        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.CREATE)
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                .setProperties(new HashMap<String, Object>());

        assertThat(commitEdge.equals(commitEdge)).isEqualTo(true);
    }

    @Test
    public void equals_shouldReturnFalseWithNull() {
        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.CREATE)
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                .setProperties(new HashMap<String, Object>());

        assertThat(commitEdge.equals(null)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithDifferentClass() {
        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.CREATE)
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                .setProperties(new HashMap<String, Object>());

        assertThat(commitEdge.equals(new Date())).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithDifferentCommitEdge() {
        CommitEdge commitEdge1 = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.CREATE)
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                .setProperties(new HashMap<String, Object>());

        CommitEdge commitEdge2 = new CommitEdge()
                .setId("9cea5fbe-1ffd-4ef7-b08b-40d278bbb0f9")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.CREATE)
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                .setProperties(new HashMap<String, Object>());

        assertThat(commitEdge1.equals(commitEdge2)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnTrueWithSameCommitEdge() {
        CommitEdge commitEdge1 = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.CREATE)
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                .setProperties(new HashMap<String, Object>());

        CommitEdge commitEdge2 = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.CREATE)
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                .setProperties(new HashMap<String, Object>());
        assertThat(commitEdge1.equals(commitEdge2)).isEqualTo(true);
        assertThat(commitEdge2.equals(commitEdge1)).isEqualTo(true);
    }

    @Test
    public void equals_shouldReturnFalseWithNullId() {
        CommitEdge commitEdge1 = new CommitEdge();
        CommitEdge commitEdge2 = new CommitEdge();

        assertThat(commitEdge1.equals(commitEdge2)).isEqualTo(false);
    }

    /**
     * hashCode
     */
    @Test
    public void hashCode_shouldReturnSameHashCodeAsID() {
        CommitEdge commitEdge = new CommitEdge()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setFrom("5687941c-fbed-4be1-9281-5f59dd522c22")
                .setTo("b1b4b64e-b170-4d85-8188-d7c9936ace7c")
                .setAction(Action.CREATE)
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                .setProperties(new HashMap<String, Object>());

        assertThat(commitEdge.hashCode()).isEqualTo(commitEdge.getId().hashCode());
    }

    @Test
    public void hashCode_shouldNotFailOnNullId() {
        CommitEdge commitEdge = new CommitEdge();

        assertThat(commitEdge.hashCode()).isNotNull();
    }
}

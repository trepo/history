package com.github.trepo.vgraph;

import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class InfoTest {

    /**
     * constructor
     */
    @Test
    public void constructor_shouldWork() {
        Info info = new Info("0.2.0","repo","1234",true);

        assertThat(info.getVersion()).isEqualTo("0.2.0");
        assertThat(info.getRepo()).isEqualTo("repo");
        assertThat(info.getCommit()).isEqualTo("1234");
        assertThat(info.isClean()).isTrue();
    }

    /**
     * getters & setters
     */
    @Test
    public void getters_setters_shouldWork() {
        Info info = new Info()
                .setVersion("0.2.0")
                .setRepo("repo")
                .setCommit("1234")
                .setClean(true);

        assertThat(info.getVersion()).isEqualTo("0.2.0");
        assertThat(info.getRepo()).isEqualTo("repo");
        assertThat(info.getCommit()).isEqualTo("1234");
        assertThat(info.isClean()).isTrue();
    }
}

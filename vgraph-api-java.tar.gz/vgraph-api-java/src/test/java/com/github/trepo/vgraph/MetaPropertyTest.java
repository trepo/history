package com.github.trepo.vgraph;

import org.testng.annotations.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class MetaPropertyTest {

    /**
     * constructor
     */
    @Test
    public void class_isProperlyFinal() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class<?> thisClass = MetaProperty.class;

        // Final and only 1 constructor
        assertThat(Modifier.isFinal(thisClass.getModifiers())).isEqualTo(true);
        assertThat(thisClass.getDeclaredConstructors().length).isEqualTo(1);

        // Make sure constructor is private
        final Constructor<?> constructor = thisClass.getDeclaredConstructor();
        assertThat(constructor.isAccessible()).isEqualTo(false);
        assertThat(Modifier.isPrivate(constructor.getModifiers())).isEqualTo(true);
        constructor.setAccessible(true);
        constructor.newInstance();
        constructor.setAccessible(false);

        // All methods must be static
        for (final Method method : MetaProperty.class.getMethods()) {
            if (!Modifier.isStatic(method.getModifiers())
                    && method.getDeclaringClass().equals(thisClass)) {
                fail("Non static method:"+method);
            }
        }
    }

    /**
     * static properties
     */
    @Test
    public void static_properties_shouldBePresent() {
        assertThat(MetaProperty.KEY).isNotNull();
        assertThat(MetaProperty.ROOT).isNotNull();
        assertThat(MetaProperty.ROOT_VERSION).isNotNull();
        assertThat(MetaProperty.COMMIT_NODE).isNotNull();
        assertThat(MetaProperty.COMMIT_ID).isNotNull();
        assertThat(MetaProperty.COMMIT_REPO).isNotNull();
        assertThat(MetaProperty.COMMIT_TIMESTAMP).isNotNull();
        assertThat(MetaProperty.COMMIT_AUTHOR).isNotNull();
        assertThat(MetaProperty.COMMIT_EMAIL).isNotNull();
        assertThat(MetaProperty.COMMIT_MESSAGE).isNotNull();
        assertThat(MetaProperty.COMMIT_NODES).isNotNull();
        assertThat(MetaProperty.COMMIT_EDGES).isNotNull();
        assertThat(MetaProperty.COMMIT_EDGE).isNotNull();
    }
}

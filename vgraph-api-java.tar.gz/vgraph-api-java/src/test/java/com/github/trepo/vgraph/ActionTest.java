package com.github.trepo.vgraph;

import org.testng.annotations.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class ActionTest {

    @Test
    public void class_isProperlyFinal() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class<?> thisClass = Action.class;

        // Final and only 1 constructor
        assertThat(Modifier.isFinal(thisClass.getModifiers())).isEqualTo(true);
        assertThat(thisClass.getDeclaredConstructors().length).isEqualTo(1);

        // Make sure constructor is private
        final Constructor<?> constructor = thisClass.getDeclaredConstructor();
        assertThat(constructor.isAccessible()).isEqualTo(false);
        assertThat(Modifier.isPrivate(constructor.getModifiers())).isEqualTo(true);
        constructor.setAccessible(true);
        constructor.newInstance();
        constructor.setAccessible(false);

        // All methods must be static
        for (final Method method : Action.class.getMethods()) {
            if (!Modifier.isStatic(method.getModifiers())
                    && method.getDeclaringClass().equals(thisClass)) {
                fail("Non static method:"+method);
            }
        }
    }

    /**
     * isValidAction
     */

    @Test
    public void isValidAction_returnsFalse() {
        assertThat(Action.isValidAction(null)).isFalse();
        assertThat(Action.isValidAction("invalid")).isFalse();
    }

    @Test
    public void isValidAction_returnsTrue() {
        assertThat(Action.isValidAction(Action.CREATE)).isTrue();
        assertThat(Action.isValidAction(Action.UPDATE)).isTrue();
        assertThat(Action.isValidAction(Action.DELETE)).isTrue();
    }
}

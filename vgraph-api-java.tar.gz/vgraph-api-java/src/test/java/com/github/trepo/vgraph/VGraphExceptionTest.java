package com.github.trepo.vgraph;

import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class VGraphExceptionTest {

    /**
     * constructor(message)
     */
    @Test
    public void constructor_message_shouldWork() {
        VGraphException e = new VGraphException("TESTING...");
        assertThat(e.getMessage()).isEqualTo("TESTING...");
    }

    /**
     * constructor(message, exception)
     */
    @Test
    public void constructor_message_exception_shouldWork() {
        Exception newE = new Exception("underlying-exception");
        VGraphException e = new VGraphException("main-exception", newE);

        assertThat(e.getMessage()).isEqualTo("main-exception");
        assertThat(e.getCause().getMessage()).isEqualTo("underlying-exception");
    }
}

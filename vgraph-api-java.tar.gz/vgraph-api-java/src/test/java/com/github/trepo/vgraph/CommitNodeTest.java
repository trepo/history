package com.github.trepo.vgraph;

import org.testng.annotations.Test;

import java.util.Date;
import java.util.HashMap;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class CommitNodeTest {

    /**
     * getters & setters
     */
    @Test
    public void getters_setters_shouldWork() {

        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.UPDATE)
                .setBoundary(false)
                .setRepo("repo")
                .setHash("1234")
                .setOriginal(original)
                .setProperties(properties);

        assertThat(commitNode.getId()).isEqualTo("4e78dce2-acfa-4856-9da4-f81cbec8b0bf");
        assertThat(commitNode.getLabel()).isEqualTo("label");
        assertThat(commitNode.getAction()).isEqualTo(Action.UPDATE);
        assertThat(commitNode.isBoundary()).isFalse();
        assertThat(commitNode.getRepo()).isEqualTo("repo");
        assertThat(commitNode.getHash()).isEqualTo("1234");
        assertThat(commitNode.getOriginal()).isEqualTo(original);
        assertThat(commitNode.getProperties()).isEqualTo(properties);

    }

    /**
     * validate
     */
    @Test
    public void validate_shouldErrorOnNullId() {
        CommitNode commitNode = new CommitNode();
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("id is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidId() {
        CommitNode commitNode = new CommitNode()
                .setId("1234");
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("id is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnNullLabel() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf");
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("label is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidLabel() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("__invalid");
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("label is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnNullAction() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label");
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("action is null");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidAction() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction("invalid");
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("action is invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnNullBoundary() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.UPDATE);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("boundary is null");
        }
    }

    @Test
    public void validate_shouldErrorOnBoundaryWithNullRepo() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.UPDATE)
                .setBoundary(true);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("repo is not set for a boundary node");
        }
    }

    @Test
    public void validate_shouldErrorOnNonBoundaryWithRepo() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.UPDATE)
                .setBoundary(false)
                .setRepo("repo");
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("repo is set for a non-boundary node");
        }
    }

    @Test
    public void validate_shouldErrorOnBoundaryWithOriginal() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.UPDATE)
                .setBoundary(true)
                .setRepo("repo")
                .setOriginal(original);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("original is set for a boundary node");
        }
    }

    @Test
    public void validate_shouldErrorOnCreateWithOriginal() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setOriginal(original);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("original is set when action is create");
        }
    }

    @Test
    public void validate_shouldErrorOnUpdateWithNullOriginal() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.UPDATE)
                .setBoundary(false);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("original is null");
        }
    }

    @Test
    public void validate_shouldErrorOnDeleteWithInvalidOriginalKey() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("__invalid", true);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.DELETE)
                .setBoundary(false)
                .setOriginal(original);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("original contains an invalid key: __invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnDeleteWithInvalidOriginalValue() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", null);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.DELETE)
                .setBoundary(false)
                .setOriginal(original);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("original contains an invalid value for key: testing");
        }
    }

    @Test
    public void validate_shouldErrorOnBoundaryWithProperties() {
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.UPDATE)
                .setBoundary(true)
                .setRepo("repo")
                .setProperties(properties);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("properties is set for a boundary node");
        }
    }

    @Test
    public void validate_shouldErrorOnDeleteWithProperties() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.DELETE)
                .setBoundary(false)
                .setOriginal(original)
                .setProperties(properties);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("properties is set when action is delete");
        }
    }

    @Test
    public void validate_shouldErrorOnUpdateWithNullProperties() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.UPDATE)
                .setBoundary(false)
                .setOriginal(original);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("properties is null");
        }
    }

    @Test
    public void validate_shouldErrorOnCreateWithInvalidPropertiesKey() {
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("__invalid", true);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setProperties(properties);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("properties contains an invalid key: __invalid");
        }
    }

    @Test
    public void validate_shouldErrorOnCreateWithInvalidPropertiesValue() {
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", null);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setProperties(properties);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("properties contains an invalid value for key: testing");
        }
    }

    @Test
    public void validate_shouldErrorOnBoundaryWithHash() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(true)
                .setRepo("repo")
                .setHash("1234");
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("hash is set for a boundary node");
        }
    }

    @Test
    public void validate_shouldErrorOnDeleteWithHash() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.DELETE)
                .setBoundary(false)
                .setOriginal(original)
                .setHash("1234");
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("hash is set when action is delete");
        }
    }

    @Test
    public void validate_shouldErrorOnUpdateWithMissingHash() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.UPDATE)
                .setBoundary(false)
                .setOriginal(original)
                .setProperties(properties);
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("hash is null");
        }
    }

    @Test
    public void validate_shouldErrorOnUpdateWithInvalidHash() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.UPDATE)
                .setBoundary(false)
                .setOriginal(original)
                .setProperties(properties)
                .setHash("1234");
        try {
            commitNode.validate();
            fail("Should error");
        } catch (VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("hash is invalid");
        }
    }

    @Test
    public void validate_shouldWork() {
        HashMap<String, Object> original = new HashMap<>();
        original.put("testing", true);

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", false);

        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.UPDATE)
                .setBoundary(false)
                .setOriginal(original)
                .setProperties(properties)
                .setHash("7881f7d20b679b02880c181f544809957f6df383");

        commitNode.validate();
    }

    /**
     * equals
     */
    @Test
    public void equals_shouldReturnTrueWithSelf() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setProperties(new HashMap<String, Object>())
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        assertThat(commitNode.equals(commitNode)).isEqualTo(true);
    }

    @Test
    public void equals_shouldReturnFalseWithNull() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setProperties(new HashMap<String, Object>())
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        assertThat(commitNode.equals(null)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithDifferentClass() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setProperties(new HashMap<String, Object>())
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        assertThat(commitNode.equals(new Date())).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithDifferentCommitEdge() {
        CommitNode commitNode1 = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setProperties(new HashMap<String, Object>())
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        CommitNode commitNode2 = new CommitNode()
                .setId("9cea5fbe-1ffd-4ef7-b08b-40d278bbb0f9")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setProperties(new HashMap<String, Object>())
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        assertThat(commitNode1.equals(commitNode2)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnTrueWithSameCommitEdge() {
        CommitNode commitNode1 = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setProperties(new HashMap<String, Object>())
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        CommitNode commitNode2 = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setProperties(new HashMap<String, Object>())
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        assertThat(commitNode1.equals(commitNode2)).isEqualTo(true);
        assertThat(commitNode2.equals(commitNode1)).isEqualTo(true);
    }

    @Test
    public void equals_shouldReturnFalseWithNullId() {
        CommitNode commitNode1 = new CommitNode();
        CommitNode commitNode2 = new CommitNode();

        assertThat(commitNode1.equals(commitNode2)).isEqualTo(false);
    }

    /**
     * hashCode
     */
    @Test
    public void hashCode_shouldReturnSameHashCodeAsID() {
        CommitNode commitNode = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setProperties(new HashMap<String, Object>())
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        assertThat(commitNode.hashCode()).isEqualTo(commitNode.getId().hashCode());
    }

    @Test
    public void hashCode_shouldNotFailOnNullId() {
        CommitNode commitNode = new CommitNode();

        assertThat(commitNode.hashCode()).isNotNull();
    }

}

# GPG
For some good info on working with GPG Signatures, see the [sonatype guide](http://central.sonatype.org/pages/working-with-pgp-signatures.html).

# Requirements

Make sure you have a key generated and available
````bash
~$ gpg --list-keys
/Users/johnclark/.gnupg/pubring.gpg
-----------------------------------
pub   2048R/BC4AD62B 2014-09-27
uid                  John Clark (Trepo Central Repository Key) <socrates37@gmail.com>
sub   2048R/7222D217 2014-09-27

~$ gpg --list-secret-keys
/Users/johnclark/.gnupg/secring.gpg
-----------------------------------
sec   2048R/BC4AD62B 2014-09-27
uid                  John Clark (Trepo Central Repository Key) <socrates37@gmail.com>
ssb   2048R/7222D217 2014-09-27
````


You need to have the gpg-agent running.
````bash
~$ gpg-agent
gpg-agent: gpg-agent running and available
````

# Mac Setup

Install GnuPG
````bash
brew install gpg gpg-agent
````

Add following to `~/.profile` to automatically start gpg-agent
````bash
eval $(gpg-agent --daemon --no-grab --write-env-file $HOME/.gpg-agent-info)
export GPG_TTY=$(tty)
export GPG_AGENT_INFO
````

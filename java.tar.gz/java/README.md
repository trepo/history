Java specific documentation for developing Trepo

# Sonatype
All of the relevant information is [here](sonatype.md).

# POM requirements
See documentation [here](pom.md).

# GPG setup
See documentation [here](gpg.md).

# Settings.xml
See documentation [here](settings.md).

# Checkstyle.xml
Here is the [checkstyle file](checkstyle.xml).

# Deployment
If everything is setup correctly, you just need to:

1. Make sure all tests pass, code coverage is met, checkstyle has no major issues, and everything is committed
1. Update the version in `pom.xml` and `README.md` and commit. The message should be the raw version number, `0.1.0`
1. Tagging this as a release in github. The tag syntax is `v0.1.0` and the message should be short and to the point
1. Deploy using `mvn clean deploy -P release`
1. Change the version in `pom.xml` to SNAPSHOT to prep for the next release.

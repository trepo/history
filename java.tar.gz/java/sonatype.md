# Overview
All of Trepo's java components are published to [Maven Central](http://search.maven.org/) using [Sonatype's Open Source Software Repository Hosting](http://central.sonatype.org/pages/producers.html)

# Guide
I followed the [OSSRH Guide](http://central.sonatype.org/pages/ossrh-guide.html).

## Initial Setup

### Sonatype ticket
The main JIRA account is under [jonnymbgood](https://issues.sonatype.org/secure/ViewProfile.jspa?name=jonnymbgood).
The initial JIRA was created [here](https://issues.sonatype.org/browse/OSSRH-11495).
The Coordinates registered were `com.github.trepo`.

### Requirements
I followed the requirements found [here](http://central.sonatype.org/pages/requirements.html).
The Trepo version of the POM components required is [here](pom.md).

### Deployment/Release
I use a maven commandline deployment/release as specified [here](http://central.sonatype.org/pages/apache-maven.html). See the [README](README.md) for actual deployment steps.

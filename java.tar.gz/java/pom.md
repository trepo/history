# POM
Here are the components for a basic POM file.

# Metadata
The groupId MUST be `com.github.trepo`. Make sure to replace `[[repo]]` with the actual repository name!

````xml
<groupId>com.github.trepo</groupId>
<artifactId></artifactId>
<version></version>
<packaging>jar</packaging>
<name></name>
<description></description>
<url>https://github.com/trepo/[[repo]]</url>
<licenses>
    <license>
        <name>MIT License</name>
        <url>http://www.opensource.org/licenses/mit-license.php</url>
    </license>
</licenses>
<developers>
    <developer>
        <name>John Clark</name>
        <email>socrates37@gmail.com</email>
    </developer>
</developers>
<scm>
    <connection>scm:git:git@github.com:trepo/[[repo]].git</connection>
    <developerConnection>scm:git:git@github.com:trepo/[[repo]].git</developerConnection>
    <url>git@github.com:trepo/[[repo]].git</url>
</scm>
````

# Properties

````xml
<properties>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    <maven.compiler.source>1.7</maven.compiler.source>
    <maven.compiler.target>1.7</maven.compiler.target>
</properties>
````

# Dependencies
Make sure to document WHY you included something.
````xml
<!-- Blueprints -->
<dependency>
    <groupId>com.tinkerpop.blueprints</groupId>
    <artifactId>blueprints-core</artifactId>
    <version>2.6.0</version>
</dependency>
````

If there are dependencies for testing, make sure to scope them accordingly!
````xml
<!-- Testing -->
<dependency>
    <groupId>org.testng</groupId>
    <artifactId>testng</artifactId>
    <version>6.8.8</version>
    <scope>test</scope>
</dependency>
````

# Profiles
If you don't want to autorelease after a deploy, make sure to set `autoReleaseAfterClose` to `false`.

````xml
<profiles>
    <profile>
        <id>release</id>
        <distributionManagement>
            <snapshotRepository>
                <id>ossrh</id>
                <url>https://oss.sonatype.org/content/repositories/snapshots</url>
            </snapshotRepository>
        </distributionManagement>
        <build>
            <plugins>
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-source-plugin</artifactId>
                    <version>2.2.1</version>
                    <executions>
                        <execution>
                            <id>attach-sources</id>
                            <goals>
                                <goal>jar-no-fork</goal>
                            </goals>
                        </execution>
                    </executions>
                </plugin>
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-javadoc-plugin</artifactId>
                    <version>2.9.1</version>
                    <executions>
                        <execution>
                            <id>attach-javadocs</id>
                            <goals>
                                <goal>jar</goal>
                            </goals>
                        </execution>
                    </executions>
                </plugin>
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-gpg-plugin</artifactId>
                    <version>1.5</version>
                    <executions>
                        <execution>
                            <id>sign-artifacts</id>
                            <phase>verify</phase>
                            <goals>
                                <goal>sign</goal>
                            </goals>
                        </execution>
                    </executions>
                </plugin>
                <plugin>
                    <groupId>org.sonatype.plugins</groupId>
                    <artifactId>nexus-staging-maven-plugin</artifactId>
                    <version>1.6.3</version>
                    <extensions>true</extensions>
                    <configuration>
                        <serverId>ossrh</serverId>
                        <nexusUrl>https://oss.sonatype.org/</nexusUrl>
                        <autoReleaseAfterClose>true</autoReleaseAfterClose>
                    </configuration>
                </plugin>
            </plugins>
        </build>
</profile>
</profiles>
````

# Maven settings.xml

# Servers
Make sure to put the somatype jira password in.

````xml
<server>
  <id>ossrh</id>
  <username>jonnymbgood</username>
  <password>[[password]]</password>
</server>
````

# Plugin Groups

````xml
<pluginGroups>
  <pluginGroup>org.sonatype.plugins</pluginGroup>
</pluginGroups>
````

# Profiles
// TODO move the relase profile to settings.xml

````xml
<profiles>
  <profile>
    <id>gpg</id>
    <properties>
      <gpg.useagent>true</gpg.useagent>        
    </properties>
  </profile>
</profiles>
````

# Active Profiles

````xml
<activeProfiles>
  <activeProfile>gpg</activeProfile>
</activeProfiles>
````

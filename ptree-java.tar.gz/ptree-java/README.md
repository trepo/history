# pTree
A Java implementation of [pTree](https://github.com/trepo/ptree).

# Usage
````java
// TODO
````

# Maven
Hosted on [Maven Central](http://search.maven.org/#search%7Cga%7C1%7Ca%3A%22ptree%22).

````xml
<dependency>
  <groupId>com.github.trepo</groupId>
  <artifactId>ptree</artifactId>
  <version>0.1.0</version>
</dependency>
````

# Javadoc
Viewable online [here](http://www.javadoc.io/doc/com.github.trepo/ptree). Many thanks to [javadoc.io](http://www.javadoc.io) for the hosting.

# Tests
There is comprehensive unit tests available by running `mvn test`.
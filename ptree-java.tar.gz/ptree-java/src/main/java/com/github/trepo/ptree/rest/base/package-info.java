/**
 * The base class that all REST classes extend.
 * @author John Clark.
 */
package com.github.trepo.ptree.rest.base;

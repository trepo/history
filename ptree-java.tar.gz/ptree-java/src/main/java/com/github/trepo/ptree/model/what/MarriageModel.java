package com.github.trepo.ptree.model.what;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.base.ReadableModel;
import com.github.trepo.ptree.model.base.WritableModel;
import com.github.trepo.ptree.model.core.DateModel;
import com.github.trepo.ptree.model.core.PersonModel;
import com.github.trepo.ptree.model.core.PlaceModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

import java.util.HashSet;
import java.util.Set;

/**
 * @author John Clark.
 */
public class MarriageModel extends BaseModel implements ReadableModel, WritableModel {

    /**
     * The person.
     */
    private Set<PersonModel> spouses;

    /**
     * The Date.
     */
    private DateModel date;

    /**
     * The Place.
     */
    private PlaceModel place;

    /**
     * Create a new Marriage model.
     * @param graph The vGraph instance.
     */
    public MarriageModel(VGraph graph) {
        super(graph);
    }

    /**
     * Create a new Marriage model.
     * @param graph The vGraph instance.
     * @param id the marriage's id.
     */
    public MarriageModel(VGraph graph, String id) {
        super(graph, id);
    }

    @Override
    public void readFromGraph() {
        Node node = getNode(Label.MARRIAGE);

        setBoundary(node.isBoundary());
        setRepo(node.getRepo());

        // Load spouses
        spouses = new HashSet<>();
        for (Edge spouse: node.getEdges(Direction.IN, Label.MARRIAGE_SPOUSE_REF)) {
            PersonModel model = new PersonModel(getGraph(), spouse.getNode(Direction.OUT).getId());
            model.readFromGraph();
            spouses.add(model);
        }

        Edge edge;

        // Load date
        edge = getEdge(node, Direction.OUT, Label.MARRIAGE_DATE_REF);
        if (edge != null) {
            date = new DateModel(getGraph(), edge.getNode(Direction.IN).getId());
            date.readFromGraph();
        }

        // Load place
        edge = getEdge(node, Direction.OUT, Label.MARRIAGE_PLACE_REF);
        if (edge != null) {
            place = new PlaceModel(getGraph(), edge.getNode(Direction.IN).getId());
            place.readFromGraph();
        }
    }

    @Override
    public void writeToGraph(Request request) {
        request.execute(this);
    }

    /**
     * Get the spouses.
     * @return The spouses.
     */
    public Set<PersonModel> getPerson() {
        return spouses;
    }

    public DateModel getDate() {
        return date;
    }

    public PlaceModel getPlace() {
        return place;
    }
}

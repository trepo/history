package com.github.trepo.ptree.rest.core;

import com.github.trepo.ptree.model.core.EdgeModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.ptree.rest.base.Base;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Get an Edge.
 * @author John Clark.
 */
@Path("/_edge/{id}")
public class Edge extends Base {

    /**
     * Gets an edge.
     * @param id The Edge's id.
     * @return The Edge, or 404.
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(@PathParam("id") String id) {

        try {
            EdgeModel edgeModel = new EdgeModel(getGraph(), id);
            edgeModel.readFromGraph();

            return Response
                    .status(Response.Status.OK)
                    .entity(edgeModel)
                    .build();

        } catch (NotFoundModelException e) {
            throw new WebApplicationException("Edge not found", e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }
}

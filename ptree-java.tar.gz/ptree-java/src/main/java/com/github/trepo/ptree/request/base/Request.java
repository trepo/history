package com.github.trepo.ptree.request.base;

import com.github.trepo.ptree.model.base.BaseModel;

/**
 * @author John Clark.
 */
public interface Request {

    public void execute(BaseModel model);
}

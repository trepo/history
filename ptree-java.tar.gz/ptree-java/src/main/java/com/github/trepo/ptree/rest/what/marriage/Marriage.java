package com.github.trepo.ptree.rest.what.marriage;

import com.github.trepo.ptree.model.exception.InvalidModelException;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.ptree.model.what.MarriageModel;
import com.github.trepo.ptree.request.what.marriage.MarriageDeleteRequest;
import com.github.trepo.ptree.request.what.marriage.MarriageWriteRequest;
import com.github.trepo.ptree.rest.base.Base;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author John Clark.
 */
@Path("/marriage")
public class Marriage extends Base {

    /**
     * Create a marriage.
     * @param request The marriage request.
     * @return 201.
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response post(MarriageWriteRequest request) {

        try {
            request.validate();
        } catch (ModelException e) {
            throw new WebApplicationException("Invalid request: " + e.getMessage(), e,
                    Response.Status.BAD_REQUEST);
        }

        try {
            MarriageModel model = new MarriageModel(getGraph());
            model.writeToGraph(request);
            model.readFromGraph();

            return Response
                    .status(Response.Status.CREATED)
                    .entity(model)
                    .build();
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get the marriage.
     * @param id The marriage id.
     * @return The marriage.
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getId(@PathParam("id") String id) {
        try {
            MarriageModel model = new MarriageModel(getGraph(), id);
            model.readFromGraph();

            return Response
                    .status(Response.Status.OK)
                    .entity(model)
                    .build();
        } catch (NotFoundModelException | InvalidModelException e) {
            throw new WebApplicationException("Marriage Not Found: " + e.getMessage(), e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Update the marriage.
     * @param id The marriage id.
     * @param request The marriage request.
     * @return The marriage.
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response putId(@PathParam("id") String id, MarriageWriteRequest request) {
        try {
            request.validate();
        } catch (ModelException e) {
            throw new WebApplicationException("Invalid request: " + e.getMessage(), e,
                    Response.Status.BAD_REQUEST);
        }

        try {
            MarriageModel model = new MarriageModel(getGraph(), id);
            model.writeToGraph(request);
            model.readFromGraph();

            return Response
                    .status(Response.Status.OK)
                    .entity(model)
                    .build();
        } catch (NotFoundModelException | InvalidModelException e) {
            e.printStackTrace();
            throw new WebApplicationException("Marriage Not Found: " + e.getMessage(), e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Delete a marriage.
     * @param id The marriage id.
     * @return 204.
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteId(@PathParam("id") String id) {
        try {
            MarriageModel model = new MarriageModel(getGraph(), id);
            model.writeToGraph(new MarriageDeleteRequest());

            return Response
                    .status(Response.Status.NO_CONTENT)
                    .build();
        } catch (NotFoundModelException | InvalidModelException e) {
            throw new WebApplicationException("Marriage Not Found: " + e.getMessage(), e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }
}

package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.base.ReadableModel;
import com.github.trepo.ptree.model.what.BirthModel;
import com.github.trepo.ptree.model.what.DeathModel;
import com.github.trepo.ptree.model.what.MarriageModel;
import com.github.trepo.ptree.model.what.NameModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * @author John Clark.
 */
public class PersonWhatModel extends BaseModel implements ReadableModel {

    private HashMap<String, ArrayList<BaseModel>> what = new HashMap<>();

    /**
     * Create a person instance.
     * @param graph Our vGraph instance.
     */
    public PersonWhatModel(VGraph graph) {
        super(graph);
    }

    /**
     * Create a person instance.
     * @param graph Our vGraph instance.
     * @param id Our person's id.
     */
    public PersonWhatModel(VGraph graph, String id) {
        super(graph, id);
    }

    /**
     * Read from the graph and load up data.
     */
    @Override
    public void readFromGraph() {
        Node person = getNode(Label.PERSON);

        setBoundary(person.isBoundary());
        setRepo(person.getRepo());

        for (Edge edge: person.getEdges(Direction.OUT)) {
            switch(edge.getNode(Direction.IN).getLabel()) {
                case Label.NAME:
                    if (!what.containsKey(Label.NAME)) {
                        what.put(Label.NAME, new ArrayList<BaseModel>());
                    }
                    NameModel nameModel = new NameModel(getGraph(), edge.getNode(Direction.IN).getId());
                    nameModel.readFromGraph();
                    what.get(Label.NAME).add(nameModel);
                    break;
                case Label.BIRTH:
                    if (!what.containsKey(Label.BIRTH)) {
                        what.put(Label.BIRTH, new ArrayList<BaseModel>());
                    }
                    BirthModel birthModel = new BirthModel(getGraph(), edge.getNode(Direction.IN).getId());
                    birthModel.readFromGraph();
                    what.get(Label.BIRTH).add(birthModel);
                    break;
                case Label.DEATH:
                    if (!what.containsKey(Label.DEATH)) {
                        what.put(Label.DEATH, new ArrayList<BaseModel>());
                    }
                    DeathModel deathModel = new DeathModel(getGraph(), edge.getNode(Direction.IN).getId());
                    deathModel.readFromGraph();
                    what.get(Label.DEATH).add(deathModel);
                    break;
                case Label.MARRIAGE:
                    if (!what.containsKey(Label.MARRIAGE)) {
                        what.put(Label.MARRIAGE, new ArrayList<BaseModel>());
                    }
                    MarriageModel marriageModel = new MarriageModel(getGraph(), edge.getNode(Direction.IN).getId());
                    marriageModel.readFromGraph();
                    what.get(Label.MARRIAGE).add(marriageModel);
                    break;
                // TODO default case should call the generic what accessor
            }
        }
    }
}

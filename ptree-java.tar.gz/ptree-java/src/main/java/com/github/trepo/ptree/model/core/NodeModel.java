package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.base.ReadableModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.vgraph.VGraph;

import java.util.HashMap;

/**
 * @author John Clark.
 */
public class NodeModel implements ReadableModel {

    /**
     * Our vGraph instance.
     * This is transient to avoid serialization/de-serialization.
     */
    private transient VGraph graph;

    /**
     * The root node's id.
     */
    private String id;

    /**
     * Our node's label.
     */
    private String label;

    /**
     * If our person is a boundary.
     */
    private Boolean boundary;

    /**
     * This node's repository.
     */
    private String repo;

    /**
     * Our properties.
     * This is only set if our node is not a boundary.
     */
    private HashMap<String, Object> properties;

    /**
     * Initialize a new node.
     * @param graphInstance The graph to use.
     * @param idInstance The node's ID.
     */
    public NodeModel(VGraph graphInstance, String idInstance) {
        if (graphInstance == null) {
            throw new ModelException("Graph is null");
        }
        if (idInstance == null) {
            throw new ModelException("id is null");
        }
        graph = graphInstance;
        id = idInstance;
    }

    @Override
    public void readFromGraph() {
        com.github.trepo.vgraph.Node node = graph.getNode(id);
        if (node == null) {
            throw new NotFoundModelException("Cannot find Node");
        }
        label = node.getLabel();
        repo = node.getRepo();
        boundary = node.isBoundary();
        if (!boundary) {
            properties = new HashMap<>();
            for (String key : node.getPropertyKeys()) {
                properties.put(key, node.getProperty(key));
            }
        }
    }

    /**
     * Get the model's id.
     * @return The id.
     */
    public String getId() {
        return id;
    }

    /**
     * Gets this node's label.
     * @return The label.
     */
    public String getLabel() {
        return label;
    }

    /**
     * If this person is a boundary node.
     * @return True if this is a boundary node.
     */
    public Boolean getBoundary() {
        return boundary;
    }

    /**
     * Gets this person's repository.
     * @return The person's repository.
     */
    public String getRepo() {
        return repo;
    }

    /**
     * Gets this node's properties.
     * @return The properties, or null if this is a boundary node.
     */
    public HashMap<String, Object> getProperties() {
        return properties;
    }

}

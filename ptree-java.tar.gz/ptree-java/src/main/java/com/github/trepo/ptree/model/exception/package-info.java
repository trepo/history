/**
 * custom Model Exception.
 * @author John Clark.
 */
package com.github.trepo.ptree.model.exception;

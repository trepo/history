package com.github.trepo.ptree.request.core;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Node;

/**
 * @author John Clark.
 */
public class PlaceWriteRequest implements Request {

    /**
     * The name.
     */
    private String name;

    /**
     * Create a new PlaceRequestModel.
     * @param name The name.
     */
    public PlaceWriteRequest(String name) {
        this.name = name;
    }

    public void validate() {
        if (name == null) {
            throw new ModelException("name may not be null");
        }
    }

    /**
     * Gets the name.
     * @return The name.
     */
    public String getName() {
        return name;
    }

    @Override
    public void execute(BaseModel model) {
        Node node = model.getOrCreateNode(Label.PLACE);

        model.setOrRemoveProperty(node, Key.PLACE_NAME, name);
    }
}

package com.github.trepo.ptree.ref;

/**
 * @author John Clark.
 */
public final class Key {

    public static final String DATE_FORMAL = "formal";
    public static final String DATE_ORIGINAL = "original";
    public static final String NAME_NAME = "name";
    public static final String PLACE_NAME = "name";

    private Key() {

    }
}

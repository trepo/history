package com.github.trepo.ptree.ref;

/**
 * @author John Clark.
 */
public final class Label {

    public static final String DATE = "Date";
    public static final String NAME = "Name";
    public static final String NAME_PERSON_REF = "Name_Person_Ref";
    public static final String PERSON = "Person";
    public static final String PLACE = "Place";
    public static final String BIRTH = "Birth";
    public static final String BIRTH_CHILD_REF = "Birth_Child_Ref";
    public static final String BIRTH_MOTHER_REF = "Birth_Mother_Ref";
    public static final String BIRTH_FATHER_REF = "Birth_Father_Ref";
    public static final String BIRTH_DATE_REF = "Birth_Date_Ref";
    public static final String BIRTH_PLACE_REF = "Birth_Place_Ref";
    public static final String DEATH = "Death";
    public static final String DEATH_PERSON_REF = "Death_Person_Ref";
    public static final String DEATH_DATE_REF = "Death_Date_Ref";
    public static final String DEATH_PLACE_REF = "Death_Place_Ref";
    public static final String MARRIAGE = "Marriage";
    public static final String MARRIAGE_SPOUSE_REF = "Marriage_Spouse_Ref";
    public static final String MARRIAGE_DATE_REF = "Marriage_Date_Ref";
    public static final String MARRIAGE_PLACE_REF = "Marriage_Place_Ref";

    private Label() {

    }
}

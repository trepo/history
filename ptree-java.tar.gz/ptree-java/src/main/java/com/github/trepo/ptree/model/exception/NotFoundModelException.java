package com.github.trepo.ptree.model.exception;

/**
 * When the base node of the model cannot be found.
 * @author John Clark.
 */
public class NotFoundModelException extends ModelException {

    /**
     * Create a new Exception.
     * @param message The message.
     */
    public NotFoundModelException(String message) {
        super(message);
    }

    /**
     * Create a new Exception.
     * @param message The message.
     * @param e The wrapped exception.
     */
    public NotFoundModelException(String message, Exception e) {
        super(message, e);
    }
}

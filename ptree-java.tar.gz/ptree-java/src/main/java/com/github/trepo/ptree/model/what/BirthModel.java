package com.github.trepo.ptree.model.what;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.base.ReadableModel;
import com.github.trepo.ptree.model.base.WritableModel;
import com.github.trepo.ptree.model.core.DateModel;
import com.github.trepo.ptree.model.core.PersonModel;
import com.github.trepo.ptree.model.core.PlaceModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

/**
 * @author John Clark.
 */
public class BirthModel extends BaseModel implements ReadableModel, WritableModel {

    /**
     * The Child.
     */
    private PersonModel child;

    /**
     * The Mother.
     */
    private PersonModel mother;

    /**
     * The Father.
     */
    private PersonModel father;

    /**
     * The Date.
     */
    private DateModel date;

    /**
     * The Place.
     */
    private PlaceModel place;

    /**
     * Create a new Birth model.
     * @param graph The vGraph instance.
     */
    public BirthModel(VGraph graph) {
        super(graph);
    }

    /**
     * Create a new Birth model.
     * @param graph The vGraph instance.
     * @param id the birth's id.
     */
    public BirthModel(VGraph graph, String id) {
        super(graph, id);
    }

    @Override
    public void readFromGraph() {
        Node node = getNode(Label.BIRTH);

        setBoundary(node.isBoundary());
        setRepo(node.getRepo());

        Edge edge;

        // Load child
        edge = getEdge(node, Direction.IN, Label.BIRTH_CHILD_REF);
        if (edge != null) {
            child = new PersonModel(getGraph(), edge.getNode(Direction.OUT).getId());
            child.readFromGraph();
        }

        // Load mother
        edge = getEdge(node, Direction.IN, Label.BIRTH_MOTHER_REF);
        if (edge != null) {
            mother = new PersonModel(getGraph(), edge.getNode(Direction.OUT).getId());
            mother.readFromGraph();
        }

        // Load father
        edge = getEdge(node, Direction.IN, Label.BIRTH_FATHER_REF);
        if (edge != null) {
            father = new PersonModel(getGraph(), edge.getNode(Direction.OUT).getId());
            father.readFromGraph();
        }

        // Load date
        edge = getEdge(node, Direction.OUT, Label.BIRTH_DATE_REF);
        if (edge != null) {
            date = new DateModel(getGraph(), edge.getNode(Direction.IN).getId());
            date.readFromGraph();
        }

        // Load place
        edge = getEdge(node, Direction.OUT, Label.BIRTH_PLACE_REF);
        if (edge != null) {
            place = new PlaceModel(getGraph(), edge.getNode(Direction.IN).getId());
            place.readFromGraph();
        }
    }

    @Override
    public void writeToGraph(Request request) {
        request.execute(this);
    }

    public PersonModel getChild() {
        return child;
    }

    public PersonModel getMother() {
        return mother;
    }

    public PersonModel getFather() {
        return father;
    }

    public DateModel getDate() {
        return date;
    }

    public PlaceModel getPlace() {
        return place;
    }

}

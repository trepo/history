package com.github.trepo.ptree.model.base;

import com.github.trepo.ptree.model.exception.InvalidModelException;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Element;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

import java.util.Iterator;

/**
 * Our base model that all other models extend.
 * @author John Clark.
 */
public abstract class BaseModel {

    /**
     * Our vGraph instance.
     * This is transient to avoid serialization/de-serialization.
     */
    private transient VGraph graph;

    /**
     * The root node's id.
     */
    private String id;

    /**
     * If our person is a boundary.
     */
    private Boolean boundary;

    /**
     * This node's repository.
     */
    private String repo;

    /**
     * Create an instance.
     * @param graphInstance Our vGraph instance.
     */
    public BaseModel(VGraph graphInstance) {
        if (graphInstance == null) {
            throw new ModelException("Graph is null");
        }
        graph = graphInstance;
        id = null;
    }

    /**
     * Create an instance.
     * @param graphInstance Our vGraph instance.
     * @param idInstance Our root id.
     */
    public BaseModel(VGraph graphInstance, String idInstance) {
        if (graphInstance == null) {
            throw new ModelException("Graph is null");
        }
        if (idInstance == null) {
            throw new ModelException("id is null");
        }
        graph = graphInstance;
        id = idInstance;
    }

    /**
     * Get our graph.
     * @return Our vGraph instance.
     */
    public VGraph getGraph() {
        return graph;
    }

    /**
     * Gets the vGraph root node and validates it.
     * @param label The label the node should have.
     * @return The node.
     */
    public Node getNode(String label) {
        if (id == null) {
            throw new ModelException("Cannot read from graph: missing id");
        }

        return getNode(id, label);
    }

    /**
     * Gets a node and validates the label.
     * @param nodeId The node id.
     * @param label The label.
     * @return The node (or throws exception).
     */
    public Node getNode(String nodeId, String label) {
        Node node = graph.getNode(nodeId);

        if (node == null) {
            throw new NotFoundModelException("node not found");
        }

        if (!node.getLabel().equals(label)) {
            throw new InvalidModelException("invalid label: expected " + label + " but found " + node.getLabel());
        }

        return node;
    }

    /**
     * Creates a new node and sets this.id to the node's id.
     * @param label The new node's label.
     * @return The created node.
     */
    public Node createNode(String label) {
        if (id != null) {
            throw new ModelException("You may not overwrite id");
        }
        Node node = graph.addNode(label);
        id = node.getId();
        return node;
    }

    /**
     * Gets or creates the root node.
     * @param label The node's label.
     * @return The node.
     */
    public Node getOrCreateNode(String label) {
        if (id == null) {
            return createNode(label);
        } else {
            return getNode(label);
        }
    }

    /**
     * Get the model's id.
     * @return The id.
     */
    public String getId() {
        return id;
    }

    /**
     * Set id if it is not already set.
     * @param newId The new id.
     */
    public void setId(String newId) {
        if (id != null) {
            throw new ModelException("You may not overwrite id");
        }
        id = newId;
    }

    /**
     * If this person is a boundary node.
     * @return True if this is a boundary node.
     */
    public Boolean getBoundary() {
        return boundary;
    }

    /**
     * Set boundary.
     * @param newBoundary The boundary.
     */
    public void setBoundary(Boolean newBoundary) {
        boundary = newBoundary;
    }

    /**
     * Gets this person's repository.
     * @return The person's repository.
     */
    public String getRepo() {
        return repo;
    }

    /**
     * Set the repo.
     * @param newRepo the repo.
     */
    public void setRepo(String newRepo) {
        repo = newRepo;
    }

    /**
     * Get a property from vGraph.
     * @param element The element to get the property from.
     * @param key The property key.
     * @param type The requested type.
     * @param <T> The requested type.
     * @return The property, cast as type.
     */
    public <T> T getProperty(Element element, String key, Class<T> type) {
        Object o = element.getProperty(key);
        if (o == null) {
            return null;
        } else {
            return type.cast(o);
        }
    }

    /**
     * If value is null, remove the property. Otherwise set the property key to value.
     * @param node The node to set the value on.
     * @param key The property key.
     * @param value The property value.
     */
    public void setOrRemoveProperty(Node node, String key, Object value) {
        if (value == null) {
            node.removeProperty(key);
        } else {
            node.setProperty(key, value);
        }
    }

    /**
     * Get the first edge that matches the direction and label.
     * @param node The node to retrieve the edge from.
     * @param direction The direction the edge must be.
     * @param label The edge label.
     * @return The edge, or null.
     */
    public Edge getEdge(Node node, Direction direction, String label) {
        Iterator<Edge> itr = node.getEdges(direction, label).iterator();
        if (itr.hasNext()) {
            return itr.next();
        } else {
            return null;
        }
    }

    @Override
    public boolean equals(Object obj) {
        if (obj instanceof BaseModel && id != null) {
            return id.equals(((BaseModel) obj).id);
        }
        return super.equals(obj);
    }

    @Override
    public int hashCode() {
        if (id == null) {
            return super.hashCode();
        } else {
            return id.hashCode();
        }
    }
}

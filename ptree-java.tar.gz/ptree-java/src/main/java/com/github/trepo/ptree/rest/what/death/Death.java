package com.github.trepo.ptree.rest.what.death;

import com.github.trepo.ptree.model.exception.InvalidModelException;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.ptree.model.what.DeathModel;
import com.github.trepo.ptree.request.what.death.DeathDeleteRequest;
import com.github.trepo.ptree.request.what.death.DeathWriteRequest;
import com.github.trepo.ptree.rest.base.Base;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author John Clark.
 */
@Path("/death")
public class Death extends Base {

    /**
     * Create a death.
     * @param request The death request.
     * @return 201.
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response post(DeathWriteRequest request) {

        try {
            request.validate();
        } catch (ModelException e) {
            throw new WebApplicationException("Invalid request: " + e.getMessage(), e,
                    Response.Status.BAD_REQUEST);
        }

        try {
            DeathModel model = new DeathModel(getGraph());
            model.writeToGraph(request);
            model.readFromGraph();

            return Response
                    .status(Response.Status.CREATED)
                    .entity(model)
                    .build();
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get the death.
     * @param id The death id.
     * @return The death.
     */
    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getId(@PathParam("id") String id) {
        try {
            DeathModel model = new DeathModel(getGraph(), id);
            model.readFromGraph();

            return Response
                    .status(Response.Status.OK)
                    .entity(model)
                    .build();
        } catch (NotFoundModelException | InvalidModelException e) {
            throw new WebApplicationException("Death Not Found: " + e.getMessage(), e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Update the death.
     * @param id The death id.
     * @param request The death request.
     * @return The death.
     */
    @PUT
    @Path("/{id}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response putId(@PathParam("id") String id, DeathWriteRequest request) {
        try {
            request.validate();
        } catch (ModelException e) {
            throw new WebApplicationException("Invalid request: " + e.getMessage(), e,
                    Response.Status.BAD_REQUEST);
        }

        try {
            DeathModel model = new DeathModel(getGraph(), id);
            model.writeToGraph(request);
            model.readFromGraph();

            return Response
                    .status(Response.Status.OK)
                    .entity(model)
                    .build();
        } catch (NotFoundModelException | InvalidModelException e) {
            e.printStackTrace();
            throw new WebApplicationException("Death Not Found: " + e.getMessage(), e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Delete a death.
     * @param id The death id.
     * @return 204.
     */
    @DELETE
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response deleteId(@PathParam("id") String id) {
        try {
            DeathModel model = new DeathModel(getGraph(), id);
            model.writeToGraph(new DeathDeleteRequest());

            return Response
                    .status(Response.Status.NO_CONTENT)
                    .build();
        } catch (NotFoundModelException | InvalidModelException e) {
            throw new WebApplicationException("Death Not Found: " + e.getMessage(), e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }
}

package com.github.trepo.ptree.request.what.birth;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

/**
 * @author John Clark.
 */
public class BirthDeleteRequest implements Request {
    @Override
    public void execute(BaseModel model) {
        VGraph graph = model.getGraph();
        Node node = model.getNode(Label.BIRTH);

        // Remove date if exists
        Edge dateEdge = model.getEdge(node, Direction.OUT, Label.BIRTH_DATE_REF);
        if (dateEdge != null) {
            graph.removeNode(dateEdge.getNode(Direction.IN).getId());
        }

        // Remove name if exists
        Edge placeEdge = model.getEdge(node, Direction.OUT, Label.BIRTH_PLACE_REF);
        if (placeEdge != null) {
            graph.removeNode(placeEdge.getNode(Direction.IN).getId());
        }

        // Remove marriage
        graph.removeNode(node.getId());
    }
}

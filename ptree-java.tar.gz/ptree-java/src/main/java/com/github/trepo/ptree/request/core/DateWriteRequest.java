package com.github.trepo.ptree.request.core;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Node;

/**
 * @author John Clark.
 */
public class DateWriteRequest implements Request {

    /**
     * The original date.
     */
    private String original;

    /**
     * The formal date.
     */
    private String formal;

    /**
     * Create a new DateRequestModel.
     * @param original The original date.
     * @param formal the formal date.
     */
    public DateWriteRequest(String original, String formal) {
        this.original = original;
        this.formal = formal;
    }

    /**
     * Validate this request.
     */
    public void validate() {

        if (original == null && formal == null) {
            throw new ModelException("You must have either a formal or original date");
        }

        // TODO validate formal date
    }

    @Override
    public void execute(BaseModel model) {

        Node node = model.getOrCreateNode(Label.DATE);

        model.setOrRemoveProperty(node, Key.DATE_FORMAL, formal);
        model.setOrRemoveProperty(node, Key.DATE_ORIGINAL, original);
    }

    /**
     * Get the original date.
     * @return The original date.
     */
    public String getOriginal() {
        return original;
    }

    /**
     * Get the formal date.
     * @return The formal date.
     */
    public String getFormal() {
        return formal;
    }
}

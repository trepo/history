package com.github.trepo.ptree.request.what.name;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;

/**
 * @author John Clark.
 */
public class NamePersonWriteRequest implements Request {

    /**
     * The person id to link to.
     */
    private String id;

    /**
     * Create a new NamePersonWriteRequest.
     * @param id The person id.
     */
    public NamePersonWriteRequest(String id) {
        this.id = id;
    }

    /**
     * Validate the request.
     */
    public void validate() {
        if (id == null) {
            throw new ModelException("id may not be null");
        }
    }

    @Override
    public void execute(BaseModel model) {
        Node name = model.getNode(Label.NAME);
        Node person = model.getNode(id, Label.PERSON);
        Edge edge = model.getEdge(name, Direction.IN, Label.NAME_PERSON_REF);

        // Deal with any existing association
        if (edge != null) {
            Node currentPerson = edge.getNode(Direction.OUT);
            if (currentPerson.getId().equals(id)) {
                return;
            } else {
                model.getGraph().removeEdge(edge.getId());
            }
        }

        person.addEdge(name, Label.NAME_PERSON_REF);
    }

    /**
     * Get the id.
     * @return The id.
     */
    public String getId() {
        return id;
    }
}

package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.base.ReadableModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.model.base.WritableModel;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

/**
 * A Person.
 * @author John Clark.
 */
public class PersonModel extends BaseModel implements ReadableModel, WritableModel {

    /**
     * Create a person instance.
     * @param graph Our vGraph instance.
     */
    public PersonModel(VGraph graph) {
        super(graph);
    }

    /**
     * Create a person instance.
     * @param graph Our vGraph instance.
     * @param id Our person's id.
     */
    public PersonModel(VGraph graph, String id) {
        super(graph, id);
    }

    @Override
    public void readFromGraph() {

        Node person = getNode(Label.PERSON);

        setBoundary(person.isBoundary());
        setRepo(person.getRepo());
    }

    @Override
    public void writeToGraph(Request request) {
        request.execute(this);
    }

}

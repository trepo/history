package com.github.trepo.ptree.request.what.death;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.core.DateModel;
import com.github.trepo.ptree.model.core.PlaceModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.ptree.request.core.DateDeleteRequest;
import com.github.trepo.ptree.request.core.DateWriteRequest;
import com.github.trepo.ptree.request.core.PlaceDeleteRequest;
import com.github.trepo.ptree.request.core.PlaceWriteRequest;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraph;

/**
 * @author John Clark.
 */
public class DeathWriteRequest implements Request {

    /**
     * The person id.
     */
    private String person;

    /**
     * The date.
     */
    private DateWriteRequest date;

    /**
     * The place.
     */
    private PlaceWriteRequest place;

    public DeathWriteRequest(String person, DateWriteRequest date, PlaceWriteRequest place) {
        this.person = person;
        this.date = date;
        this.place = place;
    }

    /**
     * validate this request.
     */
    public void validate() {
        if (person != null && !SpecialProperty.isValidId(person)) {
            throw new ModelException("person must be a valid id");
        }

        if (date != null) {
            date.validate();
        }
        if (place != null) {
            place.validate();
        }
    }

    @Override
    public void execute(BaseModel model) {
        VGraph graph = model.getGraph();

        // Get referenced person node (will error if missing)
        Node personNode = null;
        if (person != null) {
            personNode = model.getNode(person, Label.PERSON);
        }

        // Get/Create Death
        Node node = model.getOrCreateNode(Label.DEATH);

        // Get Edges
        Edge personEdge = model.getEdge(node, Direction.IN, Label.DEATH_PERSON_REF);
        Edge dateEdge = model.getEdge(node, Direction.OUT, Label.DEATH_DATE_REF);
        Edge placeEdge = model.getEdge(node, Direction.OUT, Label.DEATH_PLACE_REF);

        // Create Models
        DateModel dateModel;
        if (dateEdge != null) {
            dateModel = new DateModel(graph, dateEdge.getNode(Direction.IN).getId());
        } else {
            dateModel = new DateModel(graph);
        }
        PlaceModel placeModel;
        if (placeEdge != null) {
            placeModel = new PlaceModel(graph, placeEdge.getNode(Direction.IN).getId());
        } else {
            placeModel = new PlaceModel(graph);
        }

        // Add missing person edge
        if (personNode != null && personEdge == null) {
            personNode.addEdge(node, Label.DEATH_PERSON_REF);
        }

        // Remove unneeded person edges
        if (person == null && personEdge != null) {
            graph.removeEdge(personEdge.getId());
        }

        // Add/update nodes
        if (date != null) {
            date.execute(dateModel);
            if (dateEdge == null) {
                node.addEdge(dateModel.getNode(Label.DATE), Label.DEATH_DATE_REF);
            }
        }
        if (place != null) {
            place.execute(placeModel);
            if (placeEdge == null) {
                node.addEdge(placeModel.getNode(Label.PLACE), Label.DEATH_PLACE_REF);
            }
        }

        // Remove unneeded nodes
        if (date == null && dateEdge != null) {
            new DateDeleteRequest().execute(dateModel);
        }
        if (place == null && placeEdge != null) {
            new PlaceDeleteRequest().execute(placeModel);
        }
    }
}

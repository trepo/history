package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.base.ReadableModel;
import com.github.trepo.ptree.model.what.NameModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

/**
 * @author John Clark.
 */
public class PersonNameModel extends BaseModel implements ReadableModel {

    /**
     * The name model.
     */
    private NameModel name = null;

    /**
     * Create a person instance.
     * @param graph Our vGraph instance.
     * @param id Our person's id.
     */
    public PersonNameModel(VGraph graph, String id) {
        super(graph, id);
    }

    @Override
    public void readFromGraph() {

        Node person = getNode(Label.PERSON);

        setBoundary(person.isBoundary());
        setRepo(person.getRepo());

        for (Node node: person.getNodes(Direction.OUT, Label.NAME_PERSON_REF)) {
            name = new NameModel(getGraph(), node.getId());
            name.readFromGraph();
            break;
        }
    }

    /**
     * Get name.
     * @return The name.
     */
    public NameModel getName() {
        return name;
    }
}

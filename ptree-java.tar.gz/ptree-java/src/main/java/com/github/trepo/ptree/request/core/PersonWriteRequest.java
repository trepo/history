package com.github.trepo.ptree.request.core;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;

/**
 * @author John Clark.
 */
public class PersonWriteRequest implements Request {
    @Override
    public void execute(BaseModel model) {
        if (model.getId() == null) {
            model.createNode(Label.PERSON);
        }
    }
}

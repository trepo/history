package com.github.trepo.ptree.model.what;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.base.ReadableModel;
import com.github.trepo.ptree.model.base.WritableModel;
import com.github.trepo.ptree.model.core.PersonModel;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

/**
 * @author John Clark.
 */
public class NameModel extends BaseModel implements ReadableModel, WritableModel {

    /**
     * The name.
     */
    private String name;

    /**
     * The person.
     */
    private PersonModel person;

    /**
     * Create a new Name model.
     * @param graph The vGraph instance.
     */
    public NameModel(VGraph graph) {
        super(graph);
    }

    /**
     * Create a new Name model.
     * @param graph The vGraph instance.
     * @param id the name's id.
     */
    public NameModel(VGraph graph, String id) {
        super(graph, id);
    }

    @Override
    public void readFromGraph() {
        Node node = getNode(Label.NAME);

        setBoundary(node.isBoundary());
        setRepo(node.getRepo());

        name = getProperty(node, Key.NAME_NAME, String.class);

        // Load person
        Edge edge = getEdge(node, Direction.IN, Label.NAME_PERSON_REF);

        if (edge != null) {
            person = new PersonModel(getGraph(), edge.getNode(Direction.OUT).getId());
            person.readFromGraph();
        }
    }

    @Override
    public void writeToGraph(Request request) {
        request.execute(this);
    }

    /**
     * Get the name.
     * @return The name.
     */
    public String getName() {
        return name;
    }

    /**
     * Get the person.
     * @return The person.
     */
    public PersonModel getPerson() {
        return person;
    }
}

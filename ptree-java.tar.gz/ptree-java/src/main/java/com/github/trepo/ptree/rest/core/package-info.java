/**
 * Our core REST endpoints.
 * @author John Clark.
 */
package com.github.trepo.ptree.rest.core;

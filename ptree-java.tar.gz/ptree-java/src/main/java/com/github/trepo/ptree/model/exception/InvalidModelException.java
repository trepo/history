package com.github.trepo.ptree.model.exception;

/**
 * When a model is invalid when read, validated, or to be written.
 * @author John Clark.
 */
public class InvalidModelException extends ModelException {

    /**
     * Create a new Exception.
     * @param message The message.
     */
    public InvalidModelException(String message) {
        super(message);
    }

    /**
     * Create a new Exception.
     * @param message The message.
     * @param e The wrapped exception.
     */
    public InvalidModelException(String message, Exception e) {
        super(message, e);
    }
}

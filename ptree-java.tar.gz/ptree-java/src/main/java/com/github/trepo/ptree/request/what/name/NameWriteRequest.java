package com.github.trepo.ptree.request.what.name;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraph;

/**
 * @author John Clark.
 */
public class NameWriteRequest implements Request {

    /**
     * The name.
     */
    private String name;

    /**
     * The person.
     */
    private String person;

    /**
     * Create a new NameWriteRequest.
     * @param name The name.
     */
    public NameWriteRequest(String name, String person) {
        this.name = name;
        this.person = person;
    }

    /**
     * validate this request.
     */
    public void validate() {
        if (name == null) {
            throw new ModelException("name may not be null");
        }

        if (person != null && !SpecialProperty.isValidId(person)) {
            throw new ModelException("person must be a valid id");
        }
    }

    @Override
    public void execute(BaseModel model) {
        VGraph graph = model.getGraph();

        // Get referenced person node (will error if missing)
        Node personNode = null;
        if (person != null) {
            personNode = model.getNode(person, Label.PERSON);
        }

        Node node = model.getOrCreateNode(Label.NAME);

        model.setOrRemoveProperty(node, Key.NAME_NAME, name);

        // Get Edges
        Edge personEdge = model.getEdge(node, Direction.IN, Label.NAME_PERSON_REF);

        // Add missing person edge
        if (personNode != null && personEdge == null) {
            personNode.addEdge(node, Label.DEATH_PERSON_REF);
        }

        // Remove unneeded person edges
        if (person == null && personEdge != null) {
            graph.removeEdge(personEdge.getId());
        }
    }

    /**
     * Get the name.
     * @return The name.
     */
    public String getName() {
        return name;
    }
}

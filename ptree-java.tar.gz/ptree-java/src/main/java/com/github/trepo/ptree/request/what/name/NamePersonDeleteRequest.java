package com.github.trepo.ptree.request.what.name;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;

/**
 * @author John Clark.
 */
public class NamePersonDeleteRequest implements Request {

    @Override
    public void execute(BaseModel model) {
        Node name = model.getNode(Label.NAME);
        Edge edge = model.getEdge(name, Direction.IN, Label.NAME_PERSON_REF);
        if (edge != null) {
            model.getGraph().removeEdge(edge.getId());
        }
    }
}

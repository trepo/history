/**
 * Base model and interfaces.
 * @author John Clark.
 */
package com.github.trepo.ptree.model.base;

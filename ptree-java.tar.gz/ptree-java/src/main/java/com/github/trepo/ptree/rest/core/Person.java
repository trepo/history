package com.github.trepo.ptree.rest.core;

import com.github.trepo.ptree.model.core.PersonWhatModel;
import com.github.trepo.ptree.request.core.PersonDeleteRequest;
import com.github.trepo.ptree.model.core.PersonModel;
import com.github.trepo.ptree.request.core.PersonWriteRequest;
import com.github.trepo.ptree.model.exception.InvalidModelException;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.ptree.rest.base.Base;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author John Clark.
 */
@Path("/person")
public class Person extends Base {

    /**
     * Create a new Person.
     * @return The new Person.
     */
    @POST
    @Produces(MediaType.APPLICATION_JSON)
    public Response post() {

        try {
            PersonModel personModel = new PersonModel(getGraph());
            personModel.writeToGraph(new PersonWriteRequest());
            personModel.readFromGraph();

            return Response
                    .status(Response.Status.CREATED)
                    .entity(personModel)
                    .build();

        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }

    }

    /**
     * Get a person.
     * @param id The person's id.
     * @return The person.
     */
    @GET @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(@PathParam("id") String id) {

        try {
            PersonModel personModel = new PersonModel(getGraph(), id);
            personModel.readFromGraph();

            return Response
                    .status(Response.Status.OK)
                    .entity(personModel)
                    .build();

        } catch (NotFoundModelException | InvalidModelException e) {
            throw new WebApplicationException("Person Not Found: " + e.getMessage(), e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }

    }

    /**
     * Delete a person.
     * @param id The id of the person to delete.
     * @return 204.
     */
    @DELETE @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response delete(@PathParam("id") String id) {
        try {
            PersonModel personModel = new PersonModel(getGraph(), id);
            personModel.writeToGraph(new PersonDeleteRequest());

            return Response
                    .status(Response.Status.NO_CONTENT)
                    .build();

        } catch (NotFoundModelException | InvalidModelException e) {
            throw new WebApplicationException("Person Not Found: " + e.getMessage(), e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Get all of the whats associated with the person.
     * @param id The person's id.
     * @return The person's whats.
     */
    @GET @Path("/{id}/_what")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getWhats(@PathParam("id") String id) {
        try {
            PersonWhatModel personWhatModel = new PersonWhatModel(getGraph(), id);
            personWhatModel.readFromGraph();

            return Response
                    .status(Response.Status.OK)
                    .entity(personWhatModel)
                    .build();

        } catch (NotFoundModelException | InvalidModelException e) {
            throw new WebApplicationException("Person Not Found: " + e.getMessage(), e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }
}

package com.github.trepo.ptree.model.base;

/**
 * A readable model.
 * @author John Clark.
 */
public interface ReadableModel {

    /**
     * Read from the graph and load up data.
     */
    void readFromGraph();

}

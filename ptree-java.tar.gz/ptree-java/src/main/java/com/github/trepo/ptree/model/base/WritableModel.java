package com.github.trepo.ptree.model.base;

import com.github.trepo.ptree.request.base.Request;

/**
 * A writable model.
 * @author John Clark.
 */
public interface WritableModel {

    /**
     * Save this model to the graph.
     * @param request The request model to apply.
     */
    void writeToGraph(Request request);

    //Commit writeToCommit(RequestModel models...);
}

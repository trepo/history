package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.base.ReadableModel;
import com.github.trepo.ptree.model.base.WritableModel;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

/**
 * @author John Clark.
 */
public class DateModel extends BaseModel implements ReadableModel, WritableModel {

    /**
     * The original date.
     */
    private String original;

    /**
     * The formal date.
     */
    private String formal;

    /**
     * Create a new Date model.
     * @param graph The vGraph instance.
     */
    public DateModel(VGraph graph) {
        super(graph);
    }

    /**
     * Create a new Date model.
     * @param graph The vGraph instance.
     * @param id the date's id.
     */
    public DateModel(VGraph graph, String id) {
        super(graph, id);
    }

    @Override
    public void readFromGraph() {

        Node node = getNode(Label.DATE);

        setBoundary(node.isBoundary());
        setRepo(node.getRepo());

        original = getProperty(node, Key.DATE_ORIGINAL, String.class);
        formal = getProperty(node, Key.DATE_FORMAL, String.class);
    }

    @Override
    public void writeToGraph(Request request) {
        request.execute(this);
    }

    /**
     * Get the original date.
     * @return The original date.
     */
    public String getOriginal() {
        return original;
    }

    /**
     * Get the formal date.
     * @return The formal date.
     */
    public String getFormal() {
        return formal;
    }
}

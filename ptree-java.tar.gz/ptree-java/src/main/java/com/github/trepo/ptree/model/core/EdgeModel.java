package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.base.ReadableModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.VGraph;

import java.util.HashMap;

/**
 * @author John Clark.
 */
public class EdgeModel implements ReadableModel {

    /**
     * Our vGraph instance.
     * This is transient to avoid serialization/de-serialization.
     */
    private transient VGraph graph;

    /**
     * The root node's id.
     */
    private String id;

    /**
     * Our node's label.
     */
    private String label;

    /**
     * Our properties.
     */
    private HashMap<String, Object> properties;

    /**
     * The node this edge comes from.
     */
    private NodeModel from;

    /**
     * The node this edge goes to.
     */
    private NodeModel to;


    /**
     * Initialize a new Edge.
     * @param graphInstance Our vGraph instance.
     * @param idInstance The edge's id.
     */
    public EdgeModel(VGraph graphInstance, String idInstance) {
        if (graphInstance == null) {
            throw new ModelException("Graph is null");
        }
        if (idInstance == null) {
            throw new ModelException("id is null");
        }
        graph = graphInstance;
        id = idInstance;
    }

    @Override
    public void readFromGraph() {
        com.github.trepo.vgraph.Edge edge = graph.getEdge(id);
        if (edge == null) {
            throw new NotFoundModelException("Cannot find Edge");
        }

        label = edge.getLabel();
        properties = new HashMap<>();
        for (String key: edge.getPropertyKeys()) {
            properties.put(key, edge.getProperty(key));
        }
        from = new NodeModel(graph, edge.getNode(Direction.OUT).getId());
        from.readFromGraph();
        to = new NodeModel(graph, edge.getNode(Direction.IN).getId());
        to.readFromGraph();
    }

    /**
     * Get the model's id.
     * @return The id.
     */
    public String getId() {
        return id;
    }

    /**
     * Get the edge's label.
     * @return The label.
     */
    public String getLabel() {
        return label;
    }

    /**
     * Get the edge's properties.
     * @return The properties.
     */
    public HashMap<String, Object> getProperties() {
        return properties;
    }

    /**
     * Get the edge's from Node.
     * @return The from node.
     */
    public NodeModel getFrom() {
        return from;
    }

    /**
     * Get the edge's to Node.
     * @return The to node.
     */
    public NodeModel getTo() {
        return to;
    }
}

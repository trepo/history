package com.github.trepo.ptree.model.what;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.base.ReadableModel;
import com.github.trepo.ptree.model.base.WritableModel;
import com.github.trepo.ptree.model.core.DateModel;
import com.github.trepo.ptree.model.core.PersonModel;
import com.github.trepo.ptree.model.core.PlaceModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

/**
 * @author John Clark.
 */
public class DeathModel extends BaseModel implements ReadableModel, WritableModel {

    /**
     * The person.
     */
    private PersonModel person;

    /**
     * The Date.
     */
    private DateModel date;

    /**
     * The Place.
     */
    private PlaceModel place;

    /**
     * Create a new Death model.
     * @param graph The vGraph instance.
     */
    public DeathModel(VGraph graph) {
        super(graph);
    }

    /**
     * Create a new Death model.
     * @param graph The vGraph instance.
     * @param id the name's id.
     */
    public DeathModel(VGraph graph, String id) {
        super(graph, id);
    }


    @Override
    public void readFromGraph() {
        Node node = getNode(Label.DEATH);

        setBoundary(node.isBoundary());
        setRepo(node.getRepo());

        Edge edge;

        // Load child
        edge = getEdge(node, Direction.IN, Label.DEATH_PERSON_REF);
        if (edge != null) {
            person = new PersonModel(getGraph(), edge.getNode(Direction.OUT).getId());
            person.readFromGraph();
        }

        // Load date
        edge = getEdge(node, Direction.OUT, Label.BIRTH_DATE_REF);
        if (edge != null) {
            date = new DateModel(getGraph(), edge.getNode(Direction.IN).getId());
            date.readFromGraph();
        }

        // Load place
        edge = getEdge(node, Direction.OUT, Label.BIRTH_PLACE_REF);
        if (edge != null) {
            place = new PlaceModel(getGraph(), edge.getNode(Direction.IN).getId());
            place.readFromGraph();
        }
    }

    @Override
    public void writeToGraph(Request request) {
        request.execute(this);
    }

    /**
     * Get the person.
     * @return The person.
     */
    public PersonModel getPerson() {
        return person;
    }

    public DateModel getDate() {
        return date;
    }

    public PlaceModel getPlace() {
        return place;
    }
}

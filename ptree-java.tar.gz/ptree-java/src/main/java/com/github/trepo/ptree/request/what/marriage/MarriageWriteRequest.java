package com.github.trepo.ptree.request.what.marriage;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.core.DateModel;
import com.github.trepo.ptree.model.core.PlaceModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.ptree.request.core.DateDeleteRequest;
import com.github.trepo.ptree.request.core.DateWriteRequest;
import com.github.trepo.ptree.request.core.PlaceDeleteRequest;
import com.github.trepo.ptree.request.core.PlaceWriteRequest;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

/**
 * @author John Clark.
 */
public class MarriageWriteRequest implements Request {

    /**
     * The spouse ids.
     */
    private List<String> spouses;

    /**
     * The date.
     */
    private DateWriteRequest date;

    /**
     * The place.
     */
    private PlaceWriteRequest place;

    public MarriageWriteRequest(List<String> spouses, DateWriteRequest date, PlaceWriteRequest place) {
        this.spouses = spouses;
        this.date = date;
        this.place = place;
    }

    /**
     * validate this request.
     */
    public void validate() {

        if (spouses != null) {
            for (String spouse : spouses) {
                // TODO expand on this error
                if (!SpecialProperty.isValidId(spouse)) {
                    throw new ModelException("spouse must be a valid id");
                }
            }
        }

        if (date != null) {
            date.validate();
        }
        if (place != null) {
            place.validate();
        }
    }

    @Override
    public void execute(BaseModel model) {
        VGraph graph = model.getGraph();

        // Create Spouses Set.
        HashSet<String> requestedSpouseIds = new HashSet<>();
        if (spouses != null) {
            requestedSpouseIds.addAll(spouses);
        }

        // Get spouse nodes (will error if missing)
        HashMap<String, Node> spouseNodes = new HashMap<>();
        for (String spouse: requestedSpouseIds) {
            spouseNodes.put(spouse, model.getNode(spouse, Label.PERSON));
        }

        // Get/Create Marriage
        Node node = model.getOrCreateNode(Label.MARRIAGE);

        // Get Edges
        ArrayList<Edge> spouseEdges = new ArrayList<>();
        HashSet<String> existingSpouseIds = new HashSet<>();
        for (Edge edge: node.getEdges(Direction.IN, Label.MARRIAGE_SPOUSE_REF)) {
            spouseEdges.add(edge);
            existingSpouseIds.add(edge.getNode(Direction.OUT).getId());
        }

        Edge dateEdge = model.getEdge(node, Direction.OUT, Label.MARRIAGE_DATE_REF);
        Edge placeEdge = model.getEdge(node, Direction.OUT, Label.MARRIAGE_PLACE_REF);

        // Create Models
        DateModel dateModel;
        if (dateEdge != null) {
            dateModel = new DateModel(graph, dateEdge.getNode(Direction.IN).getId());
        } else {
            dateModel = new DateModel(graph);
        }
        PlaceModel placeModel;
        if (placeEdge != null) {
            placeModel = new PlaceModel(graph, placeEdge.getNode(Direction.IN).getId());
        } else {
            placeModel = new PlaceModel(graph);
        }

        // Add spouse edges that are in requestedSpouseIds but not in spouseEdges
        for (String id: requestedSpouseIds) {
            if (!existingSpouseIds.contains(id)) {
                spouseNodes.get(id).addEdge(node, Label.MARRIAGE_SPOUSE_REF);
            }
        }

        // Remove spouse edges that are in spouseEdges but not in requestedSpouseIds
        for (Edge edge: spouseEdges) {
            if (!requestedSpouseIds.contains(edge.getNode(Direction.OUT).getId())) {
                graph.removeEdge(edge.getId());
            }
        }

        // Add/update nodes
        if (date != null) {
            date.execute(dateModel);
            if (dateEdge == null) {
                node.addEdge(dateModel.getNode(Label.DATE), Label.MARRIAGE_DATE_REF);
            }
        }
        if (place != null) {
            place.execute(placeModel);
            if (placeEdge == null) {
                node.addEdge(placeModel.getNode(Label.PLACE), Label.MARRIAGE_PLACE_REF);
            }
        }

        // Remove unneeded nodes
        if (date == null && dateEdge != null) {
            new DateDeleteRequest().execute(dateModel);
        }
        if (place == null && placeEdge != null) {
            new PlaceDeleteRequest().execute(placeModel);
        }

    }
}

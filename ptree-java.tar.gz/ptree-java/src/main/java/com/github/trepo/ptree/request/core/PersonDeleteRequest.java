package com.github.trepo.ptree.request.core;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Node;

/**
 * @author John Clark.
 */
public class PersonDeleteRequest implements Request {

    @Override
    public void execute(BaseModel model) {
        Node node = model.getNode(Label.PERSON);
        model.getGraph().removeNode(node.getId());
    }
}

/**
 * Our core models.
 * @author John Clark.
 */
package com.github.trepo.ptree.model.core;

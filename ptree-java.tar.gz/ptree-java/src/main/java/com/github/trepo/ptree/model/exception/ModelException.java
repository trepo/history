package com.github.trepo.ptree.model.exception;

/**
 * Custom Model Exception.
 * @author John Clark.
 */
public class ModelException extends RuntimeException {

    /**
     * Create a new Exception.
     * @param message The message.
     */
    public ModelException(String message) {
        super(message);
    }

    /**
     * Create a new Exception.
     * @param message The message.
     * @param e The wrapped exception.
     */
    public ModelException(String message, Exception e) {
        super(message, e);
    }
}

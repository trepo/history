package com.github.trepo.ptree.rest.base;

import com.github.trepo.vgraph.VGraph;

import javax.inject.Inject;

/**
 * @author John Clark.
 */
public abstract class Base {
    /**
     * Our injected graph instance.
     */
    private VGraph graph;

    /**
     * Sets the vGraph instance to use via Injection.
     * @param graphInstance The vGraph instance.
     */
    @Inject
    public void setGraph(VGraph graphInstance) {
        graph = graphInstance;
    }

    /**
     * Get our vGraph instance.
     * @return The vGraph instance.
     */
    public VGraph getGraph() {
        return graph;
    }
}

package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.base.BaseModel;
import com.github.trepo.ptree.model.base.ReadableModel;
import com.github.trepo.ptree.model.base.WritableModel;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.base.Request;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

/**
 * @author John Clark.
 */
public class PlaceModel extends BaseModel implements ReadableModel, WritableModel {

    /**
     * The name.
     */
    private String name;

    /**
     * Create a new Place model.
     * @param graph The vGraph instance.
     */
    public PlaceModel(VGraph graph) {
        super(graph);
    }

    /**
     * Create a new Place model.
     * @param graph The vGraph instance.
     * @param id the date's id.
     */
    public PlaceModel(VGraph graph, String id) {
        super(graph, id);
    }


    @Override
    public void readFromGraph() {
        Node node = getNode(Label.PLACE);

        setBoundary(node.isBoundary());
        setRepo(node.getRepo());

        name = getProperty(node, Key.PLACE_NAME, String.class);
    }

    @Override
    public void writeToGraph(Request request) {
        request.execute(this);
    }

    /**
     * Get the name.
     * @return The name.
     */
    public String getName() {
        return name;
    }
}

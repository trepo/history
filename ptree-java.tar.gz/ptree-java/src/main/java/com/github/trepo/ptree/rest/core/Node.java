package com.github.trepo.ptree.rest.core;

import com.github.trepo.ptree.model.core.NodeModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.ptree.rest.base.Base;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * Get a Node.
 * @author John Clark.
 */
@Path("/_node/{id}")
public class Node extends Base {

    /**
     * Gets a Node.
     * @param id The id of the node.
     * @return The raw representation of the node, or 404.
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(@PathParam("id") String id) {

        try {
            NodeModel nodeModel = new NodeModel(getGraph(), id);
            nodeModel.readFromGraph();

            return Response
                    .status(Response.Status.OK)
                    .entity(nodeModel)
                    .build();

        } catch (NotFoundModelException e) {
            throw new WebApplicationException("Node not found", e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }

    }
}

package com.github.trepo.ptree.rest.what.name;

import com.github.trepo.ptree.model.core.PersonModel;
import com.github.trepo.ptree.model.exception.InvalidModelException;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.ptree.model.what.NameModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.what.name.NamePersonWriteRequest;
import com.github.trepo.ptree.request.what.name.NameWriteRequest;
import com.github.trepo.ptree.rest.base.Base;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.ArrayList;

/**
 * @author John Clark.
 */
@Path("/person/{id}/name")
public class PersonName extends Base {

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(@PathParam("id") String id) {
        try {
            PersonModel model = new PersonModel(getGraph(), id);

            ArrayList<NameModel> names = new ArrayList<>();

            for (Edge edge: model.getNode(Label.PERSON).getEdges(Direction.OUT, Label.NAME_PERSON_REF)) {
                NameModel name = new NameModel(getGraph(), edge.getNode(Direction.IN).getId());
                name.readFromGraph();
                names.add(name);
            }

            return Response
                    .status(Response.Status.OK)
                    .entity(names)
                    .build();
        } catch (NotFoundModelException | InvalidModelException e) {
            throw new WebApplicationException("Person Not Found: " + e.getMessage(), e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }

    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response post(@PathParam("id") String id, NameWriteRequest request) {
        try {
            request.validate();
        } catch (ModelException e) {
            throw new WebApplicationException("Invalid request: " + e.getMessage(), e,
                    Response.Status.BAD_REQUEST);
        }

        try {
            NameModel model = new NameModel(getGraph());
            PersonModel personModel = new PersonModel(getGraph(), id);
            // Make sure person exists BEFORE writing name to the graph.
            personModel.readFromGraph();
            // Create name
            model.writeToGraph(request);
            // Associate with person
            model.writeToGraph(new NamePersonWriteRequest(id));
            model.readFromGraph();

            return Response
                    .status(Response.Status.CREATED)
                    .entity(model)
                    .build();
        } catch (NotFoundModelException | InvalidModelException e) {
            throw new WebApplicationException("Person Not Found: " + e.getMessage(), e,
                    Response.Status.NOT_FOUND);
        } catch (ModelException e) {
            throw new WebApplicationException("Graph Exception: " + e.getMessage(), e,
                    Response.Status.INTERNAL_SERVER_ERROR);
        }
    }
}

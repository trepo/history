package com.github.trepo.ptree.rest.core;

import com.github.trepo.ptree.model.core.PersonModel;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class PersonTest {

    /**
     * post
     */
    @Test
    public void post_shouldError() {
        Person person = new Person();

        try {
            person.post();
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void post_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Person person = new Person();
        person.setGraph(graph);

        Response response = person.post();

        // Verify Response
        assertThat(response.getStatus()).isEqualTo(201);
        PersonModel personModel = (PersonModel) response.getEntity();
        assertThat(personModel.getBoundary()).isFalse();

        // verify graph
        Node updated = graph.getNode(personModel.getId());
        assertThat(updated).isNotNull();
    }

    /**
     * get
     */
    @Test
     public void get_shouldErrorOnGraph() {
        Person person = new Person();

        try {
            person.get("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void get_shouldErrorOnMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Person person = new Person();
        person.setGraph(graph);

        try {
            person.get("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Person Not Found: node not found");
        }
    }

    @Test
    public void get_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("NOT_PERSON").getId();
        Person person = new Person();
        person.setGraph(graph);

        try {
            person.get(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Person Not Found: invalid label: expected Person but found NOT_PERSON");
        }
    }

    @Test
    public void get_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Person").getId();
        Person person = new Person();
        person.setGraph(graph);

        Response response = person.get(id);

        assertThat(response.getStatus()).isEqualTo(200);
        PersonModel personModel = (PersonModel) response.getEntity();
        assertThat(personModel.getId()).isEqualTo(id);
        assertThat(personModel.getBoundary()).isFalse();
    }

    /**
     * delete
     */
    @Test
    public void delete_shouldErrorOnGraph() {
        Person person = new Person();

        try {
            person.delete("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void delete_shouldErrorOnMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Person person = new Person();
        person.setGraph(graph);

        try {
            person.delete("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Person Not Found: node not found");
        }
    }

    @Test
    public void delete_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("NOT_PERSON").getId();
        Person person = new Person();
        person.setGraph(graph);

        try {
            person.delete(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Person Not Found: invalid label: expected Person but found NOT_PERSON");
        }
    }

    @Test
    public void delete_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Person").getId();
        Person person = new Person();
        person.setGraph(graph);

        Response response = person.delete(id);

        assertThat(response.getStatus()).isEqualTo(204);
        assertThat(response.getEntity()).isNull();

        // Make sure node is gone
        assertThat(graph.getNode(id)).isNull();
    }
}

package com.github.trepo.ptree.rest.what.name;

import com.github.trepo.ptree.model.what.NameModel;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.what.name.NameWriteRequest;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import java.util.ArrayList;
import java.util.Iterator;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class PersonNameTest {

    /**
     * get
     */
    @Test
    public void get_shouldErrorOnGraphException() {
        PersonName personName = new PersonName();

        try {
            personName.get(null);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void get_shouldErrorOnMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        PersonName personName = new PersonName();
        personName.setGraph(graph);

        try {
            personName.get("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Person Not Found: node not found");
        }

    }

    @Test
    public void get_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Bogus").getId();
        PersonName personName = new PersonName();
        personName.setGraph(graph);

        try {
            personName.get(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Person Not Found: invalid label: expected Person but found Bogus");
        }
    }

    @Test
    @SuppressWarnings("unchecked")
    public void get_shouldReturnEmptyArray() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode(Label.PERSON).getId();
        PersonName personName = new PersonName();
        personName.setGraph(graph);

        Response response = personName.get(id);

        assertThat(response.getStatus()).isEqualTo(200);
        ArrayList<NameModel> names = (ArrayList<NameModel>) response.getEntity();
        assertThat(names.size()).isEqualTo(0);
    }

    @Test
    @SuppressWarnings("unchecked")
    public void get_shouldReturn2Names() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node person = graph.addNode(Label.PERSON);
        Node name1 = graph.addNode(Label.NAME);
        name1.setProperty(Key.NAME_NAME, "Name #1");
        person.addEdge(name1, Label.NAME_PERSON_REF);
        Node name2 = graph.addNode(Label.NAME);
        name2.setProperty(Key.NAME_NAME, "Name #2");
        person.addEdge(name2, Label.NAME_PERSON_REF);

        PersonName personName = new PersonName();
        personName.setGraph(graph);

        Response response = personName.get(person.getId());

        assertThat(response.getStatus()).isEqualTo(200);
        ArrayList<NameModel> names = (ArrayList<NameModel>) response.getEntity();
        assertThat(names.size()).isEqualTo(2);
        for (NameModel name: names) {
            assertThat(name.getId()).isIn(name1.getId(), name2.getId());
            assertThat(name.getName()).isIn("Name #1", "Name #2");
        }
    }

    /**
     * post
     */
    @Test
    public void post_shouldErrorOnValidation() {
        PersonName personName = new PersonName();

        NameWriteRequest request = new NameWriteRequest(null, null);

        try {
            personName.post(null, request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(400);
            assertThat(e.getMessage()).isEqualTo("Invalid request: name may not be null");
        }
    }

    @Test
    public void post_shouldErrorOnGraphException() {
        PersonName personName = new PersonName();

        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);

        try {
            personName.post(null, request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void post_shouldErrorOnMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        PersonName personName = new PersonName();
        personName.setGraph(graph);

        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);

        try {
            personName.post("1234", request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Person Not Found: node not found");
        }
    }

    @Test
    public void post_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Bogus").getId();
        PersonName personName = new PersonName();
        personName.setGraph(graph);

        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);

        try {
            personName.post(id, request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Person Not Found: invalid label: expected Person but found Bogus");
        }
    }

    @Test
    public void post_shouldWork() {
        // TODO
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode(Label.PERSON).getId();
        PersonName personName = new PersonName();
        personName.setGraph(graph);

        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);

        Response response = personName.post(id, request);

        // Verify Response
        assertThat(response.getStatus()).isEqualTo(201);
        NameModel model = (NameModel) response.getEntity();
        assertThat(model.getName()).isEqualTo("Bob Freemer");

        // verify graph
        Node newName = graph.getNode(model.getId());
        assertThat(newName.getProperty(Key.NAME_NAME)).isEqualTo("Bob Freemer");
        Iterator<Edge> itr = graph.getNode(id).getEdges(Direction.OUT, Label.NAME_PERSON_REF).iterator();
        assertThat(itr.hasNext());
        Edge edge = itr.next();
        assertThat(edge.getNode(Direction.IN).getId()).isEqualTo(model.getId());

    }
}

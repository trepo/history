package com.github.trepo.ptree.model.what;

import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.what.name.NameWriteRequest;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class NameModelTest {
    private VGraph graph;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
    }

    /**
     * PlaceModel(graph)
     */
    @Test
    public void constructor1_shouldWork() {
        NameModel model = new NameModel(graph);

        assertThat(model.getId()).isNull();
    }

    /**
     * PlaceModel(graph, id)
     */
    @Test
    public void constructor2_shouldWork() {
        NameModel model = new NameModel(graph, "1234");

        assertThat(model.getId()).isEqualTo("1234");
    }

    /**
     * readFromGraph
     */
    @Test
    public void readFromGraph_shouldError() {
        NameModel model = new NameModel(graph);

        try {
            model.readFromGraph();
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("Cannot read from graph: missing id");
        }
    }

    @Test
    public void readFromGraph_shouldWork() {
        Node node = graph.addNode(Label.NAME);
        node.setProperty(Key.NAME_NAME, "Bob Freemer");
        NameModel model = new NameModel(graph, node.getId());
        model.readFromGraph();

        assertThat(model.getBoundary()).isFalse();
        assertThat(model.getName()).isEqualTo("Bob Freemer");
        assertThat(model.getPerson()).isNull();
    }

    @Test
    public void readFromGraph_shouldLoadPerson() {
        Node name = graph.addNode(Label.NAME);
        name.setProperty(Key.NAME_NAME, "Bob Freemer");
        Node person = graph.addNode(Label.PERSON);
        person.addEdge(name, Label.NAME_PERSON_REF);


        NameModel model = new NameModel(graph, name.getId());
        model.readFromGraph();

        assertThat(model.getBoundary()).isFalse();
        assertThat(model.getName()).isEqualTo("Bob Freemer");
        assertThat(model.getPerson()).isNotNull();
        assertThat(model.getPerson().getId()).isEqualTo(person.getId());
    }

    /**
     * writeToGraph
     */
    @Test
    public void writeToGraph_shouldWork() {
        Node node = graph.addNode(Label.NAME);
        node.setProperty(Key.NAME_NAME, "somewhere");
        NameModel model = new NameModel(graph, node.getId());

        NameWriteRequest requestModel = new NameWriteRequest("Bob Freemer", null);

        model.writeToGraph(requestModel);


        assertThat(node.getProperty(Key.PLACE_NAME)).isEqualTo("Bob Freemer");
    }
}

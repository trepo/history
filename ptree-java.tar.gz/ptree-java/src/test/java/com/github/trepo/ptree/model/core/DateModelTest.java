package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.core.DateWriteRequest;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.fail;

/**
 * @author John Clark.
 */
public class DateModelTest {
    private VGraph graph;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
    }

    /**
     * DateModel(graph)
     */
    @Test
    public void constructor1_shouldWork() {
        DateModel model = new DateModel(graph);

        assertThat(model.getId()).isNull();
    }

    /**
     * DateModel(graph, id)
     */
    @Test
    public void constructor2_shouldWork() {
        DateModel model = new DateModel(graph, "1234");

        assertThat(model.getId()).isEqualTo("1234");
    }

    /**
     * readFromGraph
     */
    @Test
    public void readFromGraph_shouldError() {
        DateModel model = new DateModel(graph);

        try {
            model.readFromGraph();
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("Cannot read from graph: missing id");
        }
    }

    @Test
    public void readFromGraph_shouldWork() {
        Node node = graph.addNode(Label.DATE);
        node.setProperty(Key.DATE_ORIGINAL, "1800");
        DateModel model = new DateModel(graph, node.getId());
        model.readFromGraph();

        assertThat(model.getBoundary()).isFalse();
        assertThat(model.getOriginal()).isEqualTo("1800");
        assertThat(model.getFormal()).isNull();
    }

    /**
     * writeToGraph
     */
    @Test
    public void writeToGraph_shouldWork() {
        Node node = graph.addNode(Label.DATE);
        node.setProperty(Key.DATE_ORIGINAL, "1800");
        DateModel model = new DateModel(graph, node.getId());

        DateWriteRequest requestModel = new DateWriteRequest(null, "+1800");

        model.writeToGraph(requestModel);


        assertThat(node.getProperty(Key.DATE_ORIGINAL)).isNull();
        assertThat(node.getProperty(Key.DATE_FORMAL)).isEqualTo("+1800");
    }

}

package com.github.trepo.ptree.rest.core;

import com.github.trepo.ptree.model.core.DateModel;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.request.core.DateWriteRequest;
import com.github.trepo.vgraph.*;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class DateTest {

    /**
     * post
     */
    @Test
    public void post_shouldErrorOnValidation() {
        Date date = new Date();

        DateWriteRequest model = new DateWriteRequest(null, null);

        try {
            date.post(model);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(400);
            assertThat(e.getMessage()).isEqualTo("Invalid request: You must have either a formal or original date");
        }
    }

    @Test
    public void post_shouldErrorOnGraphException() {
        Date date = new Date();

        DateWriteRequest model = new DateWriteRequest("1800", "+1800");

        try {
            date.post(model);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void post_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Date date = new Date();
        date.setGraph(graph);

        DateWriteRequest model = new DateWriteRequest("1800", "+1800");

        Response response = date.post(model);

        // Verify response
        assertThat(response.getStatus()).isEqualTo(201);
        DateModel dateModel = (DateModel) response.getEntity();
        assertThat(dateModel.getOriginal()).isEqualTo("1800");
        assertThat(dateModel.getFormal()).isEqualTo("+1800");

        // verify graph
        Node updated = graph.getNode(dateModel.getId());
        assertThat(updated.getProperty(Key.DATE_ORIGINAL)).isEqualTo("1800");
        assertThat(updated.getProperty(Key.DATE_FORMAL)).isEqualTo("+1800");
    }

    /**
     * get
     */
    @Test
    public void get_shouldErrorOnGraph() {
        Date date = new Date();

        try {
            date.get("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void get_shouldErrorOnMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Date date = new Date();
        date.setGraph(graph);

        try {
            date.get("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Date Not Found: node not found");
        }
    }

    @Test
    public void get_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Not_Date").getId();
        Date date = new Date();
        date.setGraph(graph);

        try {
            date.get(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Date Not Found: invalid label: expected Date but found Not_Date");
        }
    }

    @Test
    public void get_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode("Date");
        node.setProperty(Key.DATE_ORIGINAL, "1800");
        Date date = new Date();
        date.setGraph(graph);

        Response response = date.get(node.getId());

        assertThat(response.getStatus()).isEqualTo(200);
        DateModel dateModel = (DateModel) response.getEntity();
        assertThat(dateModel.getId()).isEqualTo(node.getId());
        assertThat(dateModel.getOriginal()).isEqualTo("1800");
        assertThat(dateModel.getFormal()).isNull();
    }

    /**
     * put
     */
    @Test
    public void put_shouldErrorOnValidation() {
        Date date = new Date();

        DateWriteRequest model = new DateWriteRequest(null, null);

        try {
            date.put(null, model);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(400);
            assertThat(e.getMessage()).isEqualTo("Invalid request: You must have either a formal or original date");
        }
    }

    @Test
    public void put_shouldErrorOnGraphException() {
        Date date = new Date();

        DateWriteRequest model = new DateWriteRequest("1800", "+1800");

        try {
            date.put(null, model);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void put_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode("Date");
        node.setProperty(Key.DATE_ORIGINAL, "1800");
        Date date = new Date();
        date.setGraph(graph);

        DateWriteRequest model = new DateWriteRequest(null, "+1800");

        Response response = date.put(node.getId(), model);

        // verify response
        assertThat(response.getStatus()).isEqualTo(200);
        DateModel dateModel = (DateModel) response.getEntity();
        assertThat(dateModel.getOriginal()).isNull();
        assertThat(dateModel.getFormal()).isEqualTo("+1800");

        // verify graph
        Node updated = graph.getNode(node.getId());
        assertThat(updated.getProperty(Key.DATE_ORIGINAL)).isNull();
        assertThat(updated.getProperty(Key.DATE_FORMAL)).isEqualTo("+1800");
    }

    /**
     * delete
     */
    @Test
    public void delete_shouldErrorOnGraph() {
        Date date = new Date();

        try {
            date.delete("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void delete_shouldErrorOnMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Date date = new Date();
        date.setGraph(graph);

        try {
            date.delete("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Date Not Found: node not found");
        }
    }

    @Test
    public void delete_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Bogus").getId();
        Date date = new Date();
        date.setGraph(graph);

        try {
            date.delete(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Date Not Found: invalid label: expected Date but found Bogus");
        }
    }

    @Test
    public void delete_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode("Date");
        node.setProperty("original", "1800");
        String id = node.getId();
        Date date = new Date();
        date.setGraph(graph);

        Response response = date.delete(id);

        assertThat(response.getStatus()).isEqualTo(204);
        assertThat(response.getEntity()).isNull();

        // Make sure node is gone
        assertThat(graph.getNode(id)).isNull();
    }
}

package com.github.trepo.ptree.rest.what.name;

import com.github.trepo.ptree.model.core.PersonModel;
import com.github.trepo.ptree.model.what.NameModel;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.what.name.NamePersonWriteRequest;
import com.github.trepo.ptree.request.what.name.NameWriteRequest;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import java.util.Iterator;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class NameTest {

    /**
     * post
     */
    @Test
    public void post_shouldErrorOnValidation() {
        Name name = new Name();

        NameWriteRequest request = new NameWriteRequest(null, null);

        try {
            name.post(request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(400);
            assertThat(e.getMessage()).isEqualTo("Invalid request: name may not be null");
        }
    }

    @Test
    public void post_shouldErrorOnGraphException() {
        Name name = new Name();

        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);

        try {
            name.post(request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void post_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Name name = new Name();
        name.setGraph(graph);

        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);

        Response response = name.post(request);

        // Verify Response
        assertThat(response.getStatus()).isEqualTo(201);
        NameModel model = (NameModel) response.getEntity();
        assertThat(model.getName()).isEqualTo("Bob Freemer");

        // verify graph
        Node updated = graph.getNode(model.getId());
        assertThat(updated.getProperty(Key.NAME_NAME)).isEqualTo("Bob Freemer");
    }

    /**
     * getId
     */
    @Test
    public void getId_shouldErrorOnGraph() {
        Name name = new Name();

        try {
            name.getId(null);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void getId_shouldErrorOnMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Name name = new Name();
        name.setGraph(graph);

        try {
            name.getId("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: node not found");
        }
    }

    @Test
    public void getId_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Bogus").getId();
        Name name = new Name();
        name.setGraph(graph);

        try {
            name.getId(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: invalid label: expected Name but found Bogus");
        }
    }

    @Test
    public void getId_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode(Label.NAME);
        node.setProperty(Key.NAME_NAME, "Bob Freemer");
        Name name = new Name();
        name.setGraph(graph);

        Response response = name.getId(node.getId());

        // Verify Response
        assertThat(response.getStatus()).isEqualTo(200);
        NameModel model = (NameModel) response.getEntity();
        assertThat(model.getName()).isEqualTo("Bob Freemer");
    }

    /**
     * putId
     */
    @Test
    public void putId_shouldErrorOnValidation() {
        Name name = new Name();

        NameWriteRequest request = new NameWriteRequest(null, null);

        try {
            name.putId(null, request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(400);
            assertThat(e.getMessage()).isEqualTo("Invalid request: name may not be null");
        }
    }

    @Test
    public void putId_shouldErrorOnGraph() {
        Name name = new Name();

        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);

        try {
            name.putId(null, request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void putId_shouldErrorOnMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Name name = new Name();
        name.setGraph(graph);

        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);

        try {
            name.putId("1234", request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: node not found");
        }
    }

    @Test
    public void putId_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Bogus").getId();
        Name name = new Name();
        name.setGraph(graph);

        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);

        try {
            name.putId(id, request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: invalid label: expected Name but found Bogus");
        }
    }

    @Test
    public void putId_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode(Label.NAME);
        node.setProperty(Key.NAME_NAME, "Old Name");
        Name name = new Name();
        name.setGraph(graph);

        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);

        Response response = name.putId(node.getId(), request);

        // Verify Response
        assertThat(response.getStatus()).isEqualTo(200);
        NameModel model = (NameModel) response.getEntity();
        assertThat(model.getName()).isEqualTo("Bob Freemer");

        // verify graph
        Node updated = graph.getNode(model.getId());
        assertThat(updated.getProperty(Key.NAME_NAME)).isEqualTo("Bob Freemer");
    }

    /**
     * deleteId
     */
    @Test
    public void deleteId_shouldErrorOnGraph() {
        Name name = new Name();

        try {
            name.deleteId(null);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void deleteId_shouldErrorOnMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Name name = new Name();
        name.setGraph(graph);

        try {
            name.deleteId("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: node not found");
        }
    }

    @Test
    public void deleteId_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Bogus").getId();
        Name name = new Name();
        name.setGraph(graph);

        try {
            name.deleteId(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: invalid label: expected Name but found Bogus");
        }
    }

    @Test
    public void deleteId_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode(Label.NAME);
        node.setProperty(Key.NAME_NAME, "Old Name");
        String id = node.getId();
        Name name = new Name();
        name.setGraph(graph);

        Response response = name.deleteId(id);

        // Verify Response
        assertThat(response.getStatus()).isEqualTo(204);
        assertThat(response.getEntity()).isNull();

        // verify graph
        Node updated = graph.getNode(id);
        assertThat(updated).isNull();

    }

    /**
     * getIdPerson
     */
    @Test
    public void getIdPerson_shouldErrorOnGraph() {
        Name name = new Name();

        try {
            name.getIdPerson(null);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void getIdPerson_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Bogus").getId();
        Name name = new Name();
        name.setGraph(graph);

        try {
            name.getIdPerson(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: invalid label: expected Name but found Bogus");
        }
    }

    @Test
    public void getIdPerson_shouldErrorOnMissingName() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Name name = new Name();
        name.setGraph(graph);

        try {
            name.getIdPerson("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: node not found");
        }
    }

    @Test
    public void getIdPerson_shouldErrorOnMissingPerson() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode(Label.NAME);
        node.setProperty(Key.NAME_NAME, "Old Name");
        String id = node.getId();
        Name name = new Name();
        name.setGraph(graph);

        try {
            name.getIdPerson(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Person Not Found");
        }
    }

    @Test
    public void getIdPerson_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node nameNode = graph.addNode(Label.NAME);
        nameNode.setProperty(Key.NAME_NAME, "Old Name");
        String nameId = nameNode.getId();
        Node personNode = graph.addNode(Label.PERSON);
        String personId = personNode.getId();
        graph.addEdge(personNode, nameNode, Label.NAME_PERSON_REF);

        Name name = new Name();
        name.setGraph(graph);

        Response response = name.getIdPerson(nameId);

        // Verify Response
        assertThat(response.getStatus()).isEqualTo(200);
        PersonModel model = (PersonModel) response.getEntity();
        assertThat(model.getId()).isEqualTo(personId);

    }

    /**
     * putIdPerson
     */
    @Test
    public void putIdPerson_shouldErrorOnGraph() {
        Name name = new Name();

        NamePersonWriteRequest request = new NamePersonWriteRequest("1234");

        try {
            name.putIdPerson(null, request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void putIdPerson_shouldErrorOnValidation() {
        Name name = new Name();

        NamePersonWriteRequest request = new NamePersonWriteRequest(null);

        try {
            name.putIdPerson(null, request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(400);
            assertThat(e.getMessage()).isEqualTo("Invalid request: id may not be null");
        }
    }

    @Test
    public void putIdPerson_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Bogus").getId();
        Name name = new Name();
        name.setGraph(graph);

        NamePersonWriteRequest request = new NamePersonWriteRequest("1234");

        try {
            name.putIdPerson(id, request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: invalid label: expected Name but found Bogus");
        }
    }

    @Test
    public void putIdPerson_shouldErrorOnMissingName() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Name name = new Name();
        name.setGraph(graph);

        NamePersonWriteRequest request = new NamePersonWriteRequest("1234");

        try {
            name.putIdPerson("1234", request);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: node not found");
        }
    }

    @Test
    public void putIdPerson_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node nameNode = graph.addNode(Label.NAME);
        nameNode.setProperty(Key.NAME_NAME, "Old Name");
        String nameId = nameNode.getId();
        Node personNode1 = graph.addNode(Label.PERSON);
        String personId1 = personNode1.getId();
        graph.addEdge(personNode1, nameNode, Label.NAME_PERSON_REF);
        Node personNode2 = graph.addNode(Label.PERSON);
        String personId2 = personNode2.getId();

        Name name = new Name();
        name.setGraph(graph);

        NamePersonWriteRequest request = new NamePersonWriteRequest(personId2);

        Response response = name.putIdPerson(nameId, request);

        // Verify Response
        assertThat(response.getStatus()).isEqualTo(200);
        PersonModel model = (PersonModel) response.getEntity();
        assertThat(model.getId()).isEqualTo(personId2);

        // Verify Graph
        assertThat(graph.getNode(personId1).getEdges(Direction.OUT, Label.NAME_PERSON_REF).iterator().hasNext()).isFalse();
        Iterator<Edge> itr = graph.getNode(personId2).getEdges(Direction.OUT, Label.NAME_PERSON_REF).iterator();
        assertThat(itr.hasNext());
        Edge edge = itr.next();
        assertThat(edge.getNode(Direction.IN).getId()).isEqualTo(nameId);
    }

    /**
     * deleteIdPerson
     */
    @Test
    public void deleteIdPerson_shouldErrorOnGraph() {
        Name name = new Name();

        try {
            name.deleteIdPerson(null);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void deleteIdPerson_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Bogus").getId();
        Name name = new Name();
        name.setGraph(graph);

        try {
            name.deleteIdPerson(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: invalid label: expected Name but found Bogus");
        }
    }

    @Test
    public void deleteIdPerson_shouldErrorOnMissingName() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Name name = new Name();
        name.setGraph(graph);

        try {
            name.deleteIdPerson("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Name Not Found: node not found");
        }
    }

    @Test
    public void deleteIdPerson_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node nameNode = graph.addNode(Label.NAME);
        nameNode.setProperty(Key.NAME_NAME, "Old Name");
        String nameId = nameNode.getId();
        Node personNode = graph.addNode(Label.PERSON);
        String personId = personNode.getId();
        graph.addEdge(personNode, nameNode, Label.NAME_PERSON_REF);

        assertThat(graph.getNode(personId).getEdges(Direction.OUT, Label.NAME_PERSON_REF).iterator().hasNext()).isTrue();

        Name name = new Name();
        name.setGraph(graph);


        Response response = name.deleteIdPerson(nameId);

        // Verify Response
        assertThat(response.getStatus()).isEqualTo(204);
        assertThat(response.getEntity()).isNull();

        // Verify Graph
        assertThat(graph.getNode(personId).getEdges(Direction.OUT, Label.NAME_PERSON_REF).iterator().hasNext()).isFalse();
    }


}

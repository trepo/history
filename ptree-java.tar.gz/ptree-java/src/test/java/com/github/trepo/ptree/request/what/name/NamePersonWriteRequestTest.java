package com.github.trepo.ptree.request.what.name;

import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.what.NameModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Iterator;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.fail;

/**
 * @author John Clark.
 */
public class NamePersonWriteRequestTest {
    private VGraph graph;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
    }

    /**
     * constructor + getters
     */
    @Test
    public void shouldWork() {
        NamePersonWriteRequest request = new NamePersonWriteRequest("1234");

        assertThat(request.getId()).isEqualTo("1234");
    }

    /**
     * validate
     */
    @Test
    public void validate_shouldError() {
        NamePersonWriteRequest request = new NamePersonWriteRequest(null);
        try {
            request.validate();
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("id may not be null");
        }
    }

    @Test
    public void validate_shouldWork() {
        NamePersonWriteRequest request = new NamePersonWriteRequest("1234");
        request.validate();
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldErrorIfNameLabelIsWrong() {
        String id = graph.addNode("Bogus").getId();

        assertThat(graph.getNode(id)).isNotNull();

        NameModel model = new NameModel(graph, id);

        try {
            new NamePersonWriteRequest("1234").execute(model);
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("invalid label: expected Name but found Bogus");
        }
    }

    @Test
    public void execute_shouldErrorIfPersonLabelIsWrong() {
        String nameId = graph.addNode(Label.NAME).getId();

        String personId = graph.addNode("Bogus").getId();

        NameModel model = new NameModel(graph, nameId);

        try {
            new NamePersonWriteRequest(personId).execute(model);
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("invalid label: expected Person but found Bogus");
        }
    }

    @Test
    public void execute_shouldCreateEdge() {
        Node name = graph.addNode(Label.NAME);
        Node person = graph.addNode(Label.PERSON);

        NameModel model = new NameModel(graph, name.getId());

        new NamePersonWriteRequest(person.getId()).execute(model);

        Iterator<Edge> itr = person.getEdges(Direction.OUT, Label.NAME_PERSON_REF).iterator();

        assertThat(itr.hasNext()).isTrue();
        Edge edge = itr.next();
        assertThat(edge.getLabel()).isEqualTo(Label.NAME_PERSON_REF);
        assertThat(edge.getNode(Direction.IN)).isEqualTo(name);
        assertThat(edge.getNode(Direction.OUT)).isEqualTo(person);
    }

    @Test
    public void execute_shouldDeleteExistingEdge() {
        Node name = graph.addNode(Label.NAME);
        Node person1 = graph.addNode(Label.PERSON);
        Node person2 = graph.addNode(Label.PERSON);
        // person1 -> name
        String oldEdgeId = person1.addEdge(name, Label.NAME_PERSON_REF).getId();

        NameModel model = new NameModel(graph, name.getId());

        // Now person2 -> name
        new NamePersonWriteRequest(person2.getId()).execute(model);

        // Make sure old edge is gone.
        assertThat(graph.getEdge(oldEdgeId)).isNull();

        Iterator<Edge> itr = name.getEdges(Direction.IN, Label.NAME_PERSON_REF).iterator();
        assertThat(itr.hasNext()).isTrue();
        Edge edge = itr.next();
        assertThat(edge.getLabel()).isEqualTo(Label.NAME_PERSON_REF);
        assertThat(edge.getNode(Direction.IN)).isEqualTo(name);
        assertThat(edge.getNode(Direction.OUT)).isEqualTo(person2);
    }

    @Test
    public void execute_shouldDoNothingWhenEdgeExists() {
        Node name = graph.addNode(Label.NAME);
        Node person = graph.addNode(Label.PERSON);
        String oldEdgeId = person.addEdge(name, Label.NAME_PERSON_REF).getId();

        NameModel model = new NameModel(graph, name.getId());

        new NamePersonWriteRequest(person.getId()).execute(model);

        Iterator<Edge> itr = person.getEdges(Direction.OUT, Label.NAME_PERSON_REF).iterator();
        assertThat(itr.hasNext()).isTrue();
        Edge edge = itr.next();

        assertThat(edge.getId()).isEqualTo(oldEdgeId);
    }
}

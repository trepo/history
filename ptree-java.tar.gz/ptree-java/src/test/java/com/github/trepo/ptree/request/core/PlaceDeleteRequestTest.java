package com.github.trepo.ptree.request.core;

import com.github.trepo.ptree.model.core.PlaceModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class PlaceDeleteRequestTest {
    private VGraph graph;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldErrorIfLabelIsWrong() {
        String id = graph.addNode("Bogus").getId();

        assertThat(graph.getNode(id)).isNotNull();

        PlaceModel model = new PlaceModel(graph, id);

        try {
            new PlaceDeleteRequest().execute(model);
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("invalid label: expected Place but found Bogus");
        }

    }

    @Test
    public void execute_shouldWork() {
        String id = graph.addNode("Place").getId();

        assertThat(graph.getNode(id)).isNotNull();

        PlaceModel model = new PlaceModel(graph, id);
        new PlaceDeleteRequest().execute(model);

        assertThat(graph.getNode(id)).isNull();
    }
}

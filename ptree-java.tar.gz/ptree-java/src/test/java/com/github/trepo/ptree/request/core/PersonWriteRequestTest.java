package com.github.trepo.ptree.request.core;

import com.github.trepo.ptree.model.core.PersonModel;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class PersonWriteRequestTest {

    private VGraph graph;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldDoNothingIfAlreadyExists() {
        String id = graph.addNode("Person").getId();
        PersonModel model = new PersonModel(graph, id);
        new PersonWriteRequest().execute(model);

        assertThat(model.getId()).isEqualTo(id);
    }

    @Test
    public void execute_shouldWriteCorrectly() {
        PersonModel model = new PersonModel(graph);
        new PersonWriteRequest().execute(model);
        String id = model.getId();

        Node node = graph.getNode(id);

        assertThat(node).isNotNull();
        assertThat(node.getLabel()).isEqualTo("Person");
        assertThat(node.isBoundary()).isFalse();
    }
}

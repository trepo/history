package com.github.trepo.ptree.rest.core;

import com.github.trepo.ptree.model.core.EdgeModel;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class EdgeTest {

    /**
     * get
     */
    @Test
    public void get_shouldReturn500() {
        Edge edge = new Edge();
        try {
            edge.get("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void get_shouldReturn404() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Edge edge = new Edge();
        edge.setGraph(graph);

        try {
            edge.get("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Edge not found");
        }
    }

    @Test
    public void get_shouldReturn200() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        com.github.trepo.vgraph.Node fromNode = graph.addNode("label");
        com.github.trepo.vgraph.Node toNode = graph.addNode("label");
        com.github.trepo.vgraph.Edge graphEdge = fromNode.addEdge(toNode, "edgeLabel");
        graphEdge.setProperty("test", true);

        Edge edge = new Edge();
        edge.setGraph(graph);

        Response response = edge.get(graphEdge.getId());

        assertThat(response.getStatus()).isEqualTo(200);
        EdgeModel edgeModel = (EdgeModel) response.getEntity();
        assertThat(edgeModel.getId()).isEqualTo(graphEdge.getId());
        assertThat(edgeModel.getLabel()).isEqualTo("edgeLabel");
        assertThat(edgeModel.getProperties().size()).isEqualTo(1);
        assertThat(edgeModel.getProperties().get("test")).isEqualTo(true);
        assertThat(edgeModel.getFrom().getId()).isEqualTo(fromNode.getId());
        assertThat(edgeModel.getTo().getId()).isEqualTo(toNode.getId());
    }
}

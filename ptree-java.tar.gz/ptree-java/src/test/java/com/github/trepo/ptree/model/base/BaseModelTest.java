package com.github.trepo.ptree.model.base;

import com.github.trepo.ptree.model.exception.InvalidModelException;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.fail;

/**
 * @author John Clark.
 */
public class BaseModelTest {

    /**
     * BaseModel(graph)
     */
    @Test
    public void constructor1_shouldThrowErrorOnNullGraph() {
        try {
            new ExtendedBaseModel(null);
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("Graph is null");
        }
    }

    /**
     * BaseModel(graph, id)
     */
    @Test
    public void constructor2_shouldThrowErrorOnNullGraph() {
        try {
            new ExtendedBaseModel(null, "1234");
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("Graph is null");
        }
    }

    @Test
    public void constructor2_shouldThrowErrorOnNullID() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        try {
            new ExtendedBaseModel(graph, null);
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("id is null");
        }
    }

    /**
     * getGraph
     */
    @Test
    public void getGraph_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph, "1234");

        assertThat(baseModel.getGraph()).isEqualTo(graph);

        baseModel = new ExtendedBaseModel(graph);

        assertThat(baseModel.getGraph()).isEqualTo(graph);
    }

    /**
     * getNode(label)
     */
    @Test
    public void getNode_label_shouldErrorWhenMissingId() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        ExtendedBaseModel model = new ExtendedBaseModel(graph);

        try {
            model.getNode("label");
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("Cannot read from graph: missing id");
        }
    }

    @Test
    public void getNode_label_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Person").getId();
        ExtendedBaseModel model = new ExtendedBaseModel(graph, id);
        Node node = model.getNode("Person");

        assertThat(node.getId()).isEqualTo(id);
        assertThat(node.isBoundary()).isFalse();
        assertThat(node.getLabel()).isEqualTo("Person");
    }

    /**
     * getNode(id, label)
     */
    @Test
    public void getNode_id_label_shouldErrorWhenMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        ExtendedBaseModel model = new ExtendedBaseModel(graph, "1234");

        try {
            model.getNode("1234", "label");
            fail("Should have thrown an error");
        } catch (NotFoundModelException e) {
            assertThat(e.getMessage()).isEqualTo("node not found");
        }
    }

    @Test
    public void getNode_id_label_shouldErrorWhenNodeIsNotAPerson() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("NOT_LABEL").getId();
        ExtendedBaseModel model = new ExtendedBaseModel(graph, id);

        try {
            model.getNode(id, "LABEL");
            fail("Should have thrown an error");
        } catch (InvalidModelException e) {
            assertThat(e.getMessage()).isEqualTo("invalid label: expected LABEL but found NOT_LABEL");
        }
    }

    @Test
    public void getNode_id_label_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Person").getId();
        ExtendedBaseModel model = new ExtendedBaseModel(graph, id);
        Node node = model.getNode(id, "Person");

        assertThat(node.getId()).isEqualTo(id);
        assertThat(node.isBoundary()).isFalse();
        assertThat(node.getLabel()).isEqualTo("Person");
    }

    /**
     * createNode
     */
    @Test
    public void createNode_ShouldError() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        ExtendedBaseModel model = new ExtendedBaseModel(graph, "1234");

        try {
            model.createNode("LABEL");
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("You may not overwrite id");
        }
    }

    @Test
    public void createNode_ShouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        ExtendedBaseModel model = new ExtendedBaseModel(graph);

        Node node = model.createNode("LABEL");
        assertThat(node.getLabel()).isEqualTo("LABEL");
    }

    /**
     * getOrCreateNode
     */
    @Test
    public void getOrCreateNode_shouldCreateNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        ExtendedBaseModel model = new ExtendedBaseModel(graph);

        Node node = model.getOrCreateNode("LABEL");
        assertThat(node.getLabel()).isEqualTo("LABEL");
    }

    @Test
    public void getOrCreateNode_shouldGetNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Person").getId();
        ExtendedBaseModel model = new ExtendedBaseModel(graph, id);

        Node node = model.getOrCreateNode("Person");

        assertThat(node.getId()).isEqualTo(id);
    }

    /**
     * getId
     */
    @Test
    public void getId_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph, "1234");

        assertThat(baseModel.getId()).isEqualTo("1234");

        baseModel = new ExtendedBaseModel(graph);

        assertThat(baseModel.getId()).isNull();
    }

    /**
     * setId
     */
    @Test
    public void setId_shouldThrowError() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph, "1234");

        try {
            baseModel.setId("1234");
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("You may not overwrite id");
        }
    }

    @Test
    public void setId_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph);

        assertThat(baseModel.getId()).isNull();

        baseModel.setId("1234");

        assertThat(baseModel.getId()).isEqualTo("1234");
    }

    /**
     * get/setBoundary
     */
    @Test
    public void getSetBoundary_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph);

        assertThat(baseModel.getBoundary()).isNull();

        baseModel.setBoundary(true);

        assertThat(baseModel.getBoundary()).isTrue();
    }

    /**
     * get/setRepo
     */
    @Test
    public void getSetRepo_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph);

        assertThat(baseModel.getRepo()).isNull();

        baseModel.setRepo("repo1");

        assertThat(baseModel.getRepo()).isEqualTo("repo1");
    }

    /**
     * getProperty
     */
    @Test
    public void getProperty_shouldReturnNull() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode("label");

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph);

        assertThat(baseModel.getProperty(node, "key", String.class)).isNull();
    }

    @Test
    public void getProperty_shouldReturnString() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode("label");
        node.setProperty("key", "value");

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph);

        assertThat(baseModel.getProperty(node, "key", String.class)).isEqualTo("value");
    }

    /**
     * setOrRemoveProperty
     */
    @Test
    public void setOrRemoveProperty_shouldRemoveProperty() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode("label");
        node.setProperty("key", "value");

        assertThat(node.getProperty("key")).isEqualTo("value");

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph);
        baseModel.setOrRemoveProperty(node, "key", null);

        assertThat(node.getProperty("key")).isNull();
    }

    @Test
    public void setOrRemoveProperty_shouldSetProperty() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode("label");

        assertThat(node.getProperty("key")).isNull();

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph);
        baseModel.setOrRemoveProperty(node, "key", "value");

        assertThat(node.getProperty("key")).isEqualTo("value");
    }

    /**
     * getEdge
     */
    @Test
    public void getEdge_shouldReturnNull() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode("label");

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph);

        assertThat(baseModel.getEdge(node, Direction.OUT, "EDGE_LABEL")).isNull();
    }

    @Test
    public void getEdge_shouldReturnEdge() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        String id = node1.addEdge(node2, "EDGE_LABEL").getId();

        ExtendedBaseModel baseModel = new ExtendedBaseModel(graph);

        Edge edge = baseModel.getEdge(node1, Direction.OUT, "EDGE_LABEL");

        assertThat(edge).isNotNull();
        assertThat(edge.getId()).isEqualTo(id);
    }

    /**
     * equals
     */
    @Test
    public void equals_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = SpecialProperty.generateId();

        ExtendedBaseModel modelSansId1 = new ExtendedBaseModel(graph);
        ExtendedBaseModel modelSansId2 = new ExtendedBaseModel(graph);

        ExtendedBaseModel modelWithId1 = new ExtendedBaseModel(graph, id);
        ExtendedBaseModel modelWithId2 = new ExtendedBaseModel(graph, SpecialProperty.generateId());
        ExtendedBaseModel modelWithId3 = new ExtendedBaseModel(graph, id);

        // Check sans id
        assertThat(modelSansId1.equals(null)).isFalse();
        assertThat(modelSansId1.equals(modelSansId2)).isFalse();
        assertThat(modelSansId1.equals(modelWithId1)).isFalse();

        // Check with id
        assertThat(modelWithId1.equals(modelSansId1)).isFalse();
        assertThat(modelWithId1.equals(modelWithId2)).isFalse();
        assertThat(modelWithId1.equals(modelWithId1)).isTrue();
        assertThat(modelWithId1.equals(modelWithId3)).isTrue();
    }

    /**
     * hashCode
     */
    @Test
    public void hashCode_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = SpecialProperty.generateId();

        assertThat(new ExtendedBaseModel(graph, id).hashCode()).isEqualTo(id.hashCode());
        assertThat(new ExtendedBaseModel(graph).hashCode()).isNotNull();
    }

    private class ExtendedBaseModel extends BaseModel {

        public ExtendedBaseModel(VGraph graphInstance) {
            super(graphInstance);
        }

        public ExtendedBaseModel(VGraph graphInstance, String idInstance) {
            super(graphInstance, idInstance);
        }
    }

}

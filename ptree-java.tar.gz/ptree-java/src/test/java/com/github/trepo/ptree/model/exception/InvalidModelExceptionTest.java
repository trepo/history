package com.github.trepo.ptree.model.exception;

import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class InvalidModelExceptionTest {

    @Test
    public void shouldWork() {
        InvalidModelException e = new InvalidModelException("test");

        assertThat(e.getMessage()).isEqualTo("test");

        Exception newE = new Exception("underlying-exception");
        e = new InvalidModelException("main-exception", newE);

        assertThat(e.getMessage()).isEqualTo("main-exception");
        assertThat(e.getCause().getMessage()).isEqualTo("underlying-exception");
    }
}

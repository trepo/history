package com.github.trepo.ptree.rest.core;

import com.github.trepo.ptree.model.core.NodeModel;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class NodeTest {

    /**
     * get
     */
    @Test
    public void get_shouldReturn500() {
        Node node = new Node();
        try {
            node.get("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void get_shouldReturn404() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = new Node();
        node.setGraph(graph);
        try {
            node.get("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Node not found");
        }
    }

    @Test
    public void get_shouldReturn200() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        com.github.trepo.vgraph.Node graphNode = graph.addNode("label");
        graphNode.setProperty("test", true);

        Node node = new Node();
        node.setGraph(graph);

        Response response = node.get(graphNode.getId());

        assertThat(response.getStatus()).isEqualTo(200);
        NodeModel nodeModel = (NodeModel) response.getEntity();
        assertThat(nodeModel.getId()).isEqualTo(graphNode.getId());
        assertThat(nodeModel.getLabel()).isEqualTo("label");
        assertThat(nodeModel.getProperties().size()).isEqualTo(1);
        assertThat(nodeModel.getProperties().get("test")).isEqualTo(true);
    }
}

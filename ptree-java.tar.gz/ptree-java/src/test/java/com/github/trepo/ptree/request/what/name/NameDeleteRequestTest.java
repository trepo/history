package com.github.trepo.ptree.request.what.name;

import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.what.NameModel;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class NameDeleteRequestTest {
        private VGraph graph;

        @BeforeMethod
        public void setup() {
            graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        }

        /**
         * execute
         */
        @Test
        public void execute_shouldErrorIfLabelIsWrong() {
            String id = graph.addNode("Bogus").getId();

            assertThat(graph.getNode(id)).isNotNull();

            NameModel model = new NameModel(graph, id);

            try {
                new NameDeleteRequest().execute(model);
            } catch (ModelException e) {
                assertThat(e.getMessage()).isEqualTo("invalid label: expected Name but found Bogus");
            }

        }

        @Test
        public void execute_shouldWork() {
            String id = graph.addNode(Label.NAME).getId();

            assertThat(graph.getNode(id)).isNotNull();

            NameModel model = new NameModel(graph, id);
            new NameDeleteRequest().execute(model);

            assertThat(graph.getNode(id)).isNull();
        }
}

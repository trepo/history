package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.ref.Label;
import com.github.trepo.ptree.request.core.PlaceWriteRequest;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.fail;

/**
 * @author John Clark.
 */
public class PlaceModelTest {
    private VGraph graph;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
    }

    /**
     * PlaceModel(graph)
     */
    @Test
    public void constructor1_shouldWork() {
        PlaceModel model = new PlaceModel(graph);

        assertThat(model.getId()).isNull();
    }

    /**
     * PlaceModel(graph, id)
     */
    @Test
    public void constructor2_shouldWork() {
        PlaceModel model = new PlaceModel(graph, "1234");

        assertThat(model.getId()).isEqualTo("1234");
    }

    /**
     * readFromGraph
     */
    @Test
    public void readFromGraph_shouldError() {
        PlaceModel model = new PlaceModel(graph);

        try {
            model.readFromGraph();
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("Cannot read from graph: missing id");
        }
    }

    @Test
    public void readFromGraph_shouldWork() {
        Node node = graph.addNode(Label.PLACE);
        node.setProperty(Key.PLACE_NAME, "Knighton-on-teme");
        PlaceModel model = new PlaceModel(graph, node.getId());
        model.readFromGraph();

        assertThat(model.getBoundary()).isFalse();
        assertThat(model.getName()).isEqualTo("Knighton-on-teme");
    }

    /**
     * writeToGraph
     */
    @Test
    public void writeToGraph_shouldWork() {
        Node node = graph.addNode(Label.PLACE);
        node.setProperty(Key.PLACE_NAME, "somewhere");
        PlaceModel model = new PlaceModel(graph, node.getId());

        PlaceWriteRequest requestModel = new PlaceWriteRequest("Knighton-on-teme");

        model.writeToGraph(requestModel);


        assertThat(node.getProperty(Key.PLACE_NAME)).isEqualTo("Knighton-on-teme");
    }
}

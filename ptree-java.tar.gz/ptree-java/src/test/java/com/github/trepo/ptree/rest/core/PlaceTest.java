package com.github.trepo.ptree.rest.core;

import com.github.trepo.ptree.model.core.PlaceModel;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.ptree.request.core.PlaceWriteRequest;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Response;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class PlaceTest {

    /**
     * post
     */
    @Test
    public void post_shouldErrorOnValidation() {
        Place place = new Place();

        PlaceWriteRequest model = new PlaceWriteRequest(null);

        try {
            place.post(model);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(400);
            assertThat(e.getMessage()).isEqualTo("Invalid request: name may not be null");
        }
    }

    @Test
    public void post_shouldErrorOnGraphException() {
        Place place = new Place();

        PlaceWriteRequest model = new PlaceWriteRequest("Knighton-on-teme");

        try {
            place.post(model);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void post_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Place place = new Place();
        place.setGraph(graph);

        PlaceWriteRequest model = new PlaceWriteRequest("Knighton-on-teme");

        Response response = place.post(model);

        // Verify Response
        assertThat(response.getStatus()).isEqualTo(201);
        PlaceModel placeModel = (PlaceModel) response.getEntity();
        assertThat(placeModel.getName()).isEqualTo("Knighton-on-teme");

        // verify graph
        Node updated = graph.getNode(placeModel.getId());
        assertThat(updated.getProperty(Key.PLACE_NAME)).isEqualTo("Knighton-on-teme");
    }

    /**
     * get
     */
    @Test
    public void get_shouldErrorOnGraph() {
        Place place = new Place();

        try {
            place.get("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void get_shouldErrorOnMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Place place = new Place();
        place.setGraph(graph);

        try {
            place.get("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Place Not Found: node not found");
        }
    }

    @Test
    public void get_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Not_Place").getId();
        Place place = new Place();
        place.setGraph(graph);

        try {
            place.get(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Place Not Found: invalid label: expected Place but found Not_Place");
        }
    }

    @Test
    public void get_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode("Place");
        node.setProperty("name", "Knighton-on-teme");
        Place place = new Place();
        place.setGraph(graph);

        Response response = place.get(node.getId());

        assertThat(response.getStatus()).isEqualTo(200);
        PlaceModel placeModel = (PlaceModel) response.getEntity();
        assertThat(placeModel.getId()).isEqualTo(node.getId());
        assertThat(placeModel.getName()).isEqualTo("Knighton-on-teme");
    }

    /**
     * put
     */
    @Test
    public void put_shouldErrorOnValidation() {
        Place place = new Place();

        PlaceWriteRequest model = new PlaceWriteRequest(null);

        try {
            place.put(null, model);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(400);
            assertThat(e.getMessage()).isEqualTo("Invalid request: name may not be null");
        }
    }

    @Test
    public void put_shouldErrorOnGraphException() {
        Place place = new Place();

        PlaceWriteRequest model = new PlaceWriteRequest("Knighton-on-teme");

        try {
            place.put(null, model);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void put_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode("Place");
        node.setProperty("name", "Knighton-on-teme");
        Place place = new Place();
        place.setGraph(graph);

        PlaceWriteRequest model = new PlaceWriteRequest("Knighton-on-teme");

        Response response = place.put(node.getId(), model);

        // Verify Response
        assertThat(response.getStatus()).isEqualTo(200);
        PlaceModel placeModel = (PlaceModel) response.getEntity();
        assertThat(placeModel.getName()).isEqualTo("Knighton-on-teme");

        // verify graph
        Node updated = graph.getNode(placeModel.getId());
        assertThat(updated.getProperty(Key.PLACE_NAME)).isEqualTo("Knighton-on-teme");
    }

    /**
     * delete
     */
    @Test
    public void delete_shouldErrorOnGraph() {
        Place place = new Place();

        try {
            place.delete("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(500);
            assertThat(e.getMessage()).isEqualTo("Graph Exception: Graph is null");
        }
    }

    @Test
    public void delete_shouldErrorOnMissingNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Place place = new Place();
        place.setGraph(graph);

        try {
            place.delete("1234");
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Place Not Found: node not found");
        }
    }

    @Test
    public void delete_shouldErrorOnInvalidNode() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        String id = graph.addNode("Bogus").getId();
        Place place = new Place();
        place.setGraph(graph);

        try {
            place.delete(id);
        } catch (WebApplicationException e) {
            assertThat(e.getResponse().getStatus()).isEqualTo(404);
            assertThat(e.getMessage()).isEqualTo("Place Not Found: invalid label: expected Place but found Bogus");
        }
    }

    @Test
    public void delete_shouldWork() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        Node node = graph.addNode("Place");
        node.setProperty("name", "Knighton-on-teme");
        String id = node.getId();
        Place place = new Place();
        place.setGraph(graph);

        Response response = place.delete(id);

        assertThat(response.getStatus()).isEqualTo(204);
        assertThat(response.getEntity()).isNull();

        // Make sure node is gone
        assertThat(graph.getNode(id)).isNull();
    }
}

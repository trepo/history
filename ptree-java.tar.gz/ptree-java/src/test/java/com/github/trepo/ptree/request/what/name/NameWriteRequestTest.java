package com.github.trepo.ptree.request.what.name;

import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.what.NameModel;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.fail;

/**
 * @author John Clark.
 */
public class NameWriteRequestTest {
    private VGraph graph;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
    }

    /**
     * constructor + getters
     */
    @Test
    public void shouldWork() {
        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);

        assertThat(request.getName()).isEqualTo("Bob Freemer");
    }

    /**
     * validate
     */
    @Test
    public void validate_shouldError() {
        NameWriteRequest request = new NameWriteRequest(null, null);
        try {
            request.validate();
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("name may not be null");
        }
    }

    @Test
    public void validate_shouldWork() {
        NameWriteRequest request = new NameWriteRequest("Bob Freemer", null);
        request.validate();
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldErrorIfLabelIsWrong() {
        String id = graph.addNode("Bogus").getId();

        assertThat(graph.getNode(id)).isNotNull();

        NameModel model = new NameModel(graph, id);

        try {
            new NameWriteRequest("Bob Freemer", null).execute(model);
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("invalid label: expected Name but found Bogus");
        }
    }

    @Test
    public void execute_shouldUpdateCorrectly() {
        Node node = graph.addNode("Name");
        node.setProperty(Key.NAME_NAME, "Old Name");
        NameModel model = new NameModel(graph, node.getId());
        new NameWriteRequest("Bob Freemer", null).execute(model);

        assertThat(node.getProperty(Key.NAME_NAME)).isEqualTo("Bob Freemer");
    }

    @Test
    public void execute_shouldCreateCorrectly() {
        NameModel model = new NameModel(graph);
        new NameWriteRequest("Bob Freemer", null).execute(model);

        assertThat(model.getId()).isNotNull();

        Node node = graph.getNode(model.getId());

        assertThat(node.getProperty(Key.PLACE_NAME)).isEqualTo("Bob Freemer");
    }
}

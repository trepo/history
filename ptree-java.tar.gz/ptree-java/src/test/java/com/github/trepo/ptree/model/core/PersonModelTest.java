package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.request.core.PersonWriteRequest;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.fail;

/**
 * @author John Clark.
 */
public class PersonModelTest {

    private VGraph graph;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
    }

    /**
     * PersonModel(graph)
     */
    @Test
    public void constructor1_shouldWork() {
        PersonModel personModel = new PersonModel(graph);

        assertThat(personModel.getId()).isNull();
    }

    /**
     * PersonModel(graph, id)
     */
    @Test
    public void constructor2_shouldWork() {
        PersonModel personModel = new PersonModel(graph, "1234");

        assertThat(personModel.getId()).isEqualTo("1234");
    }

    /**
     * readFromGraph
     */
    @Test
    public void readFromGraph_shouldError() {
        PersonModel personModel = new PersonModel(graph);

        try {
            personModel.readFromGraph();
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("Cannot read from graph: missing id");
        }
    }

    @Test
    public void readFromGraph_shouldWork() {
        String id = graph.addNode("Person").getId();
        PersonModel personModel = new PersonModel(graph, id);
        personModel.readFromGraph();

        assertThat(personModel.getBoundary()).isFalse();
    }

    /**
     * writeToGraph
     */
    @Test
    public void writeToGraph_shouldWriteCorrectly() {
        PersonModel personModel = new PersonModel(graph);
        personModel.writeToGraph(new PersonWriteRequest());
        personModel.readFromGraph();
        String id = personModel.getId();

        assertThat(id).isNotNull();
        assertThat(personModel.getBoundary()).isFalse();

        // Make sure that everything got into the graph ok
        assertThat(graph.getNode(id).getLabel()).isEqualTo("Person");
    }
}

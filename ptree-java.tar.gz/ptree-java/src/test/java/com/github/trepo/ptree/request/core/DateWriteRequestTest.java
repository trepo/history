package com.github.trepo.ptree.request.core;

import com.github.trepo.ptree.model.core.DateModel;
import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.ref.Key;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.fail;

/**
 * @author John Clark.
 */
public class DateWriteRequestTest {

    private VGraph graph;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
    }

    /**
     * constructor + getters
     */
    @Test
    public void shouldWork() {
        DateWriteRequest request = new DateWriteRequest("1800", "+1800");

        assertThat(request.getOriginal()).isEqualTo("1800");
        assertThat(request.getFormal()).isEqualTo("+1800");
    }

    /**
     * validate
     */
    @Test
    public void validate_shouldError() {
        DateWriteRequest request = new DateWriteRequest(null, null);
        try {
            request.validate();
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("You must have either a formal or original date");
        }
    }

    @Test
    public void validate_shouldWork() {
        DateWriteRequest request = new DateWriteRequest(null, "+1800");
        request.validate();
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldErrorIfLabelIsWrong() {
        String id = graph.addNode("Bogus").getId();

        assertThat(graph.getNode(id)).isNotNull();

        DateModel model = new DateModel(graph, id);

        try {
            new DateWriteRequest(null, "+1800").execute(model);
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("invalid label: expected Date but found Bogus");
        }
    }

    @Test
    public void execute_shouldUpdateCorrectly() {
        Node node = graph.addNode("Date");
        node.setProperty(Key.DATE_ORIGINAL, "1800");
        DateModel model = new DateModel(graph, node.getId());
        new DateWriteRequest(null, "+1800").execute(model);

        assertThat(node.getProperty(Key.DATE_ORIGINAL)).isNull();
        assertThat(node.getProperty(Key.DATE_FORMAL)).isEqualTo("+1800");
    }

    @Test
    public void execute_shouldCreateCorrectly() {
        DateModel model = new DateModel(graph);
        new DateWriteRequest("1800", null).execute(model);

        assertThat(model.getId()).isNotNull();

        Node node = graph.getNode(model.getId());

        assertThat(node.getProperty(Key.DATE_ORIGINAL)).isEqualTo("1800");
        assertThat(node.getProperty(Key.DATE_FORMAL)).isNull();
    }
}

package com.github.trepo.ptree.model.exception;

import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class ModelExceptionTest {

    @Test
    public void shouldWork() {
        ModelException e = new ModelException("test");

        assertThat(e.getMessage()).isEqualTo("test");

        Exception newE = new Exception("underlying-exception");
        e = new ModelException("main-exception", newE);

        assertThat(e.getMessage()).isEqualTo("main-exception");
        assertThat(e.getCause().getMessage()).isEqualTo("underlying-exception");
    }
}

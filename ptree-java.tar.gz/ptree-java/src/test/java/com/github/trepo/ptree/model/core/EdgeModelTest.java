package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import java.util.HashMap;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.fail;

/**
 * @author John Clark.
 */
public class EdgeModelTest {

    /**
     * EdgeModel(graph, id)
     */
    @Test
    public void constructor_shouldThrowErrorOnNullGraph() {
        try {
            new EdgeModel(null, "1234");
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("Graph is null");
        }
    }

    @Test
    public void constructor2_shouldThrowErrorOnNullID() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        try {
            new EdgeModel(graph, null);
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("id is null");
        }
    }

    /**
     * readFromGraph
     */
    @Test
    public void readFromGraph_shouldThrowError() {

        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");

        EdgeModel edgeModel = new EdgeModel(graph, "1234");

        try {
            edgeModel.readFromGraph();
            fail("Should have thrown an error");
        } catch (NotFoundModelException e) {
            assertThat(e.getMessage()).isEqualTo("Cannot find Edge");
        }
    }

    @Test
    public void readFromGraph_shouldWork() {

        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        com.github.trepo.vgraph.Node fromNode = graph.addNode("label");
        com.github.trepo.vgraph.Node toNode = graph.addNode("label");
        com.github.trepo.vgraph.Edge graphEdge = fromNode.addEdge(toNode, "edgeLabel");
        graphEdge.setProperty("test", true);

        EdgeModel edgeModel = new EdgeModel(graph, graphEdge.getId());
        edgeModel.readFromGraph();

        assertThat(edgeModel.getId()).isEqualTo(graphEdge.getId());
        assertThat(edgeModel.getLabel()).isEqualTo("edgeLabel");
        HashMap<String, Object> properties = edgeModel.getProperties();
        assertThat(properties.size()).isEqualTo(1);
        assertThat(properties.get("test")).isEqualTo(true);

        assertThat(edgeModel.getFrom().getId()).isEqualTo(fromNode.getId());
        assertThat(edgeModel.getFrom().getLabel()).isEqualTo("label");

        assertThat(edgeModel.getTo().getId()).isEqualTo(toNode.getId());
        assertThat(edgeModel.getTo().getLabel()).isEqualTo("label");
    }
}

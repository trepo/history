package com.github.trepo.ptree.model.core;

import com.github.trepo.ptree.model.exception.ModelException;
import com.github.trepo.ptree.model.exception.NotFoundModelException;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import java.util.HashMap;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.fail;

/**
 * @author John Clark.
 */
public class NodeModelTest {

    /**
     * NodeModel(graph, id)
     */
    @Test
    public void constructor_shouldThrowErrorOnNullGraph() {
        try {
            new NodeModel(null, "1234");
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("Graph is null");
        }
    }

    @Test
    public void constructor2_shouldThrowErrorOnNullID() {
        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        try {
            new NodeModel(graph, null);
            fail("Should have thrown an error");
        } catch (ModelException e) {
            assertThat(e.getMessage()).isEqualTo("id is null");
        }
    }

    /**
     * readFromGraph
     */
    @Test
    public void readFromGraph_shouldThrowError() {

        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");

        NodeModel nodeModel = new NodeModel(graph, "1234");

        try {
            nodeModel.readFromGraph();
            fail("Should have thrown an error");
        } catch (NotFoundModelException e) {
            assertThat(e.getMessage()).isEqualTo("Cannot find Node");
        }
    }

    @Test
    public void readFromGraph_shouldWork() {

        VGraph graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        com.github.trepo.vgraph.Node graphNode = graph.addNode("label");
        graphNode.setProperty("test", true);

        NodeModel nodeModel = new NodeModel(graph, graphNode.getId());
        nodeModel.readFromGraph();

        assertThat(nodeModel.getId()).isEqualTo(graphNode.getId());
        assertThat(nodeModel.getLabel()).isEqualTo("label");
        assertThat(nodeModel.getBoundary()).isEqualTo(false);
        HashMap<String, Object> properties = nodeModel.getProperties();
        assertThat(properties.size()).isEqualTo(1);
        assertThat(properties.get("test")).isEqualTo(true);
    }
}

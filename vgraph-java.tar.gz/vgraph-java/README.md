# vGraph
A Java implementation of [vGraph](https://github.com/trepo/vgraph) built atop [Blueprints](http://blueprints.tinkerpop.com).

# Usage
````java
VGraph graph = new VGraph(new TinkerGraph());

Node node = graph.addNode("label");

node.setProperty("prop1", "value");

String prop1 = node.getProperty("prop1");
````

# Maven
Hosted on [Maven Central](http://search.maven.org/#search%7Cga%7C1%7Ca%3A%22vgraph%22).

````xml
<dependency>
  <groupId>com.github.trepo</groupId>
  <artifactId>vgraph</artifactId>
  <version>0.5.1</version>
</dependency>
````

# Javadoc
Viewable online [here](http://www.javadoc.io/doc/com.github.trepo/vgraph). Many thanks to [javadoc.io](http://www.javadoc.io) for the hosting.

# Tests
There is comprehensive unit tests available by running `mvn test`.

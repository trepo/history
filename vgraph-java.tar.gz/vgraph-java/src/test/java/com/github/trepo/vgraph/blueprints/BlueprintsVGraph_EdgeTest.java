package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraphException;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BlueprintsVGraph_EdgeTest {

    String repo = "repo";
    TinkerGraph tinkerGraph;
    BlueprintsVGraph graph;

    @BeforeMethod
    public void beforeTest() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
    }

    /**
     * addEdge
     */
    @Test
    public void addEdge_shouldErrorOnNullFrom() {
        try {
            graph.addEdge(null, null, null);
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("Invalid from");
        }
    }

    @Test
    public void addEdge_shouldAddEdge() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "EDGE_LABEL");

        assertThat(edge.getNode(com.github.trepo.vgraph.Direction.IN).getId()).isEqualTo(node2.getId());
        assertThat(edge.getNode(com.github.trepo.vgraph.Direction.OUT).getId()).isEqualTo(node1.getId());
    }

    @Test
    public void addEdge_shouldErrorOnDeletedFromNode() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");

        graph.removeNode(node1.getId());
        try {
            graph.addEdge(node1, node2, "EDGE");
            fail("Should have thrown error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Node deleted");
        }
    }

    /**
     * getEdge
     */
    @Test
    public void getEdge_shouldReturnNull() {
        Edge edge = graph.getEdge("1234");
        assertThat(edge).isEqualTo(null);
    }

    @Test
    public void getEdge_shouldReturnEdge() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "EDGE_LABEL");

        assertThat(graph.getEdge(edge.getId())).isEqualTo(edge);
    }

    @Test
    public void getEdge_shouldReturnNullWhenDeleted() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        String id = graph.addEdge(node1, node2, "EDGE_LABEL").getId();

        graph.removeEdge(id);

        assertThat(graph.getEdge(id)).isNull();
    }

    /**
     * removeEdge
     */
    @Test
    public void removeEdge_shouldSetDeleted() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "EDGE_LABEL");

        graph.removeEdge(edge.getId());

        Long timestamp = SpecialProperty.generateTimestamp();
        assertThat(timestamp-(Long)((BlueprintsEdge)edge).getBlueprintsEdge().getProperty(SpecialProperty.DELETED)).isLessThan(50);
    }

    /**
     * getEdges
     */
    @Test
    public void getEdges_shouldReturn0Edges() {
        int i = 0;
        for(Edge e: graph.getEdges()) {
            i++;
        }
        assertThat(i).isEqualTo(0);
    }

    @Test
    public void getEdges_shouldReturn2Edges() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge1 = graph.addEdge(node1, node2, "EDGE_LABEL");
        Edge edge2 = graph.addEdge(node1, node2, "EDGE_LABEL_TWO");

        int i = 0;
        for(Edge e: graph.getEdges()) {
            i++;
        }
        assertThat(i).isEqualTo(2);
    }

    @Test
    public void getEdges_shouldNotReturnDeletedEdges() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge1 = graph.addEdge(node1, node2, "EDGE_LABEL");
        graph.removeEdge(edge1.getId());
        int i = 0;
        for(Edge e: graph.getEdges()) {
            i++;
        }
        assertThat(i).isEqualTo(0);
    }

    /**
     * getEdges_key_value
     */
    @Test
    public void getEdges_key_value_shouldReturn1Edge() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge1 = graph.addEdge(node1, node2, "EDGE_LABEL");
        edge1.setProperty("key", "value");
        Edge edge2 = graph.addEdge(node1, node2, "EDGE_LABEL_TWO");

        int i = 0;
        for(Edge e: graph.getEdges("key", "value")) {
            assertThat(e.getId()).isEqualTo(edge1.getId());
            i++;
        }
        assertThat(i).isEqualTo(1);
    }

    @Test
    public void getEdges_key_value_shouldErrorOnInvalidKey() {
        try {
            graph.getEdges("1nvalid", "value");
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("Invalid Regular Key");
        }
    }

    @Test
    public void getEdges_key_value_shouldErrorOnInvalidValue() {
        try {
            graph.getEdges("invalid", new Object());
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("Invalid Regular Value");
        }
    }

    @Test
    public void getEdges_key_value_shouldNotReturnDeletedEdges() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge1 = graph.addEdge(node1, node2, "EDGE_LABEL");
        edge1.setProperty("key", "value");
        graph.removeEdge(edge1.getId());

        int i = 0;
        for(Edge e: graph.getEdges("key", "value")) {
            i++;
        }
        assertThat(i).isEqualTo(0);
    }
}

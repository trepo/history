package com.github.trepo.vgraph.blueprints.util;

import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.blueprints.BlueprintsNode;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.KeyIndexableGraph;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import java.util.Iterator;
import java.util.NoSuchElementException;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class NodeIterableTest {

    @Test
    public void shouldWorkCorrectly() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex node = graph.addVertex("1");
        node.setProperty(SpecialProperty.ID, "1");
        node.setProperty(SpecialProperty.LABEL, "label");
        node.setProperty("foo", "bar");
        node.setProperty(SpecialProperty.HASH, Util.calculateHash(new BlueprintsNode(node, null)));

        Vertex boundary = graph.addVertex("2");
        boundary.setProperty(SpecialProperty.ID, "2");
        boundary.setProperty(SpecialProperty.LABEL, "label2");
        boundary.setProperty(SpecialProperty.REPO, "repo2");

        int i = 0;
        for(Node n: new NodeIterable(graph.getVertices(), null)) {
            i++;
            if(n.getId().equals("1")) {
                assertThat(n.isBoundary()).isEqualTo(false);
            } else {
                assertThat(n.isBoundary()).isEqualTo(true);
            }
        }
        assertThat(i).isEqualTo(2);

    }

    @Test
    public void shouldReturn0When0Present() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");


        int i = 0;
        for(Node n: new NodeIterable(g.query().has(SpecialProperty.ID).vertices(), graph)) {
            i++;
        }
        assertThat(i).isEqualTo(0);
    }

    @Test
    public void shouldReturn0When1Present1Deleted() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        graph.removeNode(graph.addNode("label").getId());

        int i = 0;
        for(Node n: new NodeIterable(g.query().has(SpecialProperty.ID).vertices(), graph)) {
            i++;
        }
        assertThat(i).isEqualTo(0);

    }

    @Test
    public void shouldReturn1When2Present1Deleted() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        Node node = graph.addNode("label");
        graph.removeNode(graph.addNode("label").getId());

        int i = 0;
        for(Node n: new NodeIterable(g.query().has(SpecialProperty.ID).vertices(), graph)) {
            i++;
            assertThat(n.getId()).isEqualTo(node.getId());
        }
        assertThat(i).isEqualTo(1);
    }

    @Test
    public void shouldReturn0When2Present2Deleted() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        graph.removeNode(graph.addNode("label").getId());
        graph.removeNode(graph.addNode("label").getId());

        int i = 0;
        for(Node n: new NodeIterable(g.query().has(SpecialProperty.ID).vertices(), graph)) {
            i++;
        }
        assertThat(i).isEqualTo(0);
    }


    @Test
    public void shouldReturn3When5Present2Deleted() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        graph.addNode("label");
        graph.removeNode(graph.addNode("label").getId());
        graph.addNode("label");
        graph.removeNode(graph.addNode("label").getId());
        graph.addNode("label");

        int i = 0;
        for(Node n: new NodeIterable(g.query().has(SpecialProperty.ID).vertices(), graph)) {
            i++;
        }
        assertThat(i).isEqualTo(3);
    }

    @Test
    public void shouldErrorWhenCallingNextWithNoElements() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");

        Iterator itr = new NodeIterable(g.query().has(SpecialProperty.ID).vertices(), graph).iterator();

        try {
            itr.next();
            fail("Should have thrown error");
        } catch(NoSuchElementException e) {
            assertThat(e.getMessage()).isEqualTo("No more elements");
        }
    }

    @Test
    public void shouldFailOnRemove() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        graph.addNode("label");

        Iterator itr = new NodeIterable(g.query().has(SpecialProperty.ID).vertices(), graph).iterator();
        itr.next();
        try {
            itr.remove();
            fail("Should have failed on method not allowed");
        } catch(UnsupportedOperationException e) {
            assertThat(e.getMessage()).isEqualTo("Method not implemented");
        }
    }
}

package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.LogEntry;
import com.github.trepo.vgraph.VGraphException;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.List;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BlueprintsVGraph_LogTest {

    String repo = "repo";
    TinkerGraph tinkerGraph;
    BlueprintsVGraph graph;

    @BeforeMethod
    public void beforeTest() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
    }

    /**
     * log
     */
    @Test
    public void log_shouldHandleInvalidParameters() {

        // -1, 0
        try {
            graph.log(-1,0);
            fail("should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("number must be > 0");
        }

        // 0, 0
        try {
            graph.log(0,0);
            fail("should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("number must be > 0");
        }

        // 1, -1
        try {
            graph.log(1,-1);
            fail("should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("offset must be >= 0");
        }
    }

    @Test
    public void log_shouldWorkWith0Commits() {

        // 1,0
        assertThat(graph.log(1,0).size()).isEqualTo(0);

        // 10,0
        assertThat(graph.log(10,0).size()).isEqualTo(0);

        // 10,1
        assertThat(graph.log(10,1).size()).isEqualTo(0);

        // 10,5
        assertThat(graph.log(10,5).size()).isEqualTo(0);
    }

    @Test
    public void log_shouldWorkWith1Commit() {
        graph.addNode("label");
        Commit commit = graph.commit("author", "email", "message");

        List<LogEntry> entries;

        // 1,0
        entries = graph.log(1,0);
        assertThat(entries.size()).isEqualTo(1);
        LogEntry entry = entries.get(0);

        assertThat(entry.getId()).isEqualTo(commit.getId());
        assertThat(entry.getTimestamp()).isEqualTo(commit.getTimestamp());
        assertThat(entry.getAuthor()).isEqualTo(commit.getAuthor());
        assertThat(entry.getEmail()).isEqualTo(commit.getEmail());
        assertThat(entry.getMessage()).isEqualTo(commit.getMessage());

        // 10,0
        entries = graph.log(10,0);
        assertThat(entries.size()).isEqualTo(1);
        assertThat(entries.get(0).getId()).isEqualTo(commit.getId());

        // 10,1
        entries = graph.log(10,1);
        assertThat(entries.size()).isEqualTo(0);
    }

    @Test
    public void log_shouldWorkWith5Commits() {
        graph.addNode("label");
        String commit1 = graph.commit("author", "email", "message").getId();
        graph.addNode("label");
        String commit2 = graph.commit("author", "email", "message").getId();
        graph.addNode("label");
        String commit3 = graph.commit("author", "email", "message").getId();
        graph.addNode("label");
        String commit4 = graph.commit("author", "email", "message").getId();
        graph.addNode("label");
        String commit5 = graph.commit("author", "email", "message").getId();

        List<LogEntry> entries;

        // 1,0
        entries = graph.log(1,0);
        assertThat(entries.size()).isEqualTo(1);
        assertThat(entries.get(0).getId()).isEqualTo(commit5);

        // 2,1
        entries = graph.log(2,1);
        assertThat(entries.size()).isEqualTo(2);
        assertThat(entries.get(0).getId()).isEqualTo(commit4);
        assertThat(entries.get(1).getId()).isEqualTo(commit3);

        // 5,0
        entries = graph.log(5,0);
        assertThat(entries.size()).isEqualTo(5);
        assertThat(entries.get(0).getId()).isEqualTo(commit5);
        assertThat(entries.get(1).getId()).isEqualTo(commit4);
        assertThat(entries.get(2).getId()).isEqualTo(commit3);
        assertThat(entries.get(3).getId()).isEqualTo(commit2);
        assertThat(entries.get(4).getId()).isEqualTo(commit1);

        // 5,1
        entries = graph.log(5,1);
        assertThat(entries.size()).isEqualTo(4);
        assertThat(entries.get(0).getId()).isEqualTo(commit4);
        assertThat(entries.get(1).getId()).isEqualTo(commit3);
        assertThat(entries.get(2).getId()).isEqualTo(commit2);
        assertThat(entries.get(3).getId()).isEqualTo(commit1);

        // 6,0
        entries = graph.log(6,0);
        assertThat(entries.size()).isEqualTo(5);
        assertThat(entries.get(0).getId()).isEqualTo(commit5);
        assertThat(entries.get(1).getId()).isEqualTo(commit4);
        assertThat(entries.get(2).getId()).isEqualTo(commit3);
        assertThat(entries.get(3).getId()).isEqualTo(commit2);
        assertThat(entries.get(4).getId()).isEqualTo(commit1);

        // 10,0
        entries = graph.log(10,0);
        assertThat(entries.size()).isEqualTo(5);
        assertThat(entries.get(0).getId()).isEqualTo(commit5);
        assertThat(entries.get(1).getId()).isEqualTo(commit4);
        assertThat(entries.get(2).getId()).isEqualTo(commit3);
        assertThat(entries.get(3).getId()).isEqualTo(commit2);
        assertThat(entries.get(4).getId()).isEqualTo(commit1);

        // 10,2
        entries = graph.log(10,2);
        assertThat(entries.size()).isEqualTo(3);
        assertThat(entries.get(0).getId()).isEqualTo(commit3);
        assertThat(entries.get(1).getId()).isEqualTo(commit2);
        assertThat(entries.get(2).getId()).isEqualTo(commit1);

        // 10,4
        entries = graph.log(10,4);
        assertThat(entries.size()).isEqualTo(1);
        assertThat(entries.get(0).getId()).isEqualTo(commit1);

        // 10,5
        entries = graph.log(10,5);
        assertThat(entries.size()).isEqualTo(0);
    }

}

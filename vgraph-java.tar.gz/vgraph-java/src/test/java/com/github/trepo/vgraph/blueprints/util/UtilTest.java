package com.github.trepo.vgraph.blueprints.util;

import com.github.trepo.vgraph.Action;
import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.CommitEdge;
import com.github.trepo.vgraph.CommitNode;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.MetaProperty;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraphException;
import com.github.trepo.vgraph.blueprints.BlueprintsNode;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tinkerpop.blueprints.Edge;
import com.tinkerpop.blueprints.KeyIndexableGraph;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class UtilTest {

    /**
     * #
     */
    @Test
    public void instantiate() throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class<?> thisClass = Util.class;

        // Final and only 1 constructor
        assertThat(Modifier.isFinal(thisClass.getModifiers())).isEqualTo(true);
        assertThat(thisClass.getDeclaredConstructors().length).isEqualTo(1);

        // Make sure constructor is private
        final Constructor<?> constructor = thisClass.getDeclaredConstructor();
        assertThat(constructor.isAccessible()).isEqualTo(false);
        assertThat(Modifier.isPrivate(constructor.getModifiers())).isEqualTo(true);
        constructor.setAccessible(true);
        constructor.newInstance();
        constructor.setAccessible(false);

        // All methods must be static
        for (final Method method : Util.class.getMethods()) {
            if (!Modifier.isStatic(method.getModifiers())
                    && method.getDeclaringClass().equals(thisClass)) {
                fail("Non static method:"+method);
            }
        }
    }

    /**
     * blueprintsDirection
     */
    @Test
    public void blueprintsDirection_shouldReturnIn() {
        assertThat(Util.blueprintsDirection(Direction.IN)).isEqualTo(com.tinkerpop.blueprints.Direction.IN);
    }

    @Test
    public void blueprintsDirection_shouldReturnOut() {
        assertThat(Util.blueprintsDirection(Direction.OUT)).isEqualTo(com.tinkerpop.blueprints.Direction.OUT);
    }

    @Test
    public void blueprintsDirection_shouldReturnBoth() {
        assertThat(Util.blueprintsDirection(Direction.BOTH)).isEqualTo(com.tinkerpop.blueprints.Direction.BOTH);
    }

    /**
     * serializeProperties
     */
    @Test
    public void serializeProperties_shouldWork() {
        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", true);

        String serialized = Util.serializeProperties(properties);

        assertThat(serialized).isEqualTo("{\"testing\":true}");
    }

    /**
     * deserializeProperties
     */
    @Test
    public void deserializeProperties_shouldWork() {
        String serialized = "{\"testing\":true,\"foo\":\"bar\",\"arr\":[1,3,2]}";

        Map<String, Object> properties = Util.deserializeProperties(serialized);

        assertThat(properties.keySet().size()).isEqualTo(3);
        assertThat(properties.get("testing")).isEqualTo(true);
        assertThat(properties.get("foo")).isEqualTo("bar");
        assertThat(properties.get("arr")).isEqualTo(Arrays.asList(1.0,3.0,2.0));
    }

    /**
     * getProperties - Blueprints Element
     */
    @Test
    public void getProperties_blueprints_shouldWork() {
        KeyIndexableGraph g = new TinkerGraph();
        Vertex v = g.addVertex("1234");
        v.setProperty(SpecialProperty.ID, "1234");
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty("testing", true);
        v.setProperty("foo", "bar");

        Map<String, Object> properties = Util.getProperties(v);
        assertThat(properties.keySet().size()).isEqualTo(2);
        assertThat(properties.get("testing")).isEqualTo(true);
        assertThat(properties.get("foo")).isEqualTo("bar");
    }

    /**
     * getProperties - vGraph Element
     */
    @Test
    public void getProperties_vGraph_shouldWork() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        Node node = graph.addNode("label");
        node.setProperty("testing", true);
        node.setProperty("foo", "bar");

        Map<String, Object> properties = Util.getProperties(node);
        assertThat(properties.keySet().size()).isEqualTo(2);
        assertThat(properties.get("testing")).isEqualTo(true);
        assertThat(properties.get("foo")).isEqualTo("bar");
    }

    /**
     * calculateHash - Blueprints Element
     */
    @Test
    public void calculateHash_blueprints_shouldReturnCorrectHash() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1234");

        // Should be empty
        assertThat(Util.calculateHash(v)).isEqualTo("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        // Should still be empty (ignoring non regular properties)
        v.setProperty("__label", "foo");
        assertThat(Util.calculateHash(v)).isEqualTo("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        // Should still be empty (ignoring bogus properties
        v.setProperty("0bogus", "foo");
        assertThat(Util.calculateHash(v)).isEqualTo("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        // Should have 1 property
        v.setProperty("prop", "foo");
        assertThat(Util.calculateHash(v)).isEqualTo("91af72e0584d81d34a1aa9d47b8227d87611cd1c");

        // Should have 2 properties
        v.setProperty("bool", true);
        assertThat(Util.calculateHash(v)).isEqualTo("9d6654ff4cf10fe2edb0646648db914a9e0c655d");

        // And again with 3 (being an array)
        v.setProperty("cars",Arrays.asList("zed", "alpha", "nosorty", "bwahahaha"));
        assertThat(Util.calculateHash(v)).isEqualTo("cf975181076e171267358113c09bc1fe0e69a7c3");
    }

    /**
     * calculateHash - vGraph Element
     */
    @Test
    public void calculateHash_vGraph_shouldReturnCorrectHash() {

        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");
        BlueprintsNode n = new BlueprintsNode(v, null);

        // Should be empty
        assertThat(Util.calculateHash(n)).isEqualTo("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        // Should still be empty (ignoring non regular properties)
        v.setProperty("__label", "foo");
        assertThat(Util.calculateHash(n)).isEqualTo("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        // Should still be empty (ignoring bogus properties
        v.setProperty("0bogus", "foo");
        assertThat(Util.calculateHash(n)).isEqualTo("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f");

        // Should have 1 property
        v.setProperty("prop", "foo");
        assertThat(Util.calculateHash(n)).isEqualTo("91af72e0584d81d34a1aa9d47b8227d87611cd1c");

        // Should have 2 properties
        v.setProperty("bool", true);
        assertThat(Util.calculateHash(n)).isEqualTo("9d6654ff4cf10fe2edb0646648db914a9e0c655d");

        // And again with 3 (being an array)
        v.setProperty("cars",Arrays.asList("zed", "alpha", "nosorty", "bwahahaha"));
        assertThat(Util.calculateHash(n)).isEqualTo("cf975181076e171267358113c09bc1fe0e69a7c3");
    }

    /**
     * commitNodeFromCommit
     */
    @Test
    public void commitNodeFromCommit_shouldWork() {
        KeyIndexableGraph graph = new TinkerGraph();

        CommitNode node = new CommitNode()
                .setId("4e78dce2-acfa-4856-9da4-f81cbec8b0bf")
                .setLabel("node_label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setHash("bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f")
                .setProperties(new HashMap<String, Object>());

        HashSet<CommitNode> nodes = new HashSet<>();
        nodes.add(node);

        Commit commit = new Commit()
                .setVersion(1)
                .setId(SpecialProperty.generateId())
                .setPrev(SpecialProperty.generateId())
                .setTimestamp(SpecialProperty.generateTimestamp())
                .setRepo("repo")
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(nodes)
                .setEdges(new HashSet<CommitEdge>());

        Vertex commitNode = Util.commitNodeFromCommit(commit, graph);

        assertThat(commitNode.getProperty(MetaProperty.KEY)).isEqualTo(MetaProperty.COMMIT_NODE);
        assertThat(commitNode.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit.getId());
        assertThat(commitNode.getProperty(MetaProperty.COMMIT_REPO)).isEqualTo(commit.getRepo());
        assertThat(commitNode.getProperty(MetaProperty.COMMIT_TIMESTAMP)).isEqualTo(commit.getTimestamp());
        assertThat(commitNode.getProperty(MetaProperty.COMMIT_AUTHOR)).isEqualTo(commit.getAuthor());
        assertThat(commitNode.getProperty(MetaProperty.COMMIT_EMAIL)).isEqualTo(commit.getEmail());
        assertThat(commitNode.getProperty(MetaProperty.COMMIT_MESSAGE)).isEqualTo(commit.getMessage());

        String nodesString = commitNode.getProperty(MetaProperty.COMMIT_NODES);
        Set<CommitNode> inflatedNodes = new Gson().fromJson(nodesString,
                new TypeToken<Set<CommitNode>>() { } .getType());

        assertThat(inflatedNodes.size()).isEqualTo(1);

        assertThat(commitNode.getProperty(MetaProperty.COMMIT_EDGES)).isEqualTo("[]");
    }

    /**
     * commitFromCommitNode
     */
    @Test
    public void commitFromCommitNode_shouldWork() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");

        String commitId = SpecialProperty.generateId();
        Long timestamp = SpecialProperty.generateTimestamp();

        v.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        v.setProperty(MetaProperty.COMMIT_ID, commitId);
        v.setProperty(MetaProperty.COMMIT_REPO, "repo");
        v.setProperty(MetaProperty.COMMIT_TIMESTAMP, timestamp);
        v.setProperty(MetaProperty.COMMIT_AUTHOR, "author");
        v.setProperty(MetaProperty.COMMIT_EMAIL, "email");
        v.setProperty(MetaProperty.COMMIT_MESSAGE, "message");
        v.setProperty(MetaProperty.COMMIT_NODES, "[{\"id\":\"4e78dce2-acfa-4856-9da4-f81cbec8b0bf\",\"label\":\"node_label\",\"action\":\"create\",\"boundary\":false,\"hash\":\"bf21a9e8fbc5a3846fb05b4fa0859e0917b2202f\",\"properties\":{}}]");
        v.setProperty(MetaProperty.COMMIT_EDGES, "[]");

        Commit commit = Util.commitFromCommitNode(v);

        assertThat(commit.getVersion()).isEqualTo(1);
        assertThat(commit.getId()).isEqualTo(commitId);
        assertThat(commit.getRepo()).isEqualTo("repo");
        assertThat(commit.getTimestamp()).isEqualTo(timestamp);
        assertThat(commit.getAuthor()).isEqualTo("author");
        assertThat(commit.getEmail()).isEqualTo("email");
        assertThat(commit.getMessage()).isEqualTo("message");
        assertThat(commit.getEdges().size()).isEqualTo(0);
        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);
        CommitNode node = (CommitNode) nodes.toArray()[0];
        assertThat(node.getId()).isEqualTo("4e78dce2-acfa-4856-9da4-f81cbec8b0bf");
    }

    /**
     * createCommitNode
     */
    @Test
    public void createCommitNode_shouldMakeCreateNode() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");

        String nodeId = SpecialProperty.generateId();

        v.setProperty(SpecialProperty.ID, nodeId);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty("prop", "foo");

        Map<String, Object> properties = new HashMap<>();
        properties.put("prop", "foo");

        CommitNode commitNode = Util.createCommitNode(v, Action.CREATE, null);

        assertThat(commitNode.getId()).isEqualTo(nodeId);
        assertThat(commitNode.getLabel()).isEqualTo("label");
        assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
        assertThat(commitNode.isBoundary()).isFalse();
        assertThat(commitNode.getRepo()).isNull();
        assertThat(commitNode.getOriginal()).isNull();
        assertThat(commitNode.getProperties()).isEqualTo(properties);
        assertThat(commitNode.getHash()).isEqualTo("91af72e0584d81d34a1aa9d47b8227d87611cd1c");
    }

    @Test
    public void createCommitNode_shouldMakeCreateBoundary() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");

        String nodeId = SpecialProperty.generateId();

        v.setProperty(SpecialProperty.ID, nodeId);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "repo1");

        CommitNode commitNode = Util.createCommitNode(v, Action.CREATE, "repo1");

        assertThat(commitNode.getId()).isEqualTo(nodeId);
        assertThat(commitNode.getLabel()).isEqualTo("label");
        assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
        assertThat(commitNode.isBoundary()).isTrue();
        assertThat(commitNode.getRepo()).isEqualTo("repo1");
        assertThat(commitNode.getOriginal()).isNull();
        assertThat(commitNode.getProperties()).isNull();
        assertThat(commitNode.getHash()).isNull();
    }

    @Test
    public void createCommitNode_shouldMakeUpdateNode() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");

        String nodeId = SpecialProperty.generateId();

        v.setProperty(SpecialProperty.ID, nodeId);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.ORIGINAL, "{\"testing\":true}");
        v.setProperty("prop", "foo");

        Map<String, Object> original = new HashMap<>();
        original.put("testing", true);

        Map<String, Object> properties = new HashMap<>();
        properties.put("prop", "foo");

        CommitNode commitNode = Util.createCommitNode(v, Action.UPDATE, null);

        assertThat(commitNode.getId()).isEqualTo(nodeId);
        assertThat(commitNode.getLabel()).isEqualTo("label");
        assertThat(commitNode.getAction()).isEqualTo(Action.UPDATE);
        assertThat(commitNode.isBoundary()).isFalse();
        assertThat(commitNode.getRepo()).isNull();
        assertThat(commitNode.getOriginal()).isEqualTo(original);
        assertThat(commitNode.getProperties()).isEqualTo(properties);
        assertThat(commitNode.getHash()).isEqualTo("91af72e0584d81d34a1aa9d47b8227d87611cd1c");
    }

    @Test
    public void createCommitNode_shouldErrorOnUpdateBoundary() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");

        String nodeId = SpecialProperty.generateId();

        v.setProperty(SpecialProperty.ID, nodeId);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "repo1");

        try {
            Util.createCommitNode(v, Action.UPDATE, "repo1");
            fail("should have thrown error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("You cannot update a boundary node");
        }


    }

    @Test
    public void createCommitNode_shouldMakeDeleteNode() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");

        String nodeId = SpecialProperty.generateId();

        v.setProperty(SpecialProperty.ID, nodeId);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.DELETED, SpecialProperty.generateTimestamp());
        v.setProperty("prop", "foo");

        Map<String, Object> properties = new HashMap<>();
        properties.put("prop", "foo");

        CommitNode commitNode = Util.createCommitNode(v, Action.DELETE, null);

        assertThat(commitNode.getId()).isEqualTo(nodeId);
        assertThat(commitNode.getLabel()).isEqualTo("label");
        assertThat(commitNode.getAction()).isEqualTo(Action.DELETE);
        assertThat(commitNode.isBoundary()).isFalse();
        assertThat(commitNode.getRepo()).isNull();
        assertThat(commitNode.getOriginal()).isEqualTo(properties);
        assertThat(commitNode.getProperties()).isNull();
        assertThat(commitNode.getHash()).isNull();
    }

    @Test
    public void createCommitNode_shouldMakeDeleteNodeWithUpdatedNode() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");

        String nodeId = SpecialProperty.generateId();

        v.setProperty(SpecialProperty.ID, nodeId);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.DELETED, SpecialProperty.generateTimestamp());
        v.setProperty(SpecialProperty.ORIGINAL, "{\"testing\":true}");
        v.setProperty("prop", "foo");

        Map<String, Object> properties = new HashMap<>();
        properties.put("testing", true);

        CommitNode commitNode = Util.createCommitNode(v, Action.DELETE, null);

        assertThat(commitNode.getId()).isEqualTo(nodeId);
        assertThat(commitNode.getLabel()).isEqualTo("label");
        assertThat(commitNode.getAction()).isEqualTo(Action.DELETE);
        assertThat(commitNode.isBoundary()).isFalse();
        assertThat(commitNode.getRepo()).isNull();
        assertThat(commitNode.getOriginal()).isEqualTo(properties);
        assertThat(commitNode.getProperties()).isNull();
        assertThat(commitNode.getHash()).isNull();
    }

    @Test
    public void createCommitNode_shouldMakeDeleteBoundary() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");

        String nodeId = SpecialProperty.generateId();

        v.setProperty(SpecialProperty.ID, nodeId);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "repo1");

        CommitNode commitNode = Util.createCommitNode(v, Action.DELETE, "repo1");

        assertThat(commitNode.getId()).isEqualTo(nodeId);
        assertThat(commitNode.getLabel()).isEqualTo("label");
        assertThat(commitNode.getAction()).isEqualTo(Action.DELETE);
        assertThat(commitNode.isBoundary()).isTrue();
        assertThat(commitNode.getRepo()).isEqualTo("repo1");
        assertThat(commitNode.getOriginal()).isNull();
        assertThat(commitNode.getProperties()).isNull();
        assertThat(commitNode.getHash()).isNull();
    }

    @Test
    public void createCommitNode_shouldErrorOnUnknownAction() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");

        String nodeId = SpecialProperty.generateId();

        v.setProperty(SpecialProperty.ID, nodeId);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "repo1");

        try {
            Util.createCommitNode(v, "bogus", "repo1");
            fail("should have thrown error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Unknown Action");
        }
    }

    /**
     * createCommitEdge
     */
    // TODO
    @Test
    public void createCommitEdge_shouldMakeCreateEdge() {
        KeyIndexableGraph graph = new TinkerGraph();

        Vertex from = graph.addVertex("1");
        String fromId = SpecialProperty.generateId();
        from.setProperty(SpecialProperty.ID, fromId);
        from.setProperty(SpecialProperty.LABEL, "label");

        Vertex to = graph.addVertex("2");
        String toId = SpecialProperty.generateId();
        to.setProperty(SpecialProperty.ID, toId);
        to.setProperty(SpecialProperty.LABEL, "label");

        Edge edge = from.addEdge("edge_label", to);
        String edgeId = SpecialProperty.generateId();
        edge.setProperty(SpecialProperty.ID, edgeId);
        edge.setProperty(SpecialProperty.LABEL, "edge_label");
        edge.setProperty("prop", "foo");

        Map<String, Object> properties = new HashMap<>();
        properties.put("prop", "foo");

        CommitEdge commitEdge = Util.createCommitEdge(edge, Action.CREATE);

        assertThat(commitEdge.getId()).isEqualTo(edgeId);
        assertThat(commitEdge.getLabel()).isEqualTo("edge_label");
        assertThat(commitEdge.getFrom()).isEqualTo(fromId);
        assertThat(commitEdge.getTo()).isEqualTo(toId);
        assertThat(commitEdge.getAction()).isEqualTo(Action.CREATE);
        assertThat(commitEdge.getOriginal()).isNull();
        assertThat(commitEdge.getProperties()).isEqualTo(properties);
        assertThat(commitEdge.getHash()).isEqualTo("91af72e0584d81d34a1aa9d47b8227d87611cd1c");
    }

    @Test
    public void createCommitEdge_shouldMakeUpdateEdge() {
        KeyIndexableGraph graph = new TinkerGraph();

        Vertex from = graph.addVertex("1");
        String fromId = SpecialProperty.generateId();
        from.setProperty(SpecialProperty.ID, fromId);
        from.setProperty(SpecialProperty.LABEL, "label");

        Vertex to = graph.addVertex("2");
        String toId = SpecialProperty.generateId();
        to.setProperty(SpecialProperty.ID, toId);
        to.setProperty(SpecialProperty.LABEL, "label");

        Edge edge = from.addEdge("edge_label", to);
        String edgeId = SpecialProperty.generateId();
        edge.setProperty(SpecialProperty.ID, edgeId);
        edge.setProperty(SpecialProperty.LABEL, "edge_label");
        edge.setProperty(SpecialProperty.ORIGINAL, "{\"testing\":true}");
        edge.setProperty("prop", "foo");

        Map<String, Object> original = new HashMap<>();
        original.put("testing", true);

        Map<String, Object> properties = new HashMap<>();
        properties.put("prop", "foo");

        CommitEdge commitEdge = Util.createCommitEdge(edge, Action.UPDATE);

        assertThat(commitEdge.getId()).isEqualTo(edgeId);
        assertThat(commitEdge.getLabel()).isEqualTo("edge_label");
        assertThat(commitEdge.getFrom()).isEqualTo(fromId);
        assertThat(commitEdge.getTo()).isEqualTo(toId);
        assertThat(commitEdge.getAction()).isEqualTo(Action.UPDATE);
        assertThat(commitEdge.getOriginal()).isEqualTo(original);
        assertThat(commitEdge.getProperties()).isEqualTo(properties);
        assertThat(commitEdge.getHash()).isEqualTo("91af72e0584d81d34a1aa9d47b8227d87611cd1c");
    }

    @Test
    public void createCommitEdge_shouldMakeDeleteEdge() {
        KeyIndexableGraph graph = new TinkerGraph();

        Vertex from = graph.addVertex("1");
        String fromId = SpecialProperty.generateId();
        from.setProperty(SpecialProperty.ID, fromId);
        from.setProperty(SpecialProperty.LABEL, "label");

        Vertex to = graph.addVertex("2");
        String toId = SpecialProperty.generateId();
        to.setProperty(SpecialProperty.ID, toId);
        to.setProperty(SpecialProperty.LABEL, "label");

        Edge edge = from.addEdge("edge_label", to);
        String edgeId = SpecialProperty.generateId();
        edge.setProperty(SpecialProperty.ID, edgeId);
        edge.setProperty(SpecialProperty.LABEL, "edge_label");
        edge.setProperty("prop", "foo");

        Map<String, Object> properties = new HashMap<>();
        properties.put("prop", "foo");

        CommitEdge commitEdge = Util.createCommitEdge(edge, Action.DELETE);

        assertThat(commitEdge.getId()).isEqualTo(edgeId);
        assertThat(commitEdge.getLabel()).isEqualTo("edge_label");
        assertThat(commitEdge.getFrom()).isEqualTo(fromId);
        assertThat(commitEdge.getTo()).isEqualTo(toId);
        assertThat(commitEdge.getAction()).isEqualTo(Action.DELETE);
        assertThat(commitEdge.getOriginal()).isEqualTo(properties);
        assertThat(commitEdge.getProperties()).isNull();
        assertThat(commitEdge.getHash()).isNull();
    }

    @Test
    public void createCommitEdge_shouldMakeDeleteEdgeWithUpdatedEdge() {
        KeyIndexableGraph graph = new TinkerGraph();

        Vertex from = graph.addVertex("1");
        String fromId = SpecialProperty.generateId();
        from.setProperty(SpecialProperty.ID, fromId);
        from.setProperty(SpecialProperty.LABEL, "label");

        Vertex to = graph.addVertex("2");
        String toId = SpecialProperty.generateId();
        to.setProperty(SpecialProperty.ID, toId);
        to.setProperty(SpecialProperty.LABEL, "label");

        Edge edge = from.addEdge("edge_label", to);
        String edgeId = SpecialProperty.generateId();
        edge.setProperty(SpecialProperty.ID, edgeId);
        edge.setProperty(SpecialProperty.LABEL, "edge_label");
        edge.setProperty(SpecialProperty.ORIGINAL, "{\"testing\":true}");
        edge.setProperty("prop", "foo");

        Map<String, Object> properties = new HashMap<>();
        properties.put("testing", true);

        CommitEdge commitEdge = Util.createCommitEdge(edge, Action.DELETE);

        assertThat(commitEdge.getId()).isEqualTo(edgeId);
        assertThat(commitEdge.getLabel()).isEqualTo("edge_label");
        assertThat(commitEdge.getFrom()).isEqualTo(fromId);
        assertThat(commitEdge.getTo()).isEqualTo(toId);
        assertThat(commitEdge.getAction()).isEqualTo(Action.DELETE);
        assertThat(commitEdge.getOriginal()).isEqualTo(properties);
        assertThat(commitEdge.getProperties()).isNull();
        assertThat(commitEdge.getHash()).isNull();
    }

    @Test
    public void createCommitEdge_shouldErrorOnUnknownAction() {
        KeyIndexableGraph graph = new TinkerGraph();

        Vertex from = graph.addVertex("1");
        String fromId = SpecialProperty.generateId();
        from.setProperty(SpecialProperty.ID, fromId);
        from.setProperty(SpecialProperty.LABEL, "label");

        Vertex to = graph.addVertex("2");
        String toId = SpecialProperty.generateId();
        to.setProperty(SpecialProperty.ID, toId);
        to.setProperty(SpecialProperty.LABEL, "label");

        Edge edge = from.addEdge("edge_label", to);
        String edgeId = SpecialProperty.generateId();
        edge.setProperty(SpecialProperty.ID, edgeId);
        edge.setProperty(SpecialProperty.LABEL, "edge_label");
        edge.setProperty("prop", "foo");

        try {
            Util.createCommitEdge(edge, "bogus");
            fail("should have thrown error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Unknown Action");
        }
    }
}

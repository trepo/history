package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraphException;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BlueprintsVGraph_PatchTest {

    String sourceRepo = "source";
    TinkerGraph sourceTinkerGraph;
    BlueprintsVGraph sourceGraph;

    String destinationRepo = "source";
    TinkerGraph destinationTinkerGraph;
    BlueprintsVGraph destinationGraph;

    @BeforeMethod
    public void beforeTest() {
        sourceTinkerGraph = new TinkerGraph();
        sourceGraph = new BlueprintsVGraph(sourceTinkerGraph, sourceRepo);

        destinationTinkerGraph = new TinkerGraph();
        destinationGraph = new BlueprintsVGraph(destinationTinkerGraph, destinationRepo);
    }

    /**
     * patch
     */
    @Test(expectedExceptions = VGraphException.class)
    public void patch_shouldErrorOnInvalidCommit() {
        destinationGraph.patch(new Commit());
    }

    @Test
    public void patch_shouldErrorOnDirtyGraph() {
        Node node = sourceGraph.addNode("label");
        node.setProperty("key", "value");
        Commit commit = sourceGraph.commit("author","email", "message");

        destinationGraph.addNode("label");

        try {
            destinationGraph.patch(commit);
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("cannot patch a dirty graph");
        }

    }

    @Test
    public void patch_shouldErrorOnNullCommitMismatch() {
        sourceGraph.addNode("label");
        Commit commit = sourceGraph.commit("author", "email", "message");

        destinationGraph.addNode("label");
        destinationGraph.commit("author", "email", "message");

        commit.setPrev(null);

        try {
            destinationGraph.patch(commit);
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("previous commit mismatch. Did you mean to merge?");
        }
    }

    @Test
    public void patch_shouldErrorOnNonNullCommitMismatch() {
        sourceGraph.addNode("label");
        Commit commit = sourceGraph.commit("author", "email", "message");

        destinationGraph.addNode("label");
        destinationGraph.commit("author", "email", "message");

        try {
            destinationGraph.patch(commit);
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("previous commit mismatch. Did you mean to merge?");
        }
    }

    @Test
    public void patch_shouldDoNothingWhenEmpty() {
        Commit commit = sourceGraph.commit("author", "email", "message");

        destinationGraph.patch(commit);

        assertThat(destinationGraph.getNodes().iterator().hasNext()).isEqualTo(false);
        assertThat(destinationGraph.getEdges().iterator().hasNext()).isEqualTo(false);

    }

    @Test
    public void patch_shouldAddOneNode() {
        Node node = sourceGraph.addNode("label");
        node.setProperty("key", "value");
        Commit commit = sourceGraph.commit("author","email", "message");

        destinationGraph.patch(commit);

        Node n = destinationGraph.getNode(node.getId());

        assertThat(n).isNotNull();
        assertThat(n.getProperty("key")).isEqualTo("value");
    }

    @Test
    public void patch_shouldAddOneEdge() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        sourceGraph.commit("author","email", "message");
        Edge edge = sourceGraph.addEdge(node1, node2, "edge_label");
        edge.setProperty("key", "value");
        Commit commit = sourceGraph.commit("author","email", "message");


        commit.setPrev(null);
        destinationGraph.patch(commit);

        Node n1 = destinationGraph.getNode(node1.getId());
        assertThat(n1).isNotNull();
        assertThat(n1.isBoundary()).isEqualTo(true);
        assertThat(n1.getRepo()).isEqualTo(sourceRepo);

        Node n2 = destinationGraph.getNode(node2.getId());
        assertThat(n2).isNotNull();
        assertThat(n2.isBoundary()).isEqualTo(true);
        assertThat(n1.getRepo()).isEqualTo(sourceRepo);

        Edge e1 = destinationGraph.getEdge(edge.getId());
        assertThat(e1).isNotNull();
        assertThat(e1.getNode(com.github.trepo.vgraph.Direction.OUT).getId()).isEqualTo(node1.getId());
        assertThat(e1.getNode(com.github.trepo.vgraph.Direction.IN).getId()).isEqualTo(node2.getId());
        assertThat(e1.getProperty("key")).isEqualTo("value");
    }

    @Test
    public void patch_shouldDeleteOneEdge() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        Edge edge = sourceGraph.addEdge(node1, node2, "edge_label");
        Commit commit = sourceGraph.commit("author","email", "message");

        destinationGraph.patch(commit);

        assertThat(destinationGraph.getNode(node1.getId())).isNotNull();
        assertThat(destinationGraph.getNode(node2.getId())).isNotNull();
        assertThat(destinationGraph.getEdge(edge.getId())).isNotNull();

        sourceGraph.removeEdge(edge.getId());
        commit = sourceGraph.commit("author","email", "message");

        destinationGraph.patch(commit);

        assertThat(destinationGraph.getNode(node1.getId())).isNotNull();
        assertThat(destinationGraph.getNode(node2.getId())).isNotNull();
        assertThat(destinationGraph.getEdge(edge.getId())).isNull();
    }

    @Test
    public void patch_shouldDeleteNodeAndEdge() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        Edge edge = sourceGraph.addEdge(node1, node2, "edge_label");
        Commit commit = sourceGraph.commit("author","email", "message");

        destinationGraph.patch(commit);

        assertThat(destinationGraph.getNode(node1.getId())).isNotNull();
        assertThat(destinationGraph.getNode(node2.getId())).isNotNull();
        assertThat(destinationGraph.getEdge(edge.getId())).isNotNull();

        sourceGraph.removeNode(node2.getId());
        commit = sourceGraph.commit("author","email", "message");

        destinationGraph.patch(commit);

        assertThat(destinationGraph.getNode(node1.getId())).isNotNull();
        assertThat(destinationGraph.getNode(node2.getId())).isNull();
        assertThat(destinationGraph.getEdge(edge.getId())).isNull();
    }

}

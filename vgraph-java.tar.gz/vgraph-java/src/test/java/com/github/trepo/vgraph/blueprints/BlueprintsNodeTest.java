package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.tinkerpop.blueprints.KeyIndexableGraph;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.github.trepo.vgraph.VGraphException;
import com.github.trepo.vgraph.blueprints.util.Util;

import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BlueprintsNodeTest {

    private BlueprintsVGraph globalGraph;
    private BlueprintsNode node;
    private BlueprintsNode node2;

    @BeforeMethod
    public void beforeTest() {

        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");
        v.setProperty(SpecialProperty.ID, "1");
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty("foo", "bar");
        v.setProperty(SpecialProperty.HASH, Util.calculateHash(new BlueprintsNode(v, null)));

        Vertex v2 = graph.addVertex("2");
        v2.setProperty(SpecialProperty.ID, "2");
        v2.setProperty(SpecialProperty.LABEL, "label2");

        globalGraph = new BlueprintsVGraph(graph, "repo");
        node = new BlueprintsNode(v, globalGraph);
        node2 = new BlueprintsNode(v2, globalGraph);
    }

    /**
     * getId
     */
    @Test
    public void getId_shouldWork() {
        assertThat(node.getId()).isEqualTo("1");
    }

    /**
     * getLabel
     */
    @Test
    public void getLabel_shouldWork() {
        assertThat(node.getLabel()).isEqualTo("label");
    }

    /**
     * getHash
     */
    @Test
    public void getHash_shouldWork() {
        assertThat(node.getHash()).isEqualTo("a5e744d0164540d33b1d7ea616c28f2fa97e754a");
        assertThat(node2.getHash()).isEqualTo(null);
    }

    /**
     * getRepo
     */
    @Test
    public void getRepo_shouldWork() {
        assertThat(node.getRepo()).isEqualTo("repo");
    }

    /**
     * getPropertyKeys
     */
    @Test
    public void getPropertyKeys_shouldReturnEmptySet() {
        assertThat(node2.getPropertyKeys().isEmpty()).isEqualTo(true);
    }

    @Test
    public void getPropertyKeys_shouldContainOneKey() {
        node2.setProperty("prop1", "value");
        Set<String> keys = node2.getPropertyKeys();
        assertThat(keys.isEmpty()).isEqualTo(false);
        assertThat(keys.contains("prop1")).isEqualTo(true);
        assertThat(keys.size()).isEqualTo(1);
    }

    @Test
    public void getPropertyKeys_shouldContainOnlyTwoKeys() {
        node2.setProperty("prop2", "value2");
        node2.setProperty("prop3", "value3");
        node2.setProperty("prop2", "newValue2");
        Set<String> keys = node2.getPropertyKeys();
        assertThat(keys.isEmpty()).isEqualTo(false);
        assertThat(keys.contains("prop2")).isEqualTo(true);
        assertThat(keys.contains("prop3")).isEqualTo(true);
        assertThat(keys.size()).isEqualTo(2);
    }

    /**
     * getProperty
     */
    @Test
    public void getProperty_shouldReturnNull() {
        assertThat(node.getProperty("doesntExist")).isEqualTo(null);
    }

    @Test
    public void getProperty_shouldReturnString() {
        node.setProperty("prop1", "String");
        assertThat(node.getProperty("prop1")).isEqualTo("String");
    }

    @Test
     public void getProperty_shouldErrorOnBadKey() {
        try {
            node.getProperty("_FAIL");
            fail("Should have failed on bad key");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid Regular Key");
        }
    }

    /**
     * isBoundary
     */
    @Test
    public void isBoundary_shouldWork() {
        assertThat(node.isBoundary()).isEqualTo(false);
    }

    /**
     * setProperty
     */
    @Test
    public void setProperty_shouldSetProperly() {
        assertThat(node.getHash()).isEqualTo("a5e744d0164540d33b1d7ea616c28f2fa97e754a");
        node.setProperty("key", false);
        assertThat(node.getProperty("key")).isEqualTo(false);
        assertThat(node.getHash()).isEqualTo(null);
    }

    @Test
    public void setProperty_shouldUpdateOriginal() {
        node.setProperty("foo", true);
        assertThat(node.getProperty("foo")).isEqualTo(true);
        assertThat(node.getHash()).isEqualTo(null);
        assertThat(node.getBlueprintsNode().getProperty(SpecialProperty.ORIGINAL)).isEqualTo("{\"foo\":\"bar\"}");
    }

    @Test
    public void setProperty_shouldErrorOnBadKey() {
        try {
            node.setProperty("_FAIL", false);
            fail("Should have failed on bad key");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid Regular Key");
        }
    }

    @Test
    public void setProperty_shouldErrorOnBadValue() {
        try {
            node.setProperty("prop", new Object());
            fail("Should have failed on bad value");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid Regular Value");
        }
    }

    @Test
    public void setProperty_shouldErrorOnDeleted() {
        globalGraph.removeNode(node.getId());
        try {
            node.setProperty("foo", true);
            fail("Should have thrown error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Node deleted");
        }
    }

    /**
     * removeProperty
     */
    @Test
    public void removeProperty_shouldRemoveProperly() {
        assertThat(node.getHash()).isEqualTo("a5e744d0164540d33b1d7ea616c28f2fa97e754a");
        assertThat(node.getProperty("foo")).isEqualTo("bar");
        node.removeProperty("foo");
        assertThat(node.getProperty("foo")).isEqualTo(null);
        assertThat(node.getHash()).isEqualTo(null);
    }

    @Test
    public void removeProperty_shouldUpdateOriginal() {
        node.removeProperty("foo");
        assertThat(node.getProperty("foo")).isEqualTo(null);
        assertThat(node.getHash()).isEqualTo(null);
        assertThat(node.getBlueprintsNode().getProperty(SpecialProperty.ORIGINAL)).isEqualTo("{\"foo\":\"bar\"}");
    }

    @Test
    public void removeProperty_shouldErrorOnBadKey() {
        try {
            node.removeProperty("_FAIL");
            fail("Should have failed on bad key");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid Regular Key");
        }
    }

    @Test
    public void removeProperty_shouldErrorOnDeleted() {
        globalGraph.removeNode(node.getId());
        try {
            node.removeProperty("foo");
            fail("Should have thrown error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Node deleted");
        }
    }

    /**
     * addEdge
     */
    @Test
    public void addEdge_shouldErrorOnInvalidNode() {
        try {
            node.addEdge(null, "label");
            fail("Should have failed on bad node");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid toNode");
        }
    }

    @Test
    public void addEdge_shouldErrorOnInvalidLabel() {
        try {
            node.addEdge(new BlueprintsNode(null, null), "_FAIL");
            fail("Should have failed on bad label");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid Label");
        }
    }

    @Test
    public void addEdge_shouldErrorOnSelfReference() {
        try {
            node.addEdge(node, "EDGE");
            fail("Should have failed on self referencing node");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Self Referencing Edges are not allowed");
        }
    }

    @Test
    public void addEdge_shouldCreateEdge() {

        Edge edge = node.addEdge(node2, "EDGE");
        assertThat(edge.getId()).isNotNull();
        assertThat(edge.getId().length()).isEqualTo(36);
        assertThat(edge.getLabel()).isEqualTo("EDGE");
        assertThat(edge.getHash()).isNull();
    }

    @Test
    public void addEdge_shouldErrorOnDeletedFromNode() {
        globalGraph.removeNode(node.getId());
        try {
            node.addEdge(node2, "EDGE");
            fail("Should have thrown error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Node deleted");
        }
    }

    @Test
    public void addEdge_shouldErrorOnDeletedToNode() {
        globalGraph.removeNode(node2.getId());
        try {
            node.addEdge(node2, "EDGE");
            fail("Should have thrown error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("To node deleted");
        }
    }

    /**
     * getEdges
     */
    @Test
    public void getEdges_shouldReturnOne() {

        node.addEdge(node2, "EDGE");

        int i = 0;
        for(Edge edge: node.getEdges(Direction.OUT)) {
            i++;
            assertThat(edge.getLabel()).isEqualTo("EDGE");
        }
        assertThat(i).isEqualTo(1);
    }

    @Test
    public void getEdges_shouldReturnZero() {

        node.addEdge(node2, "EDGE");

        int i = 0;
        for(Edge edge: node.getEdges(Direction.IN)) {
            i++;
            fail("There should be 0 edges. Found "+edge.getId());
        }
        assertThat(i).isEqualTo(0);
    }

    @Test
    public void getEdges_shouldReturnZeroWithFilter() {

        node.addEdge(node2, "EDGE");

        int i = 0;
        for(Edge edge: node.getEdges(Direction.OUT, "FOO")) {
            i++;
            fail("There should be 0 edges. Found "+edge.getId());
        }
        assertThat(i).isEqualTo(0);
    }

    @Test
    public void getEdges_shouldThrowErrorOnRemove() {

        node.addEdge(node2, "EDGE");
        try {
            node.addEdge(node2, "EDGE");
            Iterator<Edge> iterator = node.getEdges(Direction.OUT).iterator();
            assertThat(iterator.hasNext()).isEqualTo(true);
            iterator.next();
            iterator.remove();
            fail("Should have failed on method not allowed");
        } catch(UnsupportedOperationException e) {
            assertThat(e.getMessage()).isEqualTo("Method not implemented");
        }

    }

    @Test
    public void getEdges_shouldNotReturnDeletedEdges() {

        String id = node.addEdge(node2, "EDGE").getId();
        globalGraph.removeEdge(id);

        int i = 0;
        for(Edge edge: node.getEdges(Direction.BOTH)) {
            i++;
            assertThat(edge.getLabel()).isEqualTo("EDGE");
        }
        assertThat(i).isEqualTo(0);
    }

    /**
     * getNodes
     */
    @Test
    public void getNodes_shouldReturnOne() {

        node.addEdge(node2, "EDGE");

        int i = 0;
        for(Node n: node.getNodes(Direction.OUT)) {
            i++;
            assertThat(n.getId()).isEqualTo("2");
        }
        assertThat(i).isEqualTo(1);

        i = 0;
        for(Node n: node2.getNodes(Direction.IN)) {
            i++;
            assertThat(n.getId()).isEqualTo("1");
        }
        assertThat(i).isEqualTo(1);
    }

    @Test
    public void getNodes_shouldReturnZero() {

        node.addEdge(node2, "EDGE");

        int i = 0;
        for(Node n: node.getNodes(Direction.IN)) {
            i++;
            fail("There should be 0 nodes. Found "+n.getId());
        }
        assertThat(i).isEqualTo(0);
    }

    @Test
    public void getNodes_shouldReturnZeroWithFilter() {

        node.addEdge(node2, "EDGE");

        int i = 0;
        for(Node n: node.getNodes(Direction.OUT, "FOO")) {
            i++;
            fail("There should be 0 nodes. Found "+n.getId());
        }
        assertThat(i).isEqualTo(0);
    }

    @Test
    public void getNodes_shouldThrowErrorOnRemove() {

        node.addEdge(node2, "EDGE");
        try {
            node.addEdge(node2, "EDGE");
            Iterator<Node> iterator = node.getNodes(Direction.OUT).iterator();
            assertThat(iterator.hasNext()).isEqualTo(true);
            iterator.next();
            iterator.remove();
            fail("Should have failed on method not allowed");
        } catch(UnsupportedOperationException e) {
            assertThat(e.getMessage()).isEqualTo("Method not implemented");
        }

    }

    @Test
    public void getNodes_shouldNotReturnDeletedEdges() {

        String id = node.addEdge(node2, "EDGE").getId();
        globalGraph.removeEdge(id);

        Iterator<Node> iterator = node.getNodes(Direction.BOTH).iterator();
        assertThat(iterator.hasNext()).isEqualTo(false);
    }

    /**
     * getBlueprintsNode
     */
    @Test
    public void getBlueprintsNode_shouldWork() {
        Vertex v = node.getBlueprintsNode();
        assertThat(v.getProperty(SpecialProperty.ID)).isEqualTo(node.getId());
    }

    /**
     * equals
     */
    @Test
    public void equals_shouldReturnTrueWithSelf() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");
        BlueprintsNode n1 = new BlueprintsNode(v, null);
        assertThat(n1.equals(n1)).isEqualTo(true);
    }

    @Test
    public void equals_shouldReturnFalseWithNull() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");
        BlueprintsNode n1 = new BlueprintsNode(v, null);
        assertThat(n1.equals(null)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithDifferentClass() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");
        BlueprintsNode n1 = new BlueprintsNode(v, null);
        assertThat(n1.equals(new Date())).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithNullVertex() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");
        BlueprintsNode n1 = new BlueprintsNode(null, null);
        BlueprintsNode n2 = new BlueprintsNode(v, null);
        assertThat(n1.equals(n2)).isEqualTo(false);
        assertThat(n2.equals(n1)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithDifferentVertex() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v1 = graph.addVertex("1");
        Vertex v2 = graph.addVertex("2");
        BlueprintsNode n1 = new BlueprintsNode(v1, null);
        BlueprintsNode n2 = new BlueprintsNode(v2, null);
        assertThat(n1.equals(n2)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnTrueWithSameVertex() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");
        BlueprintsNode n1 = new BlueprintsNode(v, null);
        BlueprintsNode n2 = new BlueprintsNode(v, null);
        assertThat(n1.equals(n2)).isEqualTo(true);
    }

    /**
     * hashCode
     */
    @Test
    public void hashCode_shouldReturn0() {
        BlueprintsNode n = new BlueprintsNode(null, null);
        assertThat(n.hashCode()).isEqualTo(0);
    }

    @Test
    public void hashCode_shouldReturnSameHashCodeAsVertex() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");
        BlueprintsNode n = new BlueprintsNode(v, null);
        assertThat(n.hashCode()).isEqualTo(v.hashCode());
    }

}

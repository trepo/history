package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.tinkerpop.blueprints.KeyIndexableGraph;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.github.trepo.vgraph.VGraphException;
import com.github.trepo.vgraph.blueprints.util.Util;

import java.util.Date;
import java.util.Set;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BlueprintsEdgeTest {

    private KeyIndexableGraph graph;
    private BlueprintsVGraph globalGraph;
    private Node node;
    private Node node2;
    private Node node3; // Boundary
    private Edge edge;
    private Edge edge2;
    private Edge edge3;

    @BeforeMethod
    public void beforeTest() {
        graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");
        v.setProperty(SpecialProperty.ID, "1");
        v.setProperty(SpecialProperty.LABEL, "label");

        Vertex v2 = graph.addVertex("2");
        v2.setProperty(SpecialProperty.ID, "2");
        v2.setProperty(SpecialProperty.LABEL, "label2");

        Vertex v3 = graph.addVertex("3");
        v3.setProperty(SpecialProperty.ID, "3");
        v3.setProperty(SpecialProperty.LABEL, "label");
        v3.setProperty(SpecialProperty.REPO, "repo2");

        globalGraph = new BlueprintsVGraph(graph, "repo");

        node = new BlueprintsNode(v, globalGraph);

        node2 = new BlueprintsNode(v2, globalGraph);

        node3 = new BlueprintsNode(v3, globalGraph);

        edge = node.addEdge(node2, "EDGE");

        edge2 = node2.addEdge(node, "EDGE_TWO");
        edge2.setProperty("foo", "bar");
        ((BlueprintsEdge)edge2).getBlueprintsEdge().setProperty(SpecialProperty.HASH, Util.calculateHash(edge2));

        edge3 = node.addEdge(node3, "EDGE_THREE");
        ((BlueprintsEdge)edge3).getBlueprintsEdge().setProperty(SpecialProperty.HASH, Util.calculateHash(edge3));
    }

    /**
     * getId
     */
    @Test
    public void getId_shouldWork() {
        assertThat(edge.getId().length()).isEqualTo(36);
    }

    /**
     * getLabel
     */
    @Test
    public void getLabel_shouldWork() {
        assertThat(edge.getLabel()).isEqualTo("EDGE");
    }

    /**
     * getHash
     */
    @Test
    public void getHash_shouldWork() {
        assertThat(edge.getHash()).isEqualTo(null);
        assertThat(edge2.getHash()).isEqualTo("a5e744d0164540d33b1d7ea616c28f2fa97e754a");
    }

    /**
     * getPropertyKeys
     */
    @Test
    public void getPropertyKeys_shouldReturnEmptySet() {
        assertThat(edge.getPropertyKeys().isEmpty()).isEqualTo(true);
    }

    @Test
    public void getPropertyKeys_shouldContainOneKey() {
        edge.setProperty("prop1", "value");
        Set<String> keys = edge.getPropertyKeys();
        assertThat(keys.isEmpty()).isEqualTo(false);
        assertThat(keys.contains("prop1")).isEqualTo(true);
        assertThat(keys.size()).isEqualTo(1);
    }

    @Test
    public void getPropertyKeys_shouldContainOnlyTwoKeys() {
        edge.setProperty("prop2", "value2");
        edge.setProperty("prop3", "value3");
        edge.setProperty("prop2", "newValue2");
        Set<String> keys = edge.getPropertyKeys();
        assertThat(keys.isEmpty()).isEqualTo(false);
        assertThat(keys.contains("prop2")).isEqualTo(true);
        assertThat(keys.contains("prop3")).isEqualTo(true);
        assertThat(keys.size()).isEqualTo(2);
    }

    /**
     * getProperty
     */
    @Test
    public void getProperty_shouldReturnNull() {
        assertThat(edge.getProperty("doesntExist")).isEqualTo(null);
    }

    @Test
    public void getProperty_shouldReturnString() {
        edge.setProperty("prop1", "String");
        assertThat(edge.getProperty("prop1")).isEqualTo("String");
    }

    @Test
    public void getProperty_shouldErrorOnBadKey() {
        try {
            edge.getProperty("_FAIL");
            fail("Should have failed on bad key");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid Regular Key");
        }
    }

    /**
     * setProperty
     */
    @Test
    public void setProperty_shouldSetProperly() {
        edge.setProperty("key", false);
        assertThat(edge.getProperty("key")).isEqualTo(false);
    }

    @Test
    public void setProperty_shouldUpdateOriginal() {
        edge2.setProperty("prop", true);
        assertThat(edge2.getProperty("prop")).isEqualTo(true);
        assertThat(edge2.getHash()).isEqualTo(null);
        assertThat(((BlueprintsEdge)edge2).getBlueprintsEdge().getProperty(SpecialProperty.ORIGINAL)).isEqualTo("{\"foo\":\"bar\"}");
    }

    @Test
    public void setProperty_shouldClearHash() {
        assertThat(edge2.getHash()).isEqualTo("a5e744d0164540d33b1d7ea616c28f2fa97e754a");
        edge2.setProperty("key", false);
        assertThat(edge2.getProperty("key")).isEqualTo(false);
        assertThat(edge2.getHash()).isEqualTo(null);
    }

    @Test
    public void setProperty_shouldErrorOnBadKey() {
        try {
            edge.setProperty("_FAIL", false);
            fail("Should have failed on bad key");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid Regular Key");
        }
    }

    @Test
    public void setProperty_shouldErrorOnBadValue() {
        try {
            edge.setProperty("prop", new Object());
            fail("Should have failed on bad value");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid Regular Value");
        }
    }

    @Test
    public void setProperty_shouldErrorOnDeleted() {
        globalGraph.removeEdge(edge.getId());
        try {
            edge.setProperty("foo", true);
            fail("Should have thrown error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Edge deleted");
        }
    }

    /**
     * removeProperty
     */
    @Test
    public void removeProperty_shouldRemoveProperly() {
        edge.setProperty("key", false);
        assertThat(edge.getProperty("key")).isEqualTo(false);
        edge.removeProperty("key");
        assertThat(edge.getProperty("key")).isEqualTo(null);
    }

    @Test
    public void removeProperty_shouldUpdateOriginal() {
        edge2.removeProperty("prop");
        assertThat(edge2.getProperty("prop")).isEqualTo(null);
        assertThat(edge2.getHash()).isEqualTo(null);
        assertThat(((BlueprintsEdge)edge2).getBlueprintsEdge().getProperty(SpecialProperty.ORIGINAL)).isEqualTo("{\"foo\":\"bar\"}");
    }

    @Test
    public void removeProperty_shouldClearHash() {
        assertThat(edge2.getHash()).isEqualTo("a5e744d0164540d33b1d7ea616c28f2fa97e754a");
        edge2.removeProperty("prop");
        assertThat(edge2.getProperty("prop")).isEqualTo(null);
        assertThat(edge2.getHash()).isEqualTo(null);
    }

    @Test
    public void removeProperty_shouldErrorOnBadKey() {
        try {
            edge.removeProperty("_FAIL");
            fail("Should have failed on bad key");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid Regular Key");
        }
    }

    @Test
    public void removeProperty_shouldErrorOnDeleted() {
        globalGraph.removeEdge(edge.getId());
        try {
            edge.removeProperty("foo");
            fail("Should have thrown error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Edge deleted");
        }
    }

    /**
     * getNode
     */
    @Test
    public void getNode_shouldReturnCorrectNode() {

        assertThat(edge.getNode(Direction.IN).getId()).isEqualTo("2");
        assertThat(edge.getNode(Direction.OUT).getId()).isEqualTo("1");
    }

    @Test
    public void getNode_ShouldReturnBoundaryNode() {
        assertThat(edge3.getNode(Direction.IN).getId()).isEqualTo("3");
        assertThat(edge3.getNode(Direction.IN).isBoundary()).isTrue();
        assertThat(edge3.getNode(Direction.OUT).getId()).isEqualTo("1");
        assertThat(edge3.getNode(Direction.OUT).isBoundary()).isFalse();
    }

    /**
     * getBlueprintsEdge
     */
    @Test
    public void getBlueprintsEdge_shouldWork() {
        assertThat(((BlueprintsEdge)edge).getBlueprintsEdge().getProperty(SpecialProperty.LABEL)).isEqualTo("EDGE");
    }

    /**
     * equals
     */
    @Test
    public void equals_shouldReturnTrueWithSelf() {
        assertThat(edge.equals(edge)).isEqualTo(true);
    }

    @Test
    public void equals_shouldReturnFalseWithNull() {
        assertThat(edge.equals(null)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithDifferentClass() {
        assertThat(edge.equals(new Date())).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithNullVertex() {
        BlueprintsEdge e = new BlueprintsEdge(null, null);
        assertThat(e.equals(edge)).isEqualTo(false);
        assertThat(edge.equals(e)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnFalseWithDifferentVertex() {
        assertThat(edge.equals(edge2)).isEqualTo(false);
    }

    @Test
    public void equals_shouldReturnTrueWithSameVertex() {
        BlueprintsEdge e2 = new BlueprintsEdge(((BlueprintsEdge)edge).getBlueprintsEdge(), null);
        assertThat(edge.equals(e2)).isEqualTo(true);
    }

    /**
     * hashCode
     */
    @Test
    public void hashCode_shouldReturn0() {
        BlueprintsEdge e = new BlueprintsEdge(null, null);
        assertThat(e.hashCode()).isEqualTo(0);
    }

    @Test
    public void hashCode_shouldReturnSameHashCodeAsVertex() {
        assertThat(edge.hashCode()).isEqualTo(((BlueprintsEdge)edge).getBlueprintsEdge().hashCode());
    }
}
package com.github.trepo.vgraph.blueprints.util;

import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.blueprints.BlueprintsNode;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.KeyIndexableGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import java.util.Iterator;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class NodeFromEdgeIterableTest {

    @Test
    public void shouldWork() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        Node n3 = graph.addNode("label");
        Node n4 = graph.addNode("label");
        Node n5 = graph.addNode("label");
        graph.addEdge(n1, n2, "label");
        graph.removeEdge(graph.addEdge(n1, n3, "label").getId());
        graph.addEdge(n4, n1, "label");
        graph.removeEdge(graph.addEdge(n5, n1, "label").getId());

        int i = 0;
        for(Node n: new NodeFromEdgeIterable(n1.getEdges(Direction.BOTH), (BlueprintsNode)n1)) {
            i++;
            assertThat(n.getId()).isIn(n2.getId(), n4.getId());
        }
        assertThat(i).isEqualTo(2);
    }

    @Test
    public void shouldFailOnRemove() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        graph.addEdge(n1, n2,"label");

        Iterator itr = new NodeFromEdgeIterable(n1.getEdges(Direction.BOTH), (BlueprintsNode)n1).iterator();
        itr.next();
        try {
            itr.remove();
            fail("Should have failed on method not allowed");
        } catch(UnsupportedOperationException e) {
            assertThat(e.getMessage()).isEqualTo("Method not implemented");
        }
    }
}

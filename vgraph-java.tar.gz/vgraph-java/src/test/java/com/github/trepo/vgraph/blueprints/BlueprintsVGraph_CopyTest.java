package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.CommitEdge;
import com.github.trepo.vgraph.CommitNode;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraphException;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.HashSet;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BlueprintsVGraph_CopyTest {

    String repo = "repo";
    TinkerGraph tinkerGraph;
    BlueprintsVGraph graph;

    @BeforeMethod
    public void beforeTest() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
    }

    /**
     * copy
     */
    @Test
    public void copy_shouldFailOnDirtyGraph() {
        graph.addNode("label");

        try {
            graph.copy("author", "email", "message");
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("cannot copy a dirty graph");
        }
    }

    @Test
    public void copy_shouldReturnEmptyCommit() {
        Commit commit = graph.copy("author", "email", "message");

        commit.validate();

        assertThat(commit.getAuthor()).isEqualTo("author");
        assertThat(commit.getEmail()).isEqualTo("email");
        assertThat(commit.getMessage()).isEqualTo("message");
        assertThat(commit.getNodes().isEmpty()).isTrue();
        assertThat(commit.getEdges().isEmpty()).isTrue();
    }

    @Test
    public void copy_shouldReturnEverything() {
        String node1Id = SpecialProperty.generateId();
        Vertex v = tinkerGraph.addVertex(node1Id);
        v.setProperty(SpecialProperty.ID, node1Id);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.HASH, SpecialProperty.calculateHash(new HashMap<String, Object>()));
        v.setProperty(SpecialProperty.REPO, "external-repo");
        Node node1 = graph.getNode(node1Id);
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "edge_label");
        graph.commit("author", "email", "message");

        Commit commit = graph.copy("author", "email", "message");

        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(2);
        for (CommitNode commitNode: commit.getNodes()) {
            if (commitNode.getId().equals(node1.getId())) {
                assertThat(commitNode.isBoundary()).isTrue();
                assertThat(commitNode.getRepo()).isEqualTo("external-repo");
            } else if (commitNode.getId().equals(node2.getId())) {
                assertThat(commitNode.isBoundary()).isFalse();
            } else {
                fail("unknown commit node");
            }
        }
        assertThat(commit.getEdges().size()).isEqualTo(1);
        for (CommitEdge commitEdge: commit.getEdges()) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getFrom()).isEqualTo(node1.getId());
            assertThat(commitEdge.getTo()).isEqualTo(node2.getId());
        }
    }

    /**
     * copy nodes
     */
    @Test
    public void copy_nodes_shouldFailOnDirtyGraph() {
        graph.addNode("label");

        try {
            graph.copy(new HashSet<Node>(), "author", "email", "message");
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("cannot copy a dirty graph");
        }
    }

    @Test
    public void copy_nodes_shouldReturnEmptyCommit() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        graph.addEdge(node1, node2, "edge_label");
        graph.commit("author", "email", "message");

        Commit commit = graph.copy(new HashSet<Node>(), "author", "email", "message");

        commit.validate();

        assertThat(commit.getAuthor()).isEqualTo("author");
        assertThat(commit.getEmail()).isEqualTo("email");
        assertThat(commit.getMessage()).isEqualTo("message");
        assertThat(commit.getNodes().isEmpty()).isTrue();
        assertThat(commit.getEdges().isEmpty()).isTrue();
    }

    @Test
    public void copy_nodes_shouldReturnProperCommitWithBoundaries() {
        // TODO
        String node1Id = SpecialProperty.generateId();
        String node4Id = SpecialProperty.generateId();
        Vertex v = tinkerGraph.addVertex(node1Id);
        v.setProperty(SpecialProperty.ID, node1Id);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.HASH, SpecialProperty.calculateHash(new HashMap<String, Object>()));
        v.setProperty(SpecialProperty.REPO, "external-repo");
        v = tinkerGraph.addVertex(node4Id);
        v.setProperty(SpecialProperty.ID, node4Id);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.HASH, SpecialProperty.calculateHash(new HashMap<String, Object>()));
        v.setProperty(SpecialProperty.REPO, "external-repo");
        Node node1 = graph.getNode(node1Id);
        Node node2 = graph.addNode("label");
        Node node3 = graph.addNode("label");
        Node node4 = graph.getNode(node4Id);
        Edge edge1 = graph.addEdge(node1, node2, "edge_label");
        Edge edge2 = graph.addEdge(node2, node3, "edge_label");
        graph.commit("author", "email", "message");

        HashSet<Node> nodes = new HashSet<>();
        nodes.add(node2);
        nodes.add(node4);

        Commit commit = graph.copy(nodes, "author", "email", "message");

        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(4);
        for (CommitNode commitNode: commit.getNodes()) {

            if (commitNode.getId().equals(node1.getId())) {

                assertThat(commitNode.isBoundary()).isTrue();
                assertThat(commitNode.getRepo()).isEqualTo("external-repo");

            } else if (commitNode.getId().equals(node2.getId())) {

                assertThat(commitNode.isBoundary()).isFalse();

            } else if (commitNode.getId().equals(node3.getId())) {

                assertThat(commitNode.isBoundary()).isTrue();
                assertThat(commitNode.getRepo()).isEqualTo("repo");

            } else if (commitNode.getId().equals(node4.getId())) {

                assertThat(commitNode.isBoundary()).isTrue();
                assertThat(commitNode.getRepo()).isEqualTo("external-repo");

            } else {
                fail("unknown commit node");
            }
        }
        assertThat(commit.getEdges().size()).isEqualTo(2);
        for (CommitEdge commitEdge: commit.getEdges()) {

            if (commitEdge.getId().equals(edge1.getId())) {

                assertThat(commitEdge.getFrom()).isEqualTo(node1.getId());
                assertThat(commitEdge.getTo()).isEqualTo(node2.getId());

            } else if (commitEdge.getId().equals(edge2.getId())) {

                assertThat(commitEdge.getFrom()).isEqualTo(node2.getId());
                assertThat(commitEdge.getTo()).isEqualTo(node3.getId());

            } else {
                fail("unknown commit edge");
            }

        }
    }
}

package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.CommitEdge;
import com.github.trepo.vgraph.CommitNode;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraphException;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashSet;
import java.util.Iterator;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BlueprintsVGraph_CloneTest {

    String repo = "repo";
    TinkerGraph tinkerGraph;
    BlueprintsVGraph graph;

    @BeforeMethod
    public void beforeTest() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
    }

    /**
     * clone
     */
    @Test
    public void clone_shouldFailOnDirtyGraph() {
        graph.addNode("label");

        try {
            graph.cloneGraph();
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("cannot clone a dirty graph");
        }
    }

    @Test
    public void clone_shouldReturn0Commits() {
        Iterator<Commit> commits = graph.cloneGraph().iterator();

        assertThat(commits.hasNext()).isFalse();
    }

    @Test
    public void clone_shouldReturn1Commit() {
        graph.addNode("label");
        Commit originalCommit = graph.commit("author", "email", "message");

        for (Commit commit: graph.cloneGraph()) {
            commit.validate();
            assertThat(commit.getId()).isEqualTo(originalCommit.getId());
            assertThat(commit.getPrev()).isEqualTo(originalCommit.getPrev());
            assertThat(commit.getTimestamp()).isEqualTo(originalCommit.getTimestamp());
            assertThat(commit.getAuthor()).isEqualTo(originalCommit.getAuthor());
            assertThat(commit.getEmail()).isEqualTo(originalCommit.getEmail());
            assertThat(commit.getMessage()).isEqualTo(originalCommit.getMessage());
            assertThat(commit.getNodes()).isEqualTo(originalCommit.getNodes());
            assertThat(commit.getEdges()).isEqualTo(originalCommit.getEdges());
        }
    }

    @Test
    public void clone_shouldReturnAllCommits() {
        Node node1 = graph.addNode("label");
        Commit commit1 = graph.commit("author", "email", "message");
        Node node2 = graph.addNode("label");
        Commit commit2 = graph.commit("author", "email", "message");
        graph.addEdge(node1, node2, "edge_label");
        Commit commit3 = graph.commit("author", "email", "message");

        for (Commit commit: graph.cloneGraph()) {
            commit.validate();
            if (commit.getId().equals(commit1.getId())) {
                assertThat(commit.getPrev()).isNull();
            } else if (commit.getId().equals(commit2.getId())) {
                assertThat(commit.getPrev()).isEqualTo(commit1.getId());
            } else if (commit.getId().equals(commit3.getId())) {
                assertThat(commit.getPrev()).isEqualTo(commit2.getId());
            } else {
                fail("unknown commit");
            }
        }
    }

    /**
     * clone nodes
     */
    @Test
    public void clone_nodes_shouldFailOnDirtyGraph() {
        graph.addNode("label");

        try {
            graph.cloneGraph(new HashSet<Node>());
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("cannot clone a dirty graph");
        }
    }

    @Test
    public void clone_nodes_shouldReturn0Commits() {
        Node node1 = graph.addNode("label");
        graph.commit("author", "email", "message");
        Node node2 = graph.addNode("label");
        graph.commit("author", "email", "message");
        graph.addEdge(node1, node2, "edge_label");
        graph.commit("author", "email", "message");

        Iterator<Commit> commits = graph.cloneGraph(new HashSet<Node>()).iterator();

        assertThat(commits.hasNext()).isFalse();
    }

    @Test
    public void clone_nodes_shouldReturnProperCommits() {
        Node node = graph.addNode("label");
        graph.addNode("label");
        graph.addNode("label");
        graph.addNode("label");
        graph.addNode("label");
        graph.commit("author", "email", "message");

        HashSet<Node> nodes = new HashSet<>();
        nodes.add(node);

        String prevCommitId = null;
        for (Commit commit: graph.cloneGraph(nodes)) {
            commit.validate();
            for (CommitNode commitNode: commit.getNodes()) {
                assertThat(commitNode.getId()).isEqualTo(node.getId());
            }
            assertThat(commit.getEdges().isEmpty()).isTrue();
            assertThat(commit.getPrev()).isEqualTo(prevCommitId);
            prevCommitId = commit.getId();
        }
    }

    @Test
    public void clone_nodes_shouldCreateProperBoundaries() {
        Node node1 = graph.addNode("label");
        graph.commit("author", "email", "message"); // 0
        Node node2 = graph.addNode("label");
        graph.commit("author", "email", "message");
        Edge edge1 = graph.addEdge(node1, node2, "edge_label");
        graph.commit("author", "email", "message"); // 1
        node1.setProperty("foo", "bar");
        node2.setProperty("foo", "bar");
        Edge edge2 = graph.addEdge(node2, node1, "edge_label");
        graph.commit("author", "email", "message"); // 2
        edge1.setProperty("foo", "bar");
        node1.setProperty("testing", true);
        graph.commit("author", "email", "message"); // 3

        HashSet<Node> nodes = new HashSet<>();
        nodes.add(node1);

        String prevCommitId = null;
        int num = 0;
        for (Commit commit: graph.cloneGraph(nodes)) {
            commit.validate();
            switch (num) {
                case 0:
                    // Should only have node1
                    assertThat(commit.getNodes().size()).isEqualTo(1);
                    for (CommitNode commitNode: commit.getNodes()) {
                        assertThat(commitNode.getId()).isEqualTo(node1.getId());
                        assertThat(commitNode.isBoundary()).isFalse();
                    }
                    assertThat(commit.getEdges().isEmpty()).isTrue();
                    break;
                case 1:
                    // Should have node1/node2 as boundaries, with edge1 included
                    assertThat(commit.getNodes().size()).isEqualTo(2);
                    for (CommitNode commitNode: commit.getNodes()) {
                        assertThat(commitNode.getId()).isIn(node1.getId(), node2.getId());
                        assertThat(commitNode.isBoundary()).isTrue();
                    }
                    assertThat(commit.getEdges().size()).isEqualTo(1);
                    for (CommitEdge commitEdge: commit.getEdges()) {
                        assertThat(commitEdge.getId()).isEqualTo(edge1.getId());
                        assertThat(commitEdge.getFrom()).isEqualTo(node1.getId());
                        assertThat(commitEdge.getTo()).isEqualTo(node2.getId());
                    }
                    break;
                case 2:
                    // Should have node1 and edge2, with node2 as boundary
                    assertThat(commit.getNodes().size()).isEqualTo(2);
                    for (CommitNode commitNode: commit.getNodes()) {
                        if (commitNode.getId().equals(node1.getId())) {
                            assertThat(commitNode.isBoundary()).isFalse();
                        } else if (commitNode.getId().equals(node2.getId())) {
                            assertThat(commitNode.isBoundary()).isTrue();
                        } else {
                            fail("unknown commit node");
                        }
                    }
                    assertThat(commit.getEdges().size()).isEqualTo(1);
                    for (CommitEdge commitEdge: commit.getEdges()) {
                        assertThat(commitEdge.getId()).isEqualTo(edge2.getId());
                        assertThat(commitEdge.getFrom()).isEqualTo(node2.getId());
                        assertThat(commitEdge.getTo()).isEqualTo(node1.getId());
                    }
                    break;
                case 3:
                    // Should have node1 and edge1, with node2 as boundary
                    assertThat(commit.getNodes().size()).isEqualTo(2);
                    for (CommitNode commitNode: commit.getNodes()) {
                        if (commitNode.getId().equals(node1.getId())) {
                            assertThat(commitNode.isBoundary()).isFalse();
                        } else if (commitNode.getId().equals(node2.getId())) {
                            assertThat(commitNode.isBoundary()).isTrue();
                        } else {
                            fail("unknown commit node");
                        }
                    }
                    assertThat(commit.getEdges().size()).isEqualTo(1);
                    for (CommitEdge commitEdge: commit.getEdges()) {
                        assertThat(commitEdge.getId()).isEqualTo(edge1.getId());
                        assertThat(commitEdge.getFrom()).isEqualTo(node1.getId());
                        assertThat(commitEdge.getTo()).isEqualTo(node2.getId());
                    }
                    break;
                default:
                    fail("To many commits");
            }
            assertThat(commit.getPrev()).isEqualTo(prevCommitId);
            prevCommitId = commit.getId();
            num++;
        }
    }
}

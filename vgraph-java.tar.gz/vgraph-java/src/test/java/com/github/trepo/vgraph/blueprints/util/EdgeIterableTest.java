package com.github.trepo.vgraph.blueprints.util;

import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.KeyIndexableGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import java.util.Iterator;
import java.util.NoSuchElementException;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class EdgeIterableTest {

    @Test
    public void shouldReturn0When0Present() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");


        int i = 0;
        for(Edge e: new EdgeIterable(graph.getBlueprintsGraph().getEdges(), graph)) {
            i++;
        }
        assertThat(i).isEqualTo(0);
    }

    @Test
    public void shouldReturn0When1Present1Deleted() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        graph.removeEdge(graph.addEdge(n1, n2, "label").getId());

        int i = 0;
        for(Edge e: new EdgeIterable(graph.getBlueprintsGraph().getEdges(), graph)) {
            i++;
        }
        assertThat(i).isEqualTo(0);

    }

    @Test
    public void shouldReturn1When2Present1Deleted() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        Node n3 = graph.addNode("label");
        Node n4 = graph.addNode("label");
        Edge edge = graph.addEdge(n1, n2,"label");
        graph.removeEdge(graph.addEdge(n3, n4, "label").getId());

        int i = 0;
        for(Edge e: new EdgeIterable(graph.getBlueprintsGraph().getEdges(), graph)) {
            i++;
            assertThat(e.getId()).isEqualTo(edge.getId());
        }
        assertThat(i).isEqualTo(1);
    }

    @Test
    public void shouldReturn0When2Present2Deleted() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        Node n3 = graph.addNode("label");
        Node n4 = graph.addNode("label");
        graph.removeEdge(graph.addEdge(n1, n2,"label").getId());
        graph.removeEdge(graph.addEdge(n3, n4,"label").getId());

        int i = 0;
        for(Edge e: new EdgeIterable(graph.getBlueprintsGraph().getEdges(), graph)) {
            i++;
        }
        assertThat(i).isEqualTo(0);
    }


    @Test
    public void shouldReturn3When5Present2Deleted() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        Node n3 = graph.addNode("label");
        Node n4 = graph.addNode("label");
        graph.addEdge(n1, n2,"label");
        graph.removeEdge(graph.addEdge(n2, n3,"label").getId());
        graph.addEdge(n3, n4,"label");
        graph.removeEdge(graph.addEdge(n4, n1,"label").getId());
        graph.addEdge(n1, n4,"label");

        int i = 0;
        for(Edge e: new EdgeIterable(graph.getBlueprintsGraph().getEdges(), graph)) {
            i++;
        }
        assertThat(i).isEqualTo(3);
    }

    @Test
    public void shouldErrorWhenCallingNextWithNoElements() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");

        Iterator itr = new EdgeIterable(graph.getBlueprintsGraph().getEdges(), graph).iterator();

        try {
            itr.next();
            fail("Should have thrown error");
        } catch(NoSuchElementException e) {
            assertThat(e.getMessage()).isEqualTo("No more elements");
        }
    }

    @Test
    public void shouldFailOnRemove() {
        KeyIndexableGraph g = new TinkerGraph();
        BlueprintsVGraph graph = new BlueprintsVGraph(g, "repo");
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        Node n3 = graph.addNode("label");
        Node n4 = graph.addNode("label");
        Edge edge = graph.addEdge(n1, n2,"label");

        Iterator itr = new EdgeIterable(graph.getBlueprintsGraph().getEdges(), graph).iterator();
        itr.next();
        try {
            itr.remove();
            fail("Should have failed on method not allowed");
        } catch(UnsupportedOperationException e) {
            assertThat(e.getMessage()).isEqualTo("Method not implemented");
        }
    }
}

package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Action;
import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.CommitEdge;
import com.github.trepo.vgraph.CommitNode;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.MetaProperty;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.blueprints.util.Util;
import com.tinkerpop.blueprints.Direction;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Set;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class BlueprintsVGraph_CommitTest {

    String repo = "repo";
    TinkerGraph tinkerGraph;
    BlueprintsVGraph graph;

    @BeforeMethod
    public void beforeTest() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
    }

    /**
     * commit
     */
    // A commit with an empty graph should have repo, author, etc but no nodes or edges
    @Test
    public void commit_shouldReturnEmptyCommit() {

        Commit commit = graph.commit("author", "email", "message");

        assertThat(commit.getAuthor()).isEqualTo("author");
        assertThat(commit.getEmail()).isEqualTo("email");
        assertThat(commit.getMessage()).isEqualTo("message");
        assertThat(commit.getNodes().isEmpty()).isEqualTo(true);
        assertThat(commit.getEdges().isEmpty()).isEqualTo(true);
    }

    // Empty commit when all hashes are set
    @Test
    public void commit_shouldBeEmptyCommitOnSetHashes() {
        Node node = graph.addNode("label");
        tinkerGraph.getVertex(node.getId()).setProperty(SpecialProperty.HASH, Util.calculateHash(node));

        Commit commit = graph.commit("author", "email", "message");
        assertThat(commit.getNodes().isEmpty()).isEqualTo(true);
        assertThat(commit.getEdges().isEmpty()).isEqualTo(true);
    }

    // Should clear dirty flag
    @Test
    public void commit_shouldClearDirtyFlag() {
        assertThat(graph.info().isClean()).isTrue();

        graph.addNode("label");

        assertThat(graph.info().isClean()).isFalse();

        graph.commit("author", "email", "message");

        assertThat(graph.info().isClean()).isTrue();
    }

    // One node added
    @Test
    public void commit_shouldAddNode() {
        Node node = graph.addNode("label");

        Commit commit = graph.commit("author", "email", "message");
        assertThat(commit.getEdges().isEmpty()).isEqualTo(true);
        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);

        for(CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitNode.getProperties().isEmpty()).isEqualTo(true);
        }

        Vertex v = tinkerGraph.getVertex(node.getId());

        assertThat(v.getProperty(SpecialProperty.HASH)).isEqualTo(SpecialProperty.calculateHash(new HashMap<String, Object>()));

    }

    // One Node updated
    @Test
    public void commit_shouldUpdateNode() {
        Node node = graph.addNode("label");
        graph.commit("author", "email", "message");

        node.setProperty("foo", "bar");

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("foo", "bar");
        String hash = SpecialProperty.calculateHash(properties);

        Commit commit = graph.commit("author", "email", "message");
        assertThat(commit.getEdges().isEmpty()).isEqualTo(true);
        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);

        for(CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.UPDATE);
            assertThat(commitNode.getOriginal().isEmpty()).isEqualTo(true);
            assertThat(commitNode.getProperties()).isEqualTo(properties);
        }

        Vertex v = tinkerGraph.getVertex(node.getId());
        assertThat(v.getProperty(SpecialProperty.HASH)).isEqualTo(hash);
        assertThat(v.getProperty(SpecialProperty.ORIGINAL)).isNull();
    }

    // One Node deleted
    @Test
    public void commit_shouldDeleteNode() {
        Node node = graph.addNode("label");
        node.setProperty("foo", "bar");
        graph.commit("author", "email", "message");

        graph.removeNode(node.getId());

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("foo", "bar");

        Commit commit = graph.commit("author", "email", "message");
        assertThat(commit.getEdges().isEmpty()).isEqualTo(true);
        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);

        for(CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.DELETE);
            assertThat(commitNode.getOriginal()).isEqualTo(properties);
        }

        assertThat(tinkerGraph.getVertex(node.getId())).isNull();
    }

    // One node changed then deleted
    @Test
    public void commit_shouldUseOriginalOnUpdateThenDelete() {
        Node node = graph.addNode("label");
        node.setProperty("foo", "bar");
        graph.commit("author", "email", "message");

        node.removeProperty("foo");
        node.setProperty("testing", true);
        graph.removeNode(node.getId());

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("foo", "bar");

        Commit commit = graph.commit("author", "email", "message");
        assertThat(commit.getEdges().isEmpty()).isEqualTo(true);
        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);

        for(CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.DELETE);
            assertThat(commitNode.getOriginal()).isEqualTo(properties);
        }
    }

    // One node added and deleted should show nothing
    @Test
    public void commit_NodeAddTheDeleteShouldAutomaticallyCleanup() {
        Node node = graph.addNode("label");
        graph.removeNode(node.getId());

        Commit commit = graph.commit("author", "email", "message");
        assertThat(commit.getEdges().isEmpty()).isEqualTo(true);
        assertThat(commit.getNodes().isEmpty()).isEqualTo(true);

        assertThat(tinkerGraph.getVertex(node.getId())).isNull();
    }

    // One edge added and deleted should show nothing
    @Test
    public void commit_EdgeAddTheDeleteShouldAutomaticallyCleanup() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        graph.commit("author", "email", "message");
        Edge edge = node1.addEdge(node2, "label");
        graph.removeEdge(edge.getId());

        Commit commit = graph.commit("author", "email", "message");
        assertThat(commit.getEdges().isEmpty()).isEqualTo(true);
        assertThat(commit.getNodes().isEmpty()).isEqualTo(true);

        assertThat(tinkerGraph.getEdge(((BlueprintsEdge) edge).getBlueprintsEdge().getId())).isNull();
    }

    // Delete node should delete attached edges
    @Test
    public void commit_DeleteNodeShouldDeleteEdge() {
        Node node1 = graph.addNode("label");
        tinkerGraph.getVertex(node1.getId()).setProperty(SpecialProperty.HASH, Util.calculateHash(node1));
        Node node2 = graph.addNode("label");
        tinkerGraph.getVertex(node2.getId()).setProperty(SpecialProperty.HASH, Util.calculateHash(node2));
        Edge edge = node1.addEdge(node2, "edge");
        tinkerGraph.getEdge(((BlueprintsEdge)edge).getBlueprintsEdge().getId()).setProperty(SpecialProperty.HASH, Util.calculateHash(edge));

        graph.removeNode(node2.getId());

        Commit commit = graph.commit("author", "email", "message");
        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);

        for(CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node2.getId());
            assertThat(commitNode.isBoundary()).isEqualTo(false);
            assertThat(commitNode.getAction()).isEqualTo(Action.DELETE);
        }

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(1);
        for(CommitEdge commitEdge: edges) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.DELETE);
        }

        assertThat(tinkerGraph.getVertex(node1.getId())).isNotNull();
        assertThat(tinkerGraph.getVertex(node2.getId())).isNull();
        assertThat(tinkerGraph.getEdge(((BlueprintsEdge)edge).getBlueprintsEdge().getId())).isNull();
    }

    // Deleting an edge shouldn't touch the nodes
    @Test
    public void commit_shouldOnlyDeleteEdge() {
        Node node1 = graph.addNode("label");
        tinkerGraph.getVertex(node1.getId()).setProperty(SpecialProperty.HASH, Util.calculateHash(node1));
        Node node2 = graph.addNode("label");
        tinkerGraph.getVertex(node2.getId()).setProperty(SpecialProperty.HASH, Util.calculateHash(node2));
        Edge edge = node1.addEdge(node2, "edge");
        edge.setProperty("foo", "bar");
        tinkerGraph.getEdge(((BlueprintsEdge)edge).getBlueprintsEdge().getId()).setProperty(SpecialProperty.HASH, Util.calculateHash(edge));

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("foo", "bar");

        graph.removeEdge(edge.getId());

        Commit commit = graph.commit("author", "email", "message");
        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(0);

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(1);
        for(CommitEdge commitEdge: edges) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.DELETE);
            assertThat(commitEdge.getOriginal()).isEqualTo(properties);
        }

        assertThat(tinkerGraph.getVertex(node1.getId())).isNotNull();
        assertThat(tinkerGraph.getVertex(node2.getId())).isNotNull();
        assertThat(tinkerGraph.getEdge(((BlueprintsEdge)edge).getBlueprintsEdge().getId())).isNull();
    }

    // One edge changed then deleted
    @Test
    public void commit_shouldUseOriginalWhenEdgeUpdatedAndDeleted() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = node1.addEdge(node2, "edge");
        edge.setProperty("foo", "bar");
        graph.commit("author", "email", "message");

        edge.removeProperty("foo");
        edge.setProperty("testing", true);
        graph.removeEdge(edge.getId());

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("foo", "bar");

        Commit commit = graph.commit("author", "email", "message");
        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(0);

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(1);
        for(CommitEdge commitEdge: edges) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.DELETE);
            assertThat(commitEdge.getOriginal()).isEqualTo(properties);
        }

        assertThat(tinkerGraph.getVertex(node1.getId())).isNotNull();
        assertThat(tinkerGraph.getVertex(node2.getId())).isNotNull();
        assertThat(tinkerGraph.getEdge(((BlueprintsEdge)edge).getBlueprintsEdge().getId())).isNull();
    }

    // An edge should create a boundary node at either end (with proper from/to)
    @Test
    public void commit_shouldCreateBoundaryNodes() {
        Node node1 = graph.addNode("label");
        tinkerGraph.getVertex(node1.getId()).setProperty(SpecialProperty.HASH, Util.calculateHash(node1));
        Node node2 = graph.addNode("label");

        String nodeHash = SpecialProperty.calculateHash(new HashMap<String, Object>());

        tinkerGraph.getVertex(node2.getId()).setProperty(SpecialProperty.HASH, Util.calculateHash(node2));
        Edge edge = node1.addEdge(node2, "edge");
        edge.setProperty("foo", "bar");

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("foo", "bar");

        String edgeHash = SpecialProperty.calculateHash(properties);

        Commit commit = graph.commit("author", "email", "message");
        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(2);

        for(CommitNode commitNode: nodes) {
            assertThat(commitNode.isBoundary()).isEqualTo(true);
            assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitNode.isBoundary()).isEqualTo(true);
            assertThat(commitNode.getRepo()).isEqualTo(repo);
        }

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(1);
        for(CommitEdge commitEdge: edges) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitEdge.getProperties()).isEqualTo(properties);
        }

        assertThat(tinkerGraph.getVertex(node1.getId()).getProperty(SpecialProperty.HASH)).isEqualTo(nodeHash);
        assertThat(tinkerGraph.getVertex(node1.getId()).getProperty(SpecialProperty.HASH)).isEqualTo(nodeHash);
        assertThat(tinkerGraph.getEdge(((BlueprintsEdge)edge).getBlueprintsEdge().getId()).getProperty(SpecialProperty.HASH)).isEqualTo(edgeHash);
    }

    // Updating an edge create a boundary node at either end (with proper from/to)
    @Test
    public void commit_shouldCreateBoundariesOnUpdate() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = node1.addEdge(node2, "edge");
        edge.setProperty("foo", "bar");
        graph.commit("author", "email", "message");

        edge.removeProperty("foo");
        edge.setProperty("testing", true);

        HashMap<String, Object> original = new HashMap<>();
        original.put("foo", "bar");

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", true);

        String edgeHash = SpecialProperty.calculateHash(properties);

        Commit commit = graph.commit("author", "email", "message");

        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(2);
        for(CommitNode commitNode: nodes) {
            assertThat(commitNode.isBoundary()).isEqualTo(true);
            assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitNode.isBoundary()).isEqualTo(true);
            assertThat(commitNode.getRepo()).isEqualTo(repo);
        }

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(1);
        for(CommitEdge commitEdge: edges) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.UPDATE);
            assertThat(commitEdge.getOriginal()).isEqualTo(original);
            assertThat(commitEdge.getProperties()).isEqualTo(properties);
            assertThat(commitEdge.getHash()).isEqualTo(edgeHash);
        }

        assertThat(tinkerGraph.getEdge(((BlueprintsEdge)edge).getBlueprintsEdge().getId()).getProperty(SpecialProperty.HASH)).isEqualTo(edgeHash);
    }

    // An edge created between a node and boundary should create 2 boundaries,
    // one from this repo and one from the specified repo
    // TODO

    // When an edge is added and then the from node is deleted in the same commit,
    // the edge should be deleted and not present in the commit
    @Test
    public void commit_shouldDeleteEdgeWhenNodeDeletedInSameCommit() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        graph.commit("author", "email", "message");
        Edge edge = node1.addEdge(node2, "edge");
        graph.removeNode(node2.getId());

        Commit commit = graph.commit("author", "email", "message");

        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);
        for(CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node2.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.DELETE);
            assertThat(commitNode.getOriginal().isEmpty()).isEqualTo(true);
        }

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(0);

        assertThat(tinkerGraph.getVertex(node1.getId())).isNotNull();
        assertThat(tinkerGraph.getVertex(node2.getId())).isNull();
        assertThat(tinkerGraph.getEdge(((BlueprintsEdge)edge).getBlueprintsEdge().getId())).isNull();
    }

    // Should Create Proper Commit Node/Edges for commit
    @Test
    public void commit_shouldCreateFirstCommitNode() {
        int i;

        // Make sure we have no commit nodes
        Vertex root = tinkerGraph.getVertex(MetaProperty.ROOT);
        assertThat(root.getVertices(Direction.BOTH).iterator().hasNext()).isFalse();

        // Commit 1
        graph.addNode("label");
        Commit commit1 = graph.commit("author", "email", "message");
        Vertex commitNode1 = null;

        // Make sure root points to one commit, the first commit
        i = 0;
        for (Vertex v: root.getVertices(Direction.OUT, MetaProperty.COMMIT_EDGE)) {
            i++;
            assertThat(v.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit1.getId());
        }
        assertThat(i).isEqualTo(1);

        // Make sure first commit points to root, and it is the only one
        i = 0;
        for (Vertex v: root.getVertices(Direction.IN, MetaProperty.COMMIT_EDGE)) {
            i++;
            assertThat(v.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit1.getId());
            commitNode1 = v;
        }
        assertThat(i).isEqualTo(1);

        // Commit 2
        graph.addNode("label");
        Commit commit2 = graph.commit("author", "email", "message");
        Vertex commitNode2 = null;

        // Make sure root points to one commit, the first commit
        i = 0;
        for (Vertex v: root.getVertices(Direction.OUT, MetaProperty.COMMIT_EDGE)) {
            i++;
            assertThat(v.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit1.getId());
        }
        assertThat(i).isEqualTo(1);

        // Make sure second commit points to root, and it is the only one
        i = 0;
        for (Vertex v: root.getVertices(Direction.IN, MetaProperty.COMMIT_EDGE)) {
            i++;
            assertThat(v.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit2.getId());
            commitNode2 = v;
        }
        assertThat(i).isEqualTo(1);

        // Make sure the first commit points to the second commit
        i = 0;
        for (Vertex v: commitNode1.getVertices(Direction.OUT, MetaProperty.COMMIT_EDGE)) {
            i++;
            assertThat(v.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit2.getId());
        }
        assertThat(i).isEqualTo(1);

        // Commit 2
        graph.addNode("label");
        Commit commit3 = graph.commit("author", "email", "message");

        // Make sure root points to one commit, the first commit
        i = 0;
        for (Vertex v: root.getVertices(Direction.OUT, MetaProperty.COMMIT_EDGE)) {
            i++;
            assertThat(v.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit1.getId());
        }
        assertThat(i).isEqualTo(1);

        // Make sure second commit points to root, and it is the only one
        i = 0;
        for (Vertex v: root.getVertices(Direction.IN, MetaProperty.COMMIT_EDGE)) {
            i++;
            assertThat(v.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit3.getId());
        }
        assertThat(i).isEqualTo(1);

        // Make sure the first commit points to the second commit
        i = 0;
        for (Vertex v: commitNode1.getVertices(Direction.OUT, MetaProperty.COMMIT_EDGE)) {
            i++;
            assertThat(v.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit2.getId());
        }
        assertThat(i).isEqualTo(1);

        // Make sure the second commit points to the third commit
        i = 0;
        for (Vertex v: commitNode2.getVertices(Direction.OUT, MetaProperty.COMMIT_EDGE)) {
            i++;
            assertThat(v.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit3.getId());
        }
        assertThat(i).isEqualTo(1);
    }

}

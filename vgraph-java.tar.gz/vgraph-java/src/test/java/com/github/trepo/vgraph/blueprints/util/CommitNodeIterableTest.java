package com.github.trepo.vgraph.blueprints.util;

import com.github.trepo.vgraph.MetaProperty;
import com.github.trepo.vgraph.VGraphException;
import com.tinkerpop.blueprints.Direction;
import com.tinkerpop.blueprints.KeyIndexableGraph;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.Test;

import java.util.Iterator;
import java.util.NoSuchElementException;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class CommitNodeIterableTest {

    @Test
    public void shouldReturn0Commits() {
        KeyIndexableGraph g = new TinkerGraph();
        Vertex root = g.addVertex("1234");

        Iterator<Vertex> itr = new CommitNodeIterable(root, Direction.OUT).iterator();

        assertThat(itr.hasNext()).isFalse();
    }

    @Test
    public void shouldReturn1Commit() {
        KeyIndexableGraph g = new TinkerGraph();
        Vertex root = g.addVertex("root");
        Vertex commit1 = g.addVertex("commit1");
        commit1.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        root.addEdge(MetaProperty.COMMIT_EDGE, commit1);
        commit1.addEdge(MetaProperty.COMMIT_EDGE, root);

        Iterator<Vertex> itr = new CommitNodeIterable(root, Direction.OUT).iterator();
        assertThat(itr.hasNext()).isTrue();
        assertThat(itr.next().getId()).isEqualTo("commit1");
        assertThat(itr.hasNext()).isFalse();
    }

    @Test
    public void shouldReturn3Commits() {
        KeyIndexableGraph g = new TinkerGraph();
        Vertex root = g.addVertex("root");

        Vertex commit1 = g.addVertex("commit1");
        commit1.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        root.addEdge(MetaProperty.COMMIT_EDGE, commit1);

        Vertex commit2 = g.addVertex("commit2");
        commit2.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        commit1.addEdge(MetaProperty.COMMIT_EDGE, commit2);

        Vertex commit3 = g.addVertex("commit3");
        commit3.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        commit2.addEdge(MetaProperty.COMMIT_EDGE, commit3);

        commit3.addEdge(MetaProperty.COMMIT_EDGE, root);

        Iterator<Vertex> itr = new CommitNodeIterable(root, Direction.OUT).iterator();
        assertThat(itr.hasNext()).isTrue();
        assertThat(itr.next().getId()).isEqualTo("commit1");
        assertThat(itr.hasNext()).isTrue();
        assertThat(itr.next().getId()).isEqualTo("commit2");
        assertThat(itr.hasNext()).isTrue();
        assertThat(itr.next().getId()).isEqualTo("commit3");
        assertThat(itr.hasNext()).isFalse();
    }

    @Test
    public void shouldIgnoreNonCommitNodes() {
        KeyIndexableGraph g = new TinkerGraph();
        Vertex root = g.addVertex("root");
        Vertex commit1 = g.addVertex("invalid");
        root.addEdge(MetaProperty.COMMIT_EDGE, commit1);
        commit1.addEdge(MetaProperty.COMMIT_EDGE, root);

        Iterator<Vertex> itr = new CommitNodeIterable(root, Direction.OUT).iterator();
        assertThat(itr.hasNext()).isFalse();
    }

    @Test
    public void shouldWorkOnlyCallingNext() {
        KeyIndexableGraph g = new TinkerGraph();
        Vertex root = g.addVertex("root");

        Vertex commit1 = g.addVertex("commit1");
        commit1.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        root.addEdge(MetaProperty.COMMIT_EDGE, commit1);

        Vertex commit2 = g.addVertex("commit2");
        commit2.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        commit1.addEdge(MetaProperty.COMMIT_EDGE, commit2);

        Vertex commit3 = g.addVertex("commit3");
        commit3.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        commit2.addEdge(MetaProperty.COMMIT_EDGE, commit3);

        commit3.addEdge(MetaProperty.COMMIT_EDGE, root);

        Iterator<Vertex> itr = new CommitNodeIterable(root, Direction.OUT).iterator();
        assertThat(itr.next().getId()).isEqualTo("commit1");
        assertThat(itr.next().getId()).isEqualTo("commit2");
        assertThat(itr.next().getId()).isEqualTo("commit3");
        assertThat(itr.hasNext()).isFalse();
    }

    @Test
    public void shouldReturnCommitsInCorrectOrder() {
        KeyIndexableGraph g = new TinkerGraph();
        Vertex root = g.addVertex("root");

        Vertex commit1 = g.addVertex("commit1");
        commit1.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        root.addEdge(MetaProperty.COMMIT_EDGE, commit1);

        Vertex commit2 = g.addVertex("commit2");
        commit2.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        commit1.addEdge(MetaProperty.COMMIT_EDGE, commit2);

        Vertex commit3 = g.addVertex("commit3");
        commit3.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        commit2.addEdge(MetaProperty.COMMIT_EDGE, commit3);

        commit3.addEdge(MetaProperty.COMMIT_EDGE, root);

        Iterator<Vertex> itr = new CommitNodeIterable(root, Direction.OUT).iterator();
        assertThat(itr.next().getId()).isEqualTo("commit1");
        assertThat(itr.next().getId()).isEqualTo("commit2");
        assertThat(itr.next().getId()).isEqualTo("commit3");
        assertThat(itr.hasNext()).isFalse();

        itr = new CommitNodeIterable(root, Direction.IN).iterator();
        assertThat(itr.next().getId()).isEqualTo("commit3");
        assertThat(itr.next().getId()).isEqualTo("commit2");
        assertThat(itr.next().getId()).isEqualTo("commit1");
        assertThat(itr.hasNext()).isFalse();
    }

    @Test
    public void shouldOnlyFollowCommitEdges() {
        KeyIndexableGraph g = new TinkerGraph();
        Vertex root = g.addVertex("root");
        Vertex commit1 = g.addVertex("commit1");
        commit1.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        root.addEdge("bogus", commit1);
        commit1.addEdge("bogus", root);

        Iterator<Vertex> itr = new CommitNodeIterable(root, Direction.OUT).iterator();
        assertThat(itr.hasNext()).isFalse();
    }

    @Test
    public void shouldErrorWhenCallingNextWithNoElements() {
        KeyIndexableGraph g = new TinkerGraph();
        Vertex root = g.addVertex("root");

        Iterator<Vertex> itr = new CommitNodeIterable(root, Direction.OUT).iterator();

        try {
            itr.next();
        } catch(NoSuchElementException e) {
            assertThat(e.getMessage()).isEqualTo("No more nodes");
        }
    }

    @Test
    public void shouldErrorOnRemove() {
        KeyIndexableGraph g = new TinkerGraph();
        Vertex root = g.addVertex("root");

        Iterator<Vertex> itr = new CommitNodeIterable(root, Direction.OUT).iterator();

        try {
            itr.remove();
            fail("should have errored");
        } catch(UnsupportedOperationException e) {
            assertThat(e.getMessage()).isEqualTo("Method not implemented");
        }
    }
}

package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Action;
import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.CommitEdge;
import com.github.trepo.vgraph.CommitNode;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class BlueprintsVGraph_StatusTest {

    String repo = "repo";
    TinkerGraph tinkerGraph;
    BlueprintsVGraph graph;

    @BeforeMethod
    public void beforeTest() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
    }

    @Test
    public void status_shouldReturnEmptyCommit() {
        Commit commit = graph.status();
        commit.validate();

        assertThat(commit.getVersion()).isEqualTo(1);
        assertThat(commit.getId()).isNotNull();
        assertThat(SpecialProperty.isValidId(commit.getId())).isTrue();
        assertThat(commit.getPrev()).isNull();
        assertThat(commit.getRepo()).isEqualTo(repo);
        assertThat(commit.getTimestamp()).isNotNull();
        assertThat(commit.getAuthor()).isNotNull();
        assertThat(commit.getEmail()).isNotNull();
        assertThat(commit.getMessage()).isNotNull();
        assertThat(commit.getNodes()).isNotNull();
        assertThat(commit.getNodes().size()).isEqualTo(0);
        assertThat(commit.getEdges()).isNotNull();
        assertThat(commit.getEdges().size()).isEqualTo(0);
    }

    @Test
    public void status_shouldReturnCommitWithCreatedNodes() {
        Node node = graph.addNode("label");

        Commit commit = graph.status();
        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(1);

        for (CommitNode commitNode: commit.getNodes()) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitNode.isBoundary()).isFalse();
        }
    }

    @Test
    public void status_shouldReturnCommitWithCreatedEdgesWithNodes() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = node1.addEdge(node2, "label");

        Commit commit = graph.status();
        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(2);

        for (CommitNode commitNode: commit.getNodes()) {
            assertThat(commitNode.getId()).isIn(node1.getId(), node2.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitNode.isBoundary()).isFalse();
        }

        assertThat(commit.getEdges().size()).isEqualTo(1);

        for (CommitEdge commitEdge: commit.getEdges()) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getFrom()).isEqualTo(node1.getId());
            assertThat(commitEdge.getTo()).isEqualTo(node2.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.CREATE);
        }
    }

    @Test
    public void status_shouldReturnCommitWithCreatedEdgesWithBoundaries() {
        String node1Id = SpecialProperty.generateId();
        Vertex v = tinkerGraph.addVertex(node1Id);
        v.setProperty(SpecialProperty.ID, node1Id);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "external-repo");

        Node node1 = graph.getNode(node1Id);
        Node node2 = graph.addNode("label");
        graph.commit("","","");
        Edge edge = node1.addEdge(node2, "label");

        Commit commit = graph.status();
        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(2);

        for (CommitNode commitNode: commit.getNodes()) {
            assertThat(commitNode.getId()).isIn(node1.getId(), node2.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitNode.isBoundary()).isTrue();

            if(commitNode.getId().equals(node1Id)) {
                assertThat(commitNode.getRepo()).isEqualTo("external-repo");
            } else {
                assertThat(commitNode.getRepo()).isEqualTo("repo");
            }
        }

        assertThat(commit.getEdges().size()).isEqualTo(1);

        for (CommitEdge commitEdge: commit.getEdges()) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getFrom()).isEqualTo(node1.getId());
            assertThat(commitEdge.getTo()).isEqualTo(node2.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.CREATE);
        }
    }

    @Test
    public void status_shouldReturnCommitWithCreatedEdgesWithFlippedBoundaries() {
        String node1Id = SpecialProperty.generateId();
        Vertex v = tinkerGraph.addVertex(node1Id);
        v.setProperty(SpecialProperty.ID, node1Id);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "external-repo");

        Node node1 = graph.getNode(node1Id);
        Node node2 = graph.addNode("label");
        graph.commit("","","");
        Edge edge = node2.addEdge(node1, "label");

        Commit commit = graph.status();
        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(2);

        for (CommitNode commitNode: commit.getNodes()) {
            assertThat(commitNode.getId()).isIn(node1.getId(), node2.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitNode.isBoundary()).isTrue();

            if(commitNode.getId().equals(node1Id)) {
                assertThat(commitNode.getRepo()).isEqualTo("external-repo");
            } else {
                assertThat(commitNode.getRepo()).isEqualTo("repo");
            }
        }

        assertThat(commit.getEdges().size()).isEqualTo(1);

        for (CommitEdge commitEdge: commit.getEdges()) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getFrom()).isEqualTo(node2.getId());
            assertThat(commitEdge.getTo()).isEqualTo(node1.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.CREATE);
        }
    }

    @Test
    public void status_shouldReturnCommitWithUpdatedNodes() {
        Node node = graph.addNode("label");
        graph.commit("","","");

        node.setProperty("foo", "bar");

        Commit commit = graph.status();
        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(1);

        for (CommitNode commitNode: commit.getNodes()) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.UPDATE);
            assertThat(commitNode.isBoundary()).isFalse();
            assertThat(commitNode.getOriginal().isEmpty()).isTrue();
            assertThat(commitNode.getProperties().get("foo")).isEqualTo("bar");
        }
    }

    @Test
    public void status_shouldReturnCommitWithUpdatedEdgesAndBoundaries() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = node1.addEdge(node2, "label");
        graph.commit("","","");

        edge.setProperty("foo", "bar");

        Commit commit = graph.status();
        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(2);

        for (CommitNode commitNode: commit.getNodes()) {
            assertThat(commitNode.getId()).isIn(node1.getId(), node2.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitNode.isBoundary()).isTrue();
        }

        assertThat(commit.getEdges().size()).isEqualTo(1);

        for (CommitEdge commitEdge: commit.getEdges()) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getFrom()).isEqualTo(node1.getId());
            assertThat(commitEdge.getTo()).isEqualTo(node2.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.UPDATE);
            assertThat(commitEdge.getOriginal().isEmpty()).isTrue();
            assertThat(commitEdge.getProperties().get("foo")).isEqualTo("bar");
        }
    }

    @Test
    public void status_shouldReturnCommitWithDeletedNodes() {
        Node node = graph.addNode("label");
        graph.commit("","","");

        graph.removeNode(node.getId());

        Commit commit = graph.status();
        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(1);

        for (CommitNode commitNode: commit.getNodes()) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.DELETE);
        }
    }

    @Test
    public void status_shouldReturnCommitWithDeletedEdges() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = node1.addEdge(node2, "label");
        graph.commit("","","");

        graph.removeEdge(edge.getId());

        Commit commit = graph.status();
        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(0);

        assertThat(commit.getEdges().size()).isEqualTo(1);

        for (CommitEdge commitEdge: commit.getEdges()) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getFrom()).isEqualTo(node1.getId());
            assertThat(commitEdge.getTo()).isEqualTo(node2.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.DELETE);
        }
    }

    @Test
    public void status_shouldReturnCommitWithDeletedBoundaryNode() {
        // TODO ?
    }

    @Test
    public void status_shouldReturnCommitWithNothingForAddedThenDeletedNode() {
        Node node = graph.addNode("label");
        graph.removeNode(node.getId());

        Commit commit = graph.status();
        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(0);
    }

    @Test
    public void status_shouldReturnCommitWithNothingForAddedThenDeletedEdge() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        graph.commit("","","");
        Edge edge = node1.addEdge(node2, "label");
        graph.removeEdge(edge.getId());

        Commit commit = graph.status();
        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(0);
        assertThat(commit.getEdges().size()).isEqualTo(0);
    }
}

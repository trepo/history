package com.github.trepo.vgraph.blueprints;


import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.Info;
import com.github.trepo.vgraph.MetaProperty;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.blueprints.util.Util;
import com.tinkerpop.blueprints.Direction;
import com.tinkerpop.blueprints.Element;
import com.tinkerpop.blueprints.Features;
import com.tinkerpop.blueprints.GraphQuery;
import com.tinkerpop.blueprints.KeyIndexableGraph;
import com.tinkerpop.blueprints.Parameter;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.github.trepo.vgraph.VGraphException;

import java.util.Iterator;
import java.util.Set;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark
 */
public class BlueprintsVGraphTest {

    String repo = "repo";
    TinkerGraph tinkerGraph;
    BlueprintsVGraph graph;

    @BeforeMethod
    public void beforeTest() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
    }

    /**
     * constructor
     */
    @Test
    public void constructor_shouldErrorOnNullBlueprintGraph() {
        try {
            graph = new BlueprintsVGraph(null, repo);
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("Invalid blueprintGraph");
        }
    }

    @Test
    public void constructor_shouldErrorOnInvalidRepo() {
        try {
            graph = new BlueprintsVGraph(tinkerGraph, null);
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("Invalid repository");
        }
    }

    @Test
    public void constructor_shouldErrorOnFeaturelessGraph() {
        final Features f = new Features();
        f.supportsBooleanProperty = false;

        KeyIndexableGraph g = new KeyIndexableGraph() {
            @Override
            public Features getFeatures() {
                return f;
            }

            @Override
            public Vertex addVertex(Object o) {
                return null;
            }

            @Override
            public Vertex getVertex(Object o) {
                return null;
            }

            @Override
            public void removeVertex(Vertex vertex) {

            }

            @Override
            public Iterable<Vertex> getVertices() {
                return null;
            }

            @Override
            public Iterable<Vertex> getVertices(String s, Object o) {
                return null;
            }

            @Override
            public com.tinkerpop.blueprints.Edge addEdge(Object o, Vertex vertex, Vertex vertex2, String s) {
                return null;
            }

            @Override
            public com.tinkerpop.blueprints.Edge getEdge(Object o) {
                return null;
            }

            @Override
            public void removeEdge(com.tinkerpop.blueprints.Edge edge) {

            }

            @Override
            public Iterable<com.tinkerpop.blueprints.Edge> getEdges() {
                return null;
            }

            @Override
            public Iterable<com.tinkerpop.blueprints.Edge> getEdges(String s, Object o) {
                return null;
            }

            @Override
            public GraphQuery query() {
                return null;
            }

            @Override
            public void shutdown() {

            }

            @Override
            public <T extends Element> void dropKeyIndex(String s, Class<T> tClass) {

            }

            @Override
            public <T extends Element> void createKeyIndex(String s, Class<T> tClass, Parameter... parameters) {

            }

            @Override
            public <T extends Element> Set<String> getIndexedKeys(Class<T> tClass) {
                return null;
            }
        };

        try {
            graph = new BlueprintsVGraph(g, repo);
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("Blueprint Graph MUST support the features used by vGraph");
        }
    }

    @Test
    public void constructor_shouldCreateRootNode() {
        Iterator<Vertex> itr = tinkerGraph.getVertices(MetaProperty.KEY, MetaProperty.ROOT).iterator();
        assertThat(itr.hasNext()).isTrue();
    }

    @Test
    public void constructor_shouldNotSetLastCommitOnOnlyRootNode() {
        assertThat(graph.info().getCommit()).isNull();
    }

    @Test
    public void constructor_shouldSetLastCommit() {
        Iterator<Vertex> itr = tinkerGraph.getVertices(MetaProperty.KEY, MetaProperty.ROOT).iterator();
        assertThat(itr.hasNext()).isTrue();
        Vertex root = itr.next();

        Iterator<Vertex> prevCommitItr = root.getVertices(Direction.IN, MetaProperty.COMMIT_EDGE).iterator();
        assertThat(prevCommitItr.hasNext()).isFalse();

        assertThat(graph.info().getCommit()).isNull();

        String commitId = SpecialProperty.generateId();

        Vertex commitNode = tinkerGraph.addVertex(commitId);
        commitNode.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        commitNode.setProperty(MetaProperty.COMMIT_ID, commitId);

        root.addEdge(MetaProperty.COMMIT_EDGE, commitNode);
        commitNode.addEdge(MetaProperty.COMMIT_EDGE, root);

        graph = new BlueprintsVGraph(tinkerGraph, repo);

        assertThat(graph.info().getCommit()).isEqualTo(commitId);
    }

    @Test
    public void constructor_shouldSetDirtyTrueOnDeletedVertex() {

        Vertex v = tinkerGraph.addVertex("1234");
        v.setProperty(SpecialProperty.ID, "1234");
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.HASH, Util.calculateHash(new BlueprintsNode(v, null)));
        v.setProperty(SpecialProperty.DELETED, SpecialProperty.generateTimestamp());

        graph = new BlueprintsVGraph(tinkerGraph, repo);

        assertThat(graph.isDirty()).isTrue();

    }

    @Test
    public void constructor_shouldSetDirtyTrueOnDeletedEdge() {

        String v1Id = SpecialProperty.generateId();
        Vertex v1 = tinkerGraph.addVertex(v1Id);
        v1.setProperty(SpecialProperty.ID, v1Id);
        v1.setProperty(SpecialProperty.LABEL, "label");
        v1.setProperty(SpecialProperty.HASH, Util.calculateHash(new BlueprintsNode(v1, null)));

        String v2Id = SpecialProperty.generateId();
        Vertex v2 = tinkerGraph.addVertex(v2Id);
        v2.setProperty(SpecialProperty.ID, v2Id);
        v2.setProperty(SpecialProperty.LABEL, "label");
        v2.setProperty(SpecialProperty.HASH, Util.calculateHash(new BlueprintsNode(v2, null)));

        String eId = SpecialProperty.generateId();
        com.tinkerpop.blueprints.Edge e = tinkerGraph.addEdge(eId, v1, v2, "edgeLabel");
        e.setProperty(SpecialProperty.ID, eId);
        e.setProperty(SpecialProperty.LABEL, "label");
        e.setProperty(SpecialProperty.HASH, Util.calculateHash(new BlueprintsEdge(e, null)));
        e.setProperty(SpecialProperty.DELETED, SpecialProperty.generateTimestamp());

        graph = new BlueprintsVGraph(tinkerGraph, repo);

        assertThat(graph.isDirty()).isTrue();

    }

    @Test
    public void constructor_shouldSetDirtyTrueOnDirtyVertex() {

        Vertex v = tinkerGraph.addVertex("1234");
        v.setProperty(SpecialProperty.ID, "1234");
        v.setProperty(SpecialProperty.LABEL, "label");

        graph = new BlueprintsVGraph(tinkerGraph, repo);

        assertThat(graph.isDirty()).isTrue();

    }

    @Test
    public void constructor_shouldSetDirtyTrueOnDirtyEdge() {

        String v1Id = SpecialProperty.generateId();
        Vertex v1 = tinkerGraph.addVertex(v1Id);
        v1.setProperty(SpecialProperty.ID, v1Id);
        v1.setProperty(SpecialProperty.LABEL, "label");
        v1.setProperty(SpecialProperty.HASH, Util.calculateHash(new BlueprintsNode(v1, null)));

        String v2Id = SpecialProperty.generateId();
        Vertex v2 = tinkerGraph.addVertex(v2Id);
        v2.setProperty(SpecialProperty.ID, v2Id);
        v2.setProperty(SpecialProperty.LABEL, "label");
        v2.setProperty(SpecialProperty.HASH, Util.calculateHash(new BlueprintsNode(v2, null)));

        String eId = SpecialProperty.generateId();
        com.tinkerpop.blueprints.Edge e = tinkerGraph.addEdge(eId, v1, v2, "edgeLabel");
        e.setProperty(SpecialProperty.ID, eId);
        e.setProperty(SpecialProperty.LABEL, "label");

        graph = new BlueprintsVGraph(tinkerGraph, repo);

        assertThat(graph.isDirty()).isTrue();

    }

    /**
     * getBlueprintGraph
     */
    @Test
    public void getBlueprintGraph_shouldWork() {
        graph = new BlueprintsVGraph(tinkerGraph, repo);
        assertThat(graph.getBlueprintsGraph()).isEqualTo(tinkerGraph);
    }

    /**
     * setDirty
     */
    @Test
    public void setDirty_shouldWork() {
        graph = new BlueprintsVGraph(tinkerGraph, repo);

        assertThat(graph.isDirty()).isFalse();

        graph.setDirty();

        assertThat(graph.isDirty()).isTrue();
    }


    /**
     * info
     */
    @Test
    public void info_shouldWork() {

        Info info = graph.info();

        assertThat(info.getCommit()).isNull();
        assertThat(info.isClean()).isTrue();
        assertThat(info.getRepo()).isEqualTo(repo);
        assertThat(info.getVersion()).isEqualTo("0.2.0");

        graph.addNode("label");
        info = graph.info();

        assertThat(info.isClean()).isFalse();

        Commit commit = graph.commit("author", "email", "message");
        info = graph.info();

        assertThat(info.isClean()).isTrue();
        assertThat(info.getCommit()).isEqualTo(commit.getId());
    }


    /**
     * shutdown
     */
    @Test
    public void shutdown_shouldWork() {
        graph.shutdown();
    }
}

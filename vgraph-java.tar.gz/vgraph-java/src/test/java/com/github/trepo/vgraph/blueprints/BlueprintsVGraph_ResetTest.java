package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class BlueprintsVGraph_ResetTest {

    String repo = "repo";
    TinkerGraph tinkerGraph;
    BlueprintsVGraph graph;

    @BeforeMethod
    public void beforeTest() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
    }

    /**
     * reset
     */
    @Test
    public void reset_shouldResurrectDeletedEdge() {
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        Edge e = graph.addEdge(n1, n2, "label");
        graph.commit("author", "email", "message");
        graph.removeEdge(e.getId());

        assertThat(graph.getEdge(e.getId())).isNull();

        graph.reset();

        assertThat(graph.info().isClean()).isTrue();
        assertThat(graph.getEdge(e.getId())).isNotNull();
    }

    @Test
    public void reset_shouldRevertChangedEdge() {
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        Edge e = graph.addEdge(n1, n2, "label");
        e.setProperty("foo", "bar");
        graph.commit("author", "email", "message");

        e.removeProperty("foo");
        e.setProperty("testing", true);

        graph.reset();

        assertThat(graph.info().isClean()).isTrue();
        assertThat(e.getPropertyKeys().size()).isEqualTo(1);
        assertThat(e.getProperty("foo")).isEqualTo("bar");
    }

    @Test
    public void reset_shouldDeleteAddedEdge() {
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        Edge e = graph.addEdge(n1, n2, "label");

        graph.reset();

        assertThat(graph.info().isClean()).isTrue();
        assertThat(graph.getEdge(e.getId())).isNull();
    }

    @Test
    public void reset_shouldRevertChangedAndDeletedEdge() {
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        Edge e = graph.addEdge(n1, n2, "label");
        e.setProperty("foo", "bar");
        graph.commit("author", "email", "message");

        e.removeProperty("foo");
        e.setProperty("testing", true);
        graph.removeEdge(e.getId());

        graph.reset();

        assertThat(graph.info().isClean()).isTrue();
        assertThat(graph.getEdge(e.getId())).isNotNull();
        assertThat(e.getPropertyKeys().size()).isEqualTo(1);
        assertThat(e.getProperty("foo")).isEqualTo("bar");

    }

    @Test
    public void reset_shouldResurrectDeletedNode() {
        Node n = graph.addNode("label");
        graph.commit("author", "email", "message");
        graph.removeNode(n.getId());

        assertThat(graph.info().isClean()).isFalse();
        assertThat(graph.getNode(n.getId())).isNull();

        graph.reset();

        assertThat(graph.info().isClean()).isTrue();
        assertThat(graph.getNode(n.getId())).isNotNull();

    }

    @Test
    public void reset_shouldRevertChangedNode() {
        Node n = graph.addNode("label");
        n.setProperty("foo", "bar");
        graph.commit("author", "email", "message");

        n.removeProperty("foo");
        n.setProperty("testing", true);

        graph.reset();

        assertThat(graph.info().isClean()).isTrue();
        assertThat(n.getPropertyKeys().size()).isEqualTo(1);
        assertThat(n.getProperty("foo")).isEqualTo("bar");
    }

    @Test
    public void reset_shouldDeleteAddedNode() {
        Node n = graph.addNode("label");

        graph.reset();

        assertThat(graph.info().isClean()).isTrue();
        assertThat(graph.getNode(n.getId())).isNull();
    }

    @Test
    public void reset_shouldRevertChangedAndDeletedNode() {
        Node n = graph.addNode("label");
        n.setProperty("foo", "bar");
        graph.commit("author", "email", "message");

        n.removeProperty("foo");
        n.setProperty("testing", true);
        graph.removeNode(n.getId());

        assertThat(graph.getNode(n.getId())).isNull();

        graph.reset();

        assertThat(graph.info().isClean()).isTrue();
        assertThat(graph.getNode(n.getId())).isNotNull();
        assertThat(n.getPropertyKeys().size()).isEqualTo(1);
        assertThat(n.getProperty("foo")).isEqualTo("bar");
    }

}

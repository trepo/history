package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.SpecialProperty;
import com.tinkerpop.blueprints.KeyIndexableGraph;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.github.trepo.vgraph.VGraphException;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BlueprintsBoundaryTest {

    private BlueprintsBoundary boundary;

    @BeforeMethod
    public void beforeTest() {
        KeyIndexableGraph graph = new TinkerGraph();
        Vertex v = graph.addVertex("1");
        v.setProperty(SpecialProperty.ID, "1");
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "remoteRepo");

        BlueprintsVGraph g = new BlueprintsVGraph(graph, "repo");
        boundary = new BlueprintsBoundary(v, g);
    }

    /**
     * isBoundary
     */
    @Test
    public void isBoundary_shouldReturnTrue() {
        assertThat(boundary.isBoundary()).isEqualTo(true);
    }

    /**
     * setProperty
     */
    @Test
    public void setProperty_shouldErrorOnBadKey() {
        try {
            boundary.setProperty("prop", "one");
            fail("Should have failed on editing a boundary node");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("You may not edit a Boundary Node");
        }
    }

    /**
     * removeProperty
     */
    @Test
    public void removeProperty_shouldErrorOnBadKey() {
        try {
            boundary.removeProperty("prop");
            fail("Should have failed on editing a boundary node");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("You may not edit a Boundary Node");
        }
    }

}

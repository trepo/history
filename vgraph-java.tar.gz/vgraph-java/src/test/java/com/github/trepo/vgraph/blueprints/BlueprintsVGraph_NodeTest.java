package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraphException;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.Iterator;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BlueprintsVGraph_NodeTest {

    String repo = "repo";
    TinkerGraph tinkerGraph;
    BlueprintsVGraph graph;

    @BeforeMethod
    public void beforeTest() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
    }

    /**
     * addNode
     */
    @Test
    public void addNode_shouldAdd() {
        Node node = graph.addNode("label");

        String id = node.getId();

        Node addedNode = graph.getNode(id);

        assertThat(addedNode.getId()).isEqualTo(id);
        assertThat((addedNode.getLabel())).isEqualTo("label");
        assertThat((addedNode.getRepo())).isEqualTo(repo);
    }

    @Test
    public void addNode_shouldValidateLabel() {
        try {
            graph.addNode("_invalid");
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("Invalid Label");
        }
    }

    /**
     * getNode
     */
    @Test
    public void getNode_shouldReturnANode() {

        Vertex v = tinkerGraph.addVertex("1");
        v.setProperty(SpecialProperty.ID, "1");
        v.setProperty(SpecialProperty.LABEL, "label");

        Node node = graph.getNode("1");

        assertThat(node.getId()).isEqualTo("1");
        assertThat((node.getLabel())).isEqualTo("label");
        assertThat((node.getRepo())).isEqualTo(repo);
        assertThat(node.isBoundary()).isEqualTo(false);
    }

    @Test
    public void getNode_shouldReturnABoundary() {

        Vertex v = tinkerGraph.addVertex("1");
        v.setProperty(SpecialProperty.ID, "1");
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "remoteRepo");

        Node node = graph.getNode("1");

        assertThat(node.getId()).isEqualTo("1");
        assertThat((node.getLabel())).isEqualTo("label");
        assertThat((node.getRepo())).isEqualTo("remoteRepo");
        assertThat(node.isBoundary()).isEqualTo(true);
    }

    @Test
    public void getNode_shouldReturnNull() {

        Node node = graph.getNode("1");

        assertThat(node).isEqualTo(null);
    }

    @Test
    public void getNode_shouldReturnNullWhenDeleted() {
        String id = graph.addNode("label").getId();

        graph.removeNode(id);

        assertThat(graph.getNode(id)).isNull();
    }

    /**
     * removeNode
     */
    @Test
    public void removeNode_shouldHandleNotFound() {
        graph.removeNode("doesn't exist");
    }

    @Test
    public void removeNode_shouldNotDeleteBoundaryNode() {

        Vertex v = tinkerGraph.addVertex("boundary");
        v.setProperty(SpecialProperty.ID, "boundary");
        v.setProperty(SpecialProperty.REPO, "repo2");

        try {
            graph.removeNode("boundary");
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("You may not delete a boundary node");
        }
    }

    @Test
    public void removeNode_shouldMarkAsDeleted() {
        Node n = graph.addNode("label");
        graph.removeNode(n.getId());
        assertThat(((BlueprintsNode)n).vertex.getProperty(SpecialProperty.DELETED)).isInstanceOf(Long.class);
    }

    @Test
    public void removeNode_shouldDeleteEdgesAsWell() {
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        Edge edge = graph.addEdge(n1, n2, "edge_label");
        graph.removeNode(n2.getId());

        assertThat(graph.getNode(n2.getId())).isNull();
        assertThat(graph.getEdge(edge.getId())).isNull();
    }

    @Test
    public void removeNode_shouldNotStampOverDeletedEdges() throws InterruptedException {
        Node n1 = graph.addNode("label");
        Node n2 = graph.addNode("label");
        Edge edge1 = graph.addEdge(n1, n2, "edge_label");
        Edge edge2 = graph.addEdge(n1, n2, "edge_label");

        graph.removeEdge(edge1.getId());

        Long edge1OriginalTimestamp = ((BlueprintsEdge)edge1).getBlueprintsEdge().getProperty(SpecialProperty.DELETED);
        Thread.sleep(100);

        graph.removeNode(n2.getId());

        assertThat(graph.getNode(n2.getId())).isNull();
        assertThat(graph.getEdge(edge1.getId())).isNull();
        assertThat(graph.getEdge(edge2.getId())).isNull();

        Long edge1Timestamp = ((BlueprintsEdge)edge1).getBlueprintsEdge().getProperty(SpecialProperty.DELETED);
        Long edge2Timestamp = ((BlueprintsEdge)edge2).getBlueprintsEdge().getProperty(SpecialProperty.DELETED);

        assertThat(edge2Timestamp).isNotEqualTo(edge1Timestamp);
        assertThat(edge1Timestamp).isEqualTo(edge1OriginalTimestamp);

    }

    /**
     * getNodes
     */
    @Test
    public void getNodes_shouldReturn0Nodes() {
        Iterator<Node> nodes = graph.getNodes().iterator();
        assertThat(nodes.hasNext()).isEqualTo(false);
    }

    @Test
    public void getNodes_shouldReturn3Nodes() {
        graph.addNode("label");
        graph.addNode("label");
        graph.addNode("label");
        int i = 0;
        for(Node n: graph.getNodes()) {
            i++;
            assertThat(n.getLabel()).isEqualTo("label");
        }
        assertThat(i).isEqualTo(3);
    }

    @Test
    public void getNodes_shouldNotReturnDeletedNodes() {
        graph.removeNode(graph.addNode("label").getId());
        Iterator<Node> nodes = graph.getNodes().iterator();
        assertThat(nodes.hasNext()).isEqualTo(false);
    }

    /**
     * getNodes_key_value
     */
    @Test
    public void getNodes_key_value_shouldErrorOnBadKey() {
        try {
            graph.getNodes("__deleted", true);
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("Invalid Regular Key");
        }
    }

    @Test
    public void getNodes_key_value_shouldErrorOnBadValue() {
        try {
            graph.getNodes("property", new Object());
            fail("Should have thrown exception");
        } catch(VGraphException e) {
            assertThat(e).hasMessage("Invalid Regular Value");
        }
    }

    @Test
    public void getNodes_key_value_shouldReturn1Node() {
        Node n;
        n = graph.addNode("label");
        n.setProperty("prop", true);
        n = graph.addNode("label");
        n.setProperty("prop", false);

        int i = 0;
        for(Node node: graph.getNodes("prop",true)) {
            i++;
            assertThat(node.getLabel()).isEqualTo("label");
        }
        assertThat(i).isEqualTo(1);
    }

    @Test
    public void getNodes_key_value_shouldNotReturnDeletedNodes() {
        Node node = graph.addNode("label");
        node.setProperty("prop", true);
        graph.removeNode(node.getId());

        Iterator<Node> nodes = graph.getNodes("prop",true).iterator();
        assertThat(nodes.hasNext()).isEqualTo(false);
    }
}

package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Action;
import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.CommitEdge;
import com.github.trepo.vgraph.CommitNode;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraphException;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BlueprintsVGraph_MergeTest {

    String sourceRepo = "source";
    TinkerGraph sourceTinkerGraph;
    BlueprintsVGraph sourceGraph;

    String destinationRepo = "destination";
    TinkerGraph destinationTinkerGraph;
    BlueprintsVGraph destinationGraph;

    @BeforeMethod
    public void beforeTest() {
        sourceTinkerGraph = new TinkerGraph();
        sourceGraph = new BlueprintsVGraph(sourceTinkerGraph, sourceRepo);

        destinationTinkerGraph = new TinkerGraph();
        destinationGraph = new BlueprintsVGraph(destinationTinkerGraph, destinationRepo);
    }

    /**
     * merge
     */
    @Test
    public void merge_shouldFailOnInvalidCommit() {
        try {
            destinationGraph.merge(new Commit(), "author", "email", "message");
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("version is null");
        }
    }

    @Test
    public void merge_shouldFailOnDirtyGraph() {
        sourceGraph.addNode("label");
        Commit commit = sourceGraph.commit("author", "email", "message");

        destinationGraph.addNode("label");

        try {
            destinationGraph.merge(commit, "author", "email", "message");
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("cannot merge with a dirty graph");
        }
    }

    @Test
    public void merge_shouldCreateProperCommit() {
        sourceGraph.addNode("label");
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        destinationGraph.addNode("label");
        Commit destinationCommit = destinationGraph.commit("destination-author", "destination-email", "destination-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();

        assertThat(commit.getId()).isNotEqualTo(sourceCommit.getId());
        assertThat(commit.getPrev()).isEqualTo(destinationCommit.getId());
        assertThat(commit.getAuthor()).isEqualTo("author");
        assertThat(commit.getEmail()).isEqualTo("email");
        assertThat(commit.getMessage()).isEqualTo("message");
    }

    @Test
    public void merge_shouldSkipAlreadyDeletedNodes() {
        Node node = sourceGraph.addNode("label");
        sourceGraph.commit("source-author", "source-email", "source-message");
        sourceGraph.removeNode(node.getId());
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();

        assertThat(commit.getNodes().isEmpty()).isTrue();
        assertThat(commit.getEdges().isEmpty()).isTrue();
    }

    @Test
    public void merge_shouldThrowErrorOnDeletingNodesWithRemainingEdges() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        sourceGraph.addEdge(node1, node2, "label");
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        destinationGraph.patch(sourceCommit);
        Edge edge = destinationGraph.addEdge(destinationGraph.getNode(node2.getId()), destinationGraph.getNode(node1.getId()), "label");
        destinationGraph.commit("destination-author", "destination-email", "destination-message");

        sourceGraph.removeNode(node1.getId());
        sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        try {
            destinationGraph.merge(sourceCommit, "author", "email", "message");
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("Merge Conflict: edge "+edge.getId()+" is present when trying to delete node "+node1.getId());
        }

    }

    @Test
    public void merge_shouldWorkWhenDeletingNodesAndAllEdges() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        Edge edge1 = sourceGraph.addEdge(node1, node2, "label");
        Edge edge2 = sourceGraph.addEdge(node2, node1, "label");
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        destinationGraph.patch(sourceCommit);

        sourceGraph.removeNode(node1.getId());
        sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();

        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);
        for (CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node1.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.DELETE);
        }

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(2);
        for (CommitEdge commitEdge: edges) {
            assertThat(commitEdge.getId()).isIn(edge1.getId(), edge2.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.DELETE);
        }
    }

    @Test
    public void merge_shouldDeleteBoundaryNodes() {
        Node node = destinationGraph.addNode("label");
        destinationGraph.commit("destination-author", "destination-email", "destination-message");

        HashSet<CommitNode> localNodes = new HashSet<>();
        localNodes.add(new CommitNode()
                .setId(node.getId())
                .setLabel("label")
                .setAction(Action.DELETE)
                .setBoundary(true)
                .setRepo("source-repo")
        );

        Commit sourceCommit = new Commit()
                .setVersion(1)
                .setId(SpecialProperty.generateId())
                .setPrev(SpecialProperty.generateId())
                .setRepo("repo")
                .setTimestamp(SpecialProperty.generateTimestamp())
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(localNodes)
                .setEdges(new HashSet<CommitEdge>());

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();

        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);
        for (CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.DELETE);
            assertThat(commitNode.isBoundary()).isTrue();
        }
    }

    @Test
    public void merge_shouldDeleteNodes() {
        Node node = sourceGraph.addNode("label");
        node.setProperty("foo", "bar");
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        destinationGraph.patch(sourceCommit);

        node.removeProperty("foo");
        node.setProperty("testing", true);
        sourceGraph.commit("source-author", "source-email", "source-message");

        sourceGraph.removeNode(node.getId());
        sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        assertThat(sourceCommit.getNodes().size()).isEqualTo(1);
        for (CommitNode commitNode: sourceCommit.getNodes()) {
            assertThat(commitNode.getOriginal().size()).isEqualTo(1);
            assertThat(commitNode.getOriginal().get("testing")).isEqualTo(true);
        }

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();

        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);
        for (CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.DELETE);
            assertThat(commitNode.getOriginal().size()).isEqualTo(1);
            assertThat(commitNode.getOriginal().get("foo")).isEqualTo("bar");
        }

        assertThat(commit.getEdges().size()).isEqualTo(0);
    }

    @Test
    public void merge_shouldCreateUpdatedNodeWhenMissing() {
        Node node = sourceGraph.addNode("label");
        sourceGraph.commit("source-author", "source-email", "source-message");
        node.setProperty("foo", "bar");
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();

        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);
        for (CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitNode.getProperties().size()).isEqualTo(1);
            assertThat(commitNode.getProperties().get("foo")).isEqualTo("bar");
        }

        assertThat(commit.getEdges().size()).isEqualTo(0);
    }

    @Test
    public void merge_shouldUpdateUpdatedNodeWhenPresent() {
        Node node = sourceGraph.addNode("label");
        node.setProperty("foo", "bar");
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        destinationGraph.patch(sourceCommit);

        node.setProperty("foo", "not-bar");
        sourceGraph.commit("source-author", "source-email", "source-message");

        node.removeProperty("foo");
        node.setProperty("testing", true);
        sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();

        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);
        for (CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.UPDATE);
            assertThat(commitNode.getOriginal().size()).isEqualTo(1);
            assertThat(commitNode.getOriginal().get("foo")).isEqualTo("bar");
            assertThat(commitNode.getProperties().size()).isEqualTo(1);
            assertThat(commitNode.getProperties().get("testing")).isEqualTo(true);
        }

        assertThat(commit.getEdges().size()).isEqualTo(0);
    }

    @Test
    public void merge_shouldCreateMissingBoundaryNode() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        sourceGraph.commit("source-author", "source-email", "source-message");

        sourceGraph.addEdge(node1, node2, "label");
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();

        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(2);
        for (CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isIn(node1.getId(), node2.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitNode.isBoundary()).isTrue();
        }

        assertThat(commit.getEdges().size()).isEqualTo(1);
    }

    @Test
    public void merge_shouldAddCreatingBoundaryNodeThatExists() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        destinationGraph.patch(sourceCommit);

        sourceGraph.addEdge(node1, node2, "label");
        sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();

        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(2);
        for (CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isIn(node1.getId(), node2.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitNode.isBoundary()).isTrue();
        }

        assertThat(commit.getEdges().size()).isEqualTo(1);
    }

    @Test
    public void merge_shouldUpdateCreatedNodeWhenPresent() {
        Node node = destinationGraph.addNode("label");
        node.setProperty("foo", "bar");
        destinationGraph.commit("destination-author", "destination-email", "destination-message");

        HashMap<String, Object> original = new HashMap<>();
        original.put("foo", "bar");

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", true);

        HashSet<CommitNode> localNodes = new HashSet<>();
        localNodes.add(new CommitNode()
                .setId(node.getId())
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(false)
                .setProperties(properties)
                .setHash(SpecialProperty.calculateHash(properties))
        );

        Commit sourceCommit = new Commit()
                .setVersion(1)
                .setId(SpecialProperty.generateId())
                .setPrev(SpecialProperty.generateId())
                .setRepo("repo")
                .setTimestamp(SpecialProperty.generateTimestamp())
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(localNodes)
                .setEdges(new HashSet<CommitEdge>());

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();

        Set<CommitNode> nodes = commit.getNodes();
        assertThat(nodes.size()).isEqualTo(1);
        for (CommitNode commitNode: nodes) {
            assertThat(commitNode.getId()).isEqualTo(node.getId());
            assertThat(commitNode.getAction()).isEqualTo(Action.UPDATE);
            assertThat(commitNode.isBoundary()).isFalse();
            assertThat(commitNode.getOriginal()).isEqualTo(original);
            assertThat(commitNode.getProperties()).isEqualTo(properties);
        }

        assertThat(commit.getEdges().size()).isEqualTo(0);
    }

    @Test
    public void merge_shouldSkipDeletedEdgeWhenMissing() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        Edge edge = sourceGraph.addEdge(node1, node2, "label");
        sourceGraph.commit("source-author", "source-email", "source-message");

        sourceGraph.removeEdge(edge.getId());
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();

        assertThat(commit.getNodes().size()).isEqualTo(0);

        assertThat(commit.getEdges().size()).isEqualTo(0);
    }

    @Test
    public void merge_shouldDeleteEdgeWhenPresent() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        Edge edge = sourceGraph.addEdge(node1, node2, "label");
        edge.setProperty("foo", "bar");
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        destinationGraph.patch(sourceCommit);

        Edge destinationEdge = destinationGraph.getEdge(edge.getId());
        destinationEdge.removeProperty("foo");
        destinationEdge.setProperty("testing", true);
        destinationGraph.commit("destination-author", "destination-email", "destination-message");

        sourceGraph.removeEdge(edge.getId());
        sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();
        assertThat(commit.getNodes().size()).isEqualTo(0);

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(1);
        for (CommitEdge commitEdge: edges) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.DELETE);
            assertThat(commitEdge.getOriginal().size()).isEqualTo(1);
            assertThat(commitEdge.getOriginal().get("testing")).isEqualTo(true);
        }
    }

    @Test
    public void merge_shouldCreateUpdatedEdgeWhenMissing() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        Edge edge = sourceGraph.addEdge(node1, node2, "label");
        edge.setProperty("foo", "bar");
        sourceGraph.commit("source-author", "source-email", "source-message");

        edge.removeProperty("foo");
        edge.setProperty("testing", true);
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();
        assertThat(commit.getNodes().size()).isEqualTo(2);

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(1);
        for (CommitEdge commitEdge: edges) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitEdge.getProperties().size()).isEqualTo(1);
            assertThat(commitEdge.getProperties().get("testing")).isEqualTo(true);
        }
    }

    @Test
    public void merge_shouldUpdateUpdatedEdgeWhenPresent() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        Edge edge = sourceGraph.addEdge(node1, node2, "label");
        edge.setProperty("foo", "bar");
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        destinationGraph.patch(sourceCommit);

        Edge destinationEdge = destinationGraph.getEdge(edge.getId());
        destinationEdge.removeProperty("foo");
        destinationEdge.setProperty("testing", true);
        destinationGraph.commit("destination-author", "destination-email", "destination-message");

        edge.removeProperty("foo");
        edge.setProperty("third", 4);
        sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();
        assertThat(commit.getNodes().size()).isEqualTo(2);

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(1);
        for (CommitEdge commitEdge: edges) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.UPDATE);
            assertThat(commitEdge.getOriginal().size()).isEqualTo(1);
            assertThat(commitEdge.getOriginal().get("testing")).isEqualTo(true);
            assertThat(commitEdge.getProperties().size()).isEqualTo(1);
            assertThat(commitEdge.getProperties().get("third")).isEqualTo(4);
        }

    }

    @Test
    public void merge_shouldCreateCreatedEdgeWhenMissing() {
        Node node1 = sourceGraph.addNode("label");
        Node node2 = sourceGraph.addNode("label");
        Edge edge = sourceGraph.addEdge(node1, node2, "label");
        edge.setProperty("foo", "bar");
        Commit sourceCommit = sourceGraph.commit("source-author", "source-email", "source-message");

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();
        assertThat(commit.getNodes().size()).isEqualTo(2);

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(1);
        for (CommitEdge commitEdge: edges) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.CREATE);
            assertThat(commitEdge.getProperties().size()).isEqualTo(1);
            assertThat(commitEdge.getProperties().get("foo")).isEqualTo("bar");
        }
    }

    @Test
    public void merge_shouldUpdateCreatedEdgeWhenPresent() {
        Node node1 = destinationGraph.addNode("label");
        Node node2 = destinationGraph.addNode("label");
        Edge edge = destinationGraph.addEdge(node1, node2, "label");
        edge.setProperty("foo", "bar");
        destinationGraph.commit("destination-author", "destination-email", "destination-message");

        HashSet<CommitNode> localNodes = new HashSet<>();
        localNodes.add(new CommitNode()
                .setId(node1.getId())
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(true)
                .setRepo("source-repo")
        );
        localNodes.add(new CommitNode()
                .setId(node2.getId())
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(true)
                .setRepo("source-repo")
        );

        HashMap<String, Object> properties = new HashMap<>();
        properties.put("testing", true);

        HashSet<CommitEdge> localEdges = new HashSet<>();
        localEdges.add(new CommitEdge()
                .setId(edge.getId())
                .setLabel("label")
                .setFrom(node1.getId())
                .setTo(node2.getId())
                .setAction(Action.CREATE)
                .setProperties(properties)
                .setHash(SpecialProperty.calculateHash(properties))
        );

        Commit sourceCommit = new Commit()
                .setVersion(1)
                .setId(SpecialProperty.generateId())
                .setPrev(SpecialProperty.generateId())
                .setRepo("repo")
                .setTimestamp(SpecialProperty.generateTimestamp())
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(localNodes)
                .setEdges(localEdges);

        Commit commit = destinationGraph.merge(sourceCommit, "author", "email", "message");

        commit.validate();
        assertThat(commit.getNodes().size()).isEqualTo(2);

        Set<CommitEdge> edges = commit.getEdges();
        assertThat(edges.size()).isEqualTo(1);
        for (CommitEdge commitEdge: edges) {
            assertThat(commitEdge.getId()).isEqualTo(edge.getId());
            assertThat(commitEdge.getAction()).isEqualTo(Action.UPDATE);
            assertThat(commitEdge.getOriginal().size()).isEqualTo(1);
            assertThat(commitEdge.getOriginal().get("foo")).isEqualTo("bar");
            assertThat(commitEdge.getProperties().size()).isEqualTo(1);
            assertThat(commitEdge.getProperties().get("testing")).isEqualTo(true);
        }
    }
}

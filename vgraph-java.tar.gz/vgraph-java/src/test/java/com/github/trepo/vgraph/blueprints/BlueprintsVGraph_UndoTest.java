package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Action;
import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.CommitEdge;
import com.github.trepo.vgraph.CommitNode;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.MetaProperty;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraphException;
import com.github.trepo.vgraph.blueprints.util.CommitNodeIterable;
import com.tinkerpop.blueprints.Direction;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.HashSet;
import java.util.List;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BlueprintsVGraph_UndoTest {

    String repo = "repo";
    TinkerGraph tinkerGraph;
    BlueprintsVGraph graph;

    @BeforeMethod
    public void beforeTest() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
    }

    /**
     * undo
     */
    @Test
    public void undo_shouldFailOnInvalidId() {
        graph.addNode("label");

        try {
            graph.undo(null);
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("invalid commit id");
        }

        try {
            graph.undo("1234");
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("invalid commit id");
        }
    }

    @Test
    public void undo_shouldFailOnDirtyGraph() {
        graph.addNode("label");

        try {
            graph.undo(SpecialProperty.generateId());
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("cannot undo a dirty graph");
        }
    }

    @Test
    public void undo_shouldFailOnMissingCommitNode() {
        try {
            graph.undo(SpecialProperty.generateId());
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("commit does not exist");
        }

        graph.addNode("label");
        graph.commit("author", "email", "message");
        graph.addNode("label");
        graph.commit("author", "email", "message");
        graph.addNode("label");
        graph.commit("author", "email", "message");

        try {
            graph.undo(SpecialProperty.generateId());
            fail("Should have thrown an error");
        } catch(VGraphException e) {
            assertThat(e.getMessage()).isEqualTo("commit does not exist");
        }
    }

    @Test
    public void undo_shouldUndoDeleteNode() {
        Node node = graph.addNode("label");
        node.setProperty("foo", "bar");
        String id = node.getId();
        Commit originalCommit = graph.commit("author", "email", "message");
        graph.removeNode(id);
        Commit commit = graph.commit("author", "email", "message");

        assertThat(graph.getNode(id)).isNull();

        List<String> commitIds = graph.undo(originalCommit.getId());

        assertThat(commitIds.size()).isEqualTo(1);
        assertThat(commitIds.get(0)).isEqualTo(commit.getId());

        node = graph.getNode(id);
        assertThat(node).isNotNull();
        assertThat(node.getPropertyKeys().size()).isEqualTo(1);
        assertThat(node.getProperty("foo")).isEqualTo("bar");

        assertThat(graph.info().getCommit()).isEqualTo(originalCommit.getId());
    }

    @Test
    public void undo_shouldUndoDeleteBoundary() {
        String id = SpecialProperty.generateId();
        CommitNode createNode = new CommitNode()
                .setId(id)
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(true)
                .setRepo("external-repo");

        HashSet<CommitNode> createNodes = new HashSet<>();
        createNodes.add(createNode);

        Commit originalCommit = new Commit().setVersion(1)
                .setId(SpecialProperty.generateId())
                .setPrev(null)
                .setRepo("repo")
                .setTimestamp(SpecialProperty.generateTimestamp())
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(createNodes)
                .setEdges(new HashSet<CommitEdge>());
        originalCommit.validate();
        graph.patch(originalCommit);

        CommitNode deleteNode = new CommitNode()
                .setId(id)
                .setLabel("label")
                .setAction(Action.DELETE)
                .setBoundary(true)
                .setRepo("external-repo");

        HashSet<CommitNode> deleteNodes = new HashSet<>();
        deleteNodes.add(deleteNode);

        Commit commit = new Commit().setVersion(1)
                .setId(SpecialProperty.generateId())
                .setPrev(originalCommit.getId())
                .setRepo("repo")
                .setTimestamp(SpecialProperty.generateTimestamp())
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(deleteNodes)
                .setEdges(new HashSet<CommitEdge>());
        commit.validate();
        graph.patch(commit);

        assertThat(graph.getNode(id)).isNull();

        List<String> commitIds = graph.undo(originalCommit.getId());

        assertThat(commitIds.size()).isEqualTo(1);
        assertThat(commitIds.get(0)).isEqualTo(commit.getId());

        assertThat(graph.getNode(id).isBoundary()).isTrue();
        assertThat(graph.getNode(id).getRepo()).isEqualTo("external-repo");

        assertThat(graph.info().getCommit()).isEqualTo(originalCommit.getId());
    }

    @Test
    public void undo_shouldUndoDeleteEdge() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "label");
        edge.setProperty("foo", "bar");
        String id = edge.getId();
        Commit originalCommit = graph.commit("author", "email", "message");
        graph.removeEdge(id);
        Commit commit = graph.commit("author", "email", "message");

        assertThat(graph.getEdge(id)).isNull();

        List<String> commitIds = graph.undo(originalCommit.getId());

        assertThat(commitIds.size()).isEqualTo(1);
        assertThat(commitIds.get(0)).isEqualTo(commit.getId());

        edge = graph.getEdge(id);
        assertThat(edge).isNotNull();
        assertThat(edge.getPropertyKeys().size()).isEqualTo(1);
        assertThat(edge.getProperty("foo")).isEqualTo("bar");

        assertThat(graph.info().getCommit()).isEqualTo(originalCommit.getId());
    }

    @Test
    public void undo_shouldUndoUpdateEdge() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "label");
        edge.setProperty("foo", "bar");
        String id = edge.getId();
        Commit originalCommit = graph.commit("author", "email", "message");
        edge.removeProperty("foo");
        edge.setProperty("testing", true);
        Commit commit = graph.commit("author", "email", "message");

        assertThat(graph.getEdge(id).getPropertyKeys().size()).isEqualTo(1);
        assertThat(graph.getEdge(id).getProperty("testing")).isEqualTo(true);

        List<String> commitIds = graph.undo(originalCommit.getId());

        assertThat(commitIds.size()).isEqualTo(1);
        assertThat(commitIds.get(0)).isEqualTo(commit.getId());

        edge = graph.getEdge(id);
        assertThat(edge).isNotNull();
        assertThat(edge.getPropertyKeys().size()).isEqualTo(1);
        assertThat(edge.getProperty("foo")).isEqualTo("bar");

        assertThat(graph.info().getCommit()).isEqualTo(originalCommit.getId());
    }

    @Test
    public void undo_shouldUndoCreateEdge() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Commit originalCommit = graph.commit("author", "email", "message");
        Edge edge = graph.addEdge(node1, node2, "label");
        edge.setProperty("foo", "bar");
        String id = edge.getId();
        Commit commit = graph.commit("author", "email", "message");

        assertThat(graph.getEdge(id)).isNotNull();

        List<String> commitIds = graph.undo(originalCommit.getId());

        assertThat(commitIds.size()).isEqualTo(1);
        assertThat(commitIds.get(0)).isEqualTo(commit.getId());

        assertThat(graph.getEdge(id)).isNull();

        assertThat(graph.info().getCommit()).isEqualTo(originalCommit.getId());
    }

    @Test
    public void undo_shouldUndoUpdateNode() {
        Node node = graph.addNode("label");
        node.setProperty("foo", "bar");
        String id = node.getId();
        Commit originalCommit = graph.commit("author", "email", "message");
        node.removeProperty("foo");
        node.setProperty("testing", true);
        Commit commit = graph.commit("author", "email", "message");

        assertThat(graph.getNode(id).getPropertyKeys().size()).isEqualTo(1);
        assertThat(graph.getNode(id).getProperty("testing")).isEqualTo(true);

        List<String> commitIds = graph.undo(originalCommit.getId());

        assertThat(commitIds.size()).isEqualTo(1);
        assertThat(commitIds.get(0)).isEqualTo(commit.getId());

        node = graph.getNode(id);
        assertThat(node).isNotNull();
        assertThat(node.getPropertyKeys().size()).isEqualTo(1);
        assertThat(node.getProperty("foo")).isEqualTo("bar");

        assertThat(graph.info().getCommit()).isEqualTo(originalCommit.getId());
    }

    @Test
    public void undo_shouldUndoCreateNode() {
        graph.addNode("label");
        Commit originalCommit = graph.commit("author", "email", "message");
        Node node = graph.addNode("label");
        node.setProperty("foo", "bar");
        String id = node.getId();
        Commit commit = graph.commit("author", "email", "message");

        assertThat(graph.getNode(id).getPropertyKeys().size()).isEqualTo(1);
        assertThat(graph.getNode(id).getProperty("foo")).isEqualTo("bar");

        List<String> commitIds = graph.undo(originalCommit.getId());

        assertThat(commitIds.size()).isEqualTo(1);
        assertThat(commitIds.get(0)).isEqualTo(commit.getId());

        assertThat(graph.getNode(id)).isNull();

        assertThat(graph.info().getCommit()).isEqualTo(originalCommit.getId());
    }

    @Test
    public void undo_shouldUndoCreateBoundary() {
        graph.addNode("label");
        Commit originalCommit = graph.commit("author", "email", "message");

        String id = SpecialProperty.generateId();
        CommitNode commitNode = new CommitNode()
                .setId(id)
                .setLabel("label")
                .setAction(Action.CREATE)
                .setBoundary(true)
                .setRepo("external-repo");

        HashSet<CommitNode> commitNodes = new HashSet<>();
        commitNodes.add(commitNode);

        Commit commit = new Commit().setVersion(1)
                .setId(SpecialProperty.generateId())
                .setPrev(originalCommit.getId())
                .setRepo("repo")
                .setTimestamp(SpecialProperty.generateTimestamp())
                .setAuthor("author")
                .setEmail("email")
                .setMessage("message")
                .setNodes(commitNodes)
                .setEdges(new HashSet<CommitEdge>());
        commit.validate();
        graph.patch(commit);

        assertThat(graph.getNode(id).isBoundary()).isTrue();
        assertThat(graph.getNode(id).getRepo()).isEqualTo("external-repo");

        List<String> commitIds = graph.undo(originalCommit.getId());

        assertThat(commitIds.size()).isEqualTo(1);
        assertThat(commitIds.get(0)).isEqualTo(commit.getId());

        assertThat(graph.getNode(id)).isNull();

        assertThat(graph.info().getCommit()).isEqualTo(originalCommit.getId());
    }

    @Test
    public void undo_shouldReturnProperListOfCommitIDs() {
        graph.addNode("label");
        Commit commit1 = graph.commit("author", "email", "message");
        graph.addNode("label");
        Commit commit2 = graph.commit("author", "email", "message");
        graph.addNode("label");
        Commit commit3 = graph.commit("author", "email", "message");
        graph.addNode("label");
        Commit commit4 = graph.commit("author", "email", "message");
        graph.addNode("label");
        Commit commit5 = graph.commit("author", "email", "message");

        List<String> commitIds = graph.undo(commit1.getId());

        assertThat(commitIds.size()).isEqualTo(4);
        assertThat(commitIds.get(0)).isEqualTo(commit5.getId());
        assertThat(commitIds.get(1)).isEqualTo(commit4.getId());
        assertThat(commitIds.get(2)).isEqualTo(commit3.getId());
        assertThat(commitIds.get(3)).isEqualTo(commit2.getId());
    }

    @Test
    public void undo_shouldCleanUpCommitNodesAndEdgesCorrectly() {
        graph.addNode("label");
        Commit commit1 = graph.commit("author", "email", "message");
        graph.addNode("label");
        Commit commit2 = graph.commit("author", "email", "message");
        graph.addNode("label");
        graph.commit("author", "email", "message");
        graph.addNode("label");
        graph.commit("author", "email", "message");
        graph.addNode("label");
        graph.commit("author", "email", "message");

        // Undo 3 commits
        graph.undo(commit2.getId());

        int num = 0;
        for (Vertex v: new CommitNodeIterable(tinkerGraph.getVertex(MetaProperty.ROOT), Direction.OUT)) {

            switch (num) {
                case 0:
                    assertThat(v.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit1.getId());
                    break;
                case 1:
                    assertThat(v.getProperty(MetaProperty.COMMIT_ID)).isEqualTo(commit2.getId());
                    break;
                default:
                    fail("invalid commit node");
            }

            num++;
        }
    }
}

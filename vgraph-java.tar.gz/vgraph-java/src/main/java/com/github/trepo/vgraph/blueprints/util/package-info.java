/**
 * Utility classes for vGraph.
 * @author John Clark.
 */
package com.github.trepo.vgraph.blueprints.util;

package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Boundary;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraphException;
import com.tinkerpop.blueprints.Vertex;

/**
 * @author John Clark.
 */
public class BlueprintsBoundary extends BlueprintsNode implements Boundary {

    /**
     * Make sure to call our parent, the regular old node.
     * @param v The blueprint's vertex to wrap.
     * @param g The vGraph instance.
     */
    public BlueprintsBoundary(Vertex v, BlueprintsVGraph g) {
        super(v, g);
    }

    /**
     * Returns True as this Node is a Boundary Node.
     * @return True.
     */
    @Override
    public boolean isBoundary() {
        return true;
    }

    /**
     * {@inheritDoc}
     */
    public String getRepo() {
        return vertex.getProperty(SpecialProperty.REPO);
    }

    /**
     * Overridden to disallow modifying a boundary node.
     * This will always throw a VGraphException.
     * @param key The key.
     * @param value The value.
     */
    @Override
    public void setProperty(String key, Object value) {
        throw new VGraphException("You may not edit a Boundary Node");
    }

    /**
     * Overridden to disallow modifying a boundary node.
     * This will always throw a VGraphException.
     * @param key The key.
     */
    @Override
    public void removeProperty(String key) {
        throw new VGraphException("You may not edit a Boundary Node");
    }

}

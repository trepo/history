package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.Property;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.blueprints.util.NodeFromEdgeIterable;
import com.tinkerpop.blueprints.Vertex;
import com.github.trepo.vgraph.VGraphException;
import com.github.trepo.vgraph.blueprints.util.EdgeIterable;
import com.github.trepo.vgraph.blueprints.util.Util;

import java.util.HashSet;
import java.util.Set;

/**
 * An Element representing a vertex in the graph.
 * @author John Clark
 */
public class BlueprintsNode extends BlueprintsElement implements Node {

    /**
     * The wrapped blueprint vertex.
     */
    protected Vertex vertex;

    /**
     * Our vGraph instance.
     */
    private BlueprintsVGraph graph;

    /**
     * Create a vGraph Edge that wraps a Blueprints Vertex.
     * @param v The Blueprints Vertex to wrap.
     * @param g The vGraph instance.
     */
    public BlueprintsNode(Vertex v, BlueprintsVGraph g) {
        this.vertex = v;
        this.graph = g;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getId() {
        return vertex.getProperty(SpecialProperty.ID);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getLabel() {
        return vertex.getProperty(SpecialProperty.LABEL);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getHash() {
        return vertex.getProperty(SpecialProperty.HASH);
    }


    /**
     * {@inheritDoc}
     */
    @Override
    public Set<String> getPropertyKeys() {
        Set<String> keys = new HashSet<>();
        for (String key:vertex.getPropertyKeys()) {
            if (Property.isValidKey(key)) {
                keys.add(key);
            }
        }
        return keys;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object getProperty(String key) {
        if (!Property.isValidKey(key)) {
            throw new VGraphException("Invalid Regular Key");
        }
        return vertex.getProperty(key);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setProperty(String key, Object value) {
        if (!Property.isValidKey(key)) {
            throw new VGraphException("Invalid Regular Key");
        }
        if (!Property.isValidValue(value)) {
            throw new VGraphException("Invalid Regular Value");
        }

        if (graph.acquireLock()) {
            try {
                if (vertex.getProperty(SpecialProperty.DELETED) != null) {
                    throw new VGraphException("Node deleted");
                }
                graph.setDirty();
                if (vertex.getProperty(SpecialProperty.HASH) != null) {
                    vertex.setProperty(SpecialProperty.ORIGINAL, Util.serializeProperties(Util.getProperties(vertex)));
                }
                vertex.removeProperty(SpecialProperty.HASH);
                vertex.setProperty(key, value);
            } finally {
                graph.unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void removeProperty(String key) {
        if (!Property.isValidKey(key)) {
            throw new VGraphException("Invalid Regular Key");
        }

        if (graph.acquireLock()) {
            try {
                if (vertex.getProperty(SpecialProperty.DELETED) != null) {
                    throw new VGraphException("Node deleted");
                }
                graph.setDirty();
                if (vertex.getProperty(SpecialProperty.HASH) != null) {
                    vertex.setProperty(SpecialProperty.ORIGINAL, Util.serializeProperties(Util.getProperties(vertex)));
                }
                vertex.removeProperty(SpecialProperty.HASH);
                vertex.removeProperty(key);
            } finally {
                graph.unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    /**
     * {@inheritDoc}
     */
    public String getRepo() {
        return graph.info().getRepo();
    }

    /**
     * Returns False as this Node is not a Boundary Node.
     * @return False.
     */
    public boolean isBoundary() {
        return false;
    }

    /**
     * {@inheritDoc}
     */
    public Edge addEdge(Node to, String label) {
        BlueprintsNode toNode = (BlueprintsNode) to;
        if (toNode == null) {
            throw new VGraphException("Invalid toNode");
        }
        if (!SpecialProperty.isValidLabel(label)) {
            throw new VGraphException("Invalid Label");
        }
        if (this.getId().equals(toNode.getId())) {
            throw new VGraphException("Self Referencing Edges are not allowed");
        }

        if (graph.acquireLock()) {
            try {
                if (vertex.getProperty(SpecialProperty.DELETED) != null) {
                    throw new VGraphException("Node deleted");
                }
                if (toNode.vertex.getProperty(SpecialProperty.DELETED) != null) {
                    throw new VGraphException("To node deleted");
                }
                graph.setDirty();
                String id = SpecialProperty.generateId();
                com.tinkerpop.blueprints.Edge e = vertex.addEdge(label, toNode.vertex);
                e.setProperty(SpecialProperty.ID, id);
                e.setProperty(SpecialProperty.LABEL, label);

                return new BlueprintsEdge(e, graph);
            } finally {
                graph.unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    /**
     * {@inheritDoc}
     */
    public Iterable<Edge> getEdges(Direction direction, String... labels) {
        return new EdgeIterable(vertex.getEdges(Util.blueprintsDirection(direction), labels), graph);
    }

    /**
     * {@inheritDoc}
     */
    public Iterable<Node> getNodes(Direction direction, String... labels) {
        return new NodeFromEdgeIterable(getEdges(direction, labels), this);
    }

    /**
     * Gets the underlying Blueprints Node.
     * @return The Blueprints Node.
     */
    public Vertex getBlueprintsNode() {
        return vertex;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        BlueprintsNode node = (BlueprintsNode) o;

        if (vertex != null ? !vertex.equals(node.vertex) : node.vertex != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        if (vertex != null) {
            return vertex.hashCode();
        } else {
            return 0;
        }
    }
}

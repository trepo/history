package com.github.trepo.vgraph.blueprints.util;

import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.blueprints.BlueprintsEdge;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * @author John Clark.
 */
public class EdgeIterable implements Iterable<Edge> {

    /**
     * Our vGraph instance.
     */
    private BlueprintsVGraph graph;

    /**
     * The internal Iterable.
     */
    private Iterable<com.tinkerpop.blueprints.Edge> itr;

    /**
     * Wrap a blueprints Edge Iterable.
     * @param iterable The Iterable we are wrapping.
     * @param g The vGraph instance.
     */
    public EdgeIterable(Iterable<com.tinkerpop.blueprints.Edge> iterable, BlueprintsVGraph g) {
        itr = iterable;
        graph = g;
    }

    @Override
    public Iterator<Edge> iterator() {
        return new EdgesFromNodeIterator();
    }

    /**
     * A private class that wraps our iterator.
     */
    private class EdgesFromNodeIterator implements Iterator<Edge> {

        /**
         * Our wrapped iterator.
         */
        private Iterator<com.tinkerpop.blueprints.Edge> iterator;

        /**
         * If we have another edge.
         */
        private Boolean hasNext = null;

        /**
         * The next edge.
         */
        private com.tinkerpop.blueprints.Edge nextEdge;

        /**
         * Create an iterator that pulls from the above Iterable.
         */
        public EdgesFromNodeIterator() {
            iterator = itr.iterator();
        }

        @Override
        public boolean hasNext() {

            if (hasNext == null) {
                setNext();
            }

            return hasNext;
        }

        /**
         * Figure out if we really do have another non-deleted node.
         */
        private void setNext() {
            while (iterator.hasNext()) {
                com.tinkerpop.blueprints.Edge tmp = iterator.next();
                // If node is not deleted
                if (tmp.getProperty(SpecialProperty.DELETED) == null) {
                    hasNext = true;
                    nextEdge = tmp;
                    return;
                }
            }
            hasNext = false;
        }

        @Override
        public Edge next() {
            if (!hasNext()) {
                throw new NoSuchElementException("No more elements");
            }

            hasNext = null;
            return new BlueprintsEdge(nextEdge, graph);
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Method not implemented");
        }
    }

}

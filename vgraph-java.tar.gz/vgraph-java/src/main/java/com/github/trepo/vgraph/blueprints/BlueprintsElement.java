package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Element;

import java.util.Set;

/**
 * An element in the Graph, being either a node or an edge.
 * @author John Clark
 */
public abstract class BlueprintsElement implements Element {

    /**
     * {@inheritDoc}
     */
    public abstract String getId();

    /**
     * {@inheritDoc}
     */
    public abstract String getLabel();

    /**
     * {@inheritDoc}
     */
    public abstract String getHash();

    /**
     * {@inheritDoc}
     */
    public abstract Set<String> getPropertyKeys();

    /**
     * {@inheritDoc}
     */
    public abstract Object getProperty(String key);

    /**
     * {@inheritDoc}
     */
    public abstract void setProperty(String key, Object value);

    /**
     * {@inheritDoc}
     */
    public abstract void removeProperty(String key);

}

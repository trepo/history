package com.github.trepo.vgraph.blueprints.util;

import com.github.trepo.vgraph.Action;
import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.CommitEdge;
import com.github.trepo.vgraph.CommitNode;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Element;
import com.github.trepo.vgraph.MetaProperty;
import com.github.trepo.vgraph.Property;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraphException;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.tinkerpop.blueprints.Edge;
import com.tinkerpop.blueprints.KeyIndexableGraph;
import com.tinkerpop.blueprints.Vertex;


import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * A General Utility Class.
 * @author John Clark
 */
public final class Util {

    /**
     * Our GSON instance to use for serialization.
     */
    private static final Gson GSON = new Gson();

    /**
     * Map of properties reflection type for GSON deserialization.
     */
    private static final Type PROPERTIES_TYPE = new TypeToken<HashMap<String, Object>>() { } .getType();

    /**
     * Set of CommitNodes reflection type for GSON deserialization.
     */
    private static final Type NODES_TYPE = new TypeToken<Set<CommitNode>>() { } .getType();

    /**
     * Set of CommitEdges reflection type for GSON deserialization.
     */
    private static final Type EDGES_TYPE = new TypeToken<Set<CommitEdge>>() { } .getType();

    /**
     * Private Constructor to prevent instantiation.
     */
    private Util() {
        // Never called.
    }

    /**
     * Translates a vGraph Direction into a Blueprints Direction.
     * @param direction The vGraph Direction to translate.
     * @return The resulting Blueprints Direction.
     */
    public static com.tinkerpop.blueprints.Direction blueprintsDirection(Direction direction) {
        switch(direction) {
            case IN: return com.tinkerpop.blueprints.Direction.IN;
            case OUT: return com.tinkerpop.blueprints.Direction.OUT;
            default: return com.tinkerpop.blueprints.Direction.BOTH;
        }
    }

    /**
     * Serialize a Map of properties into a JSON String.
     * @param properties The properties.
     * @return The JSON String.
     */
    public static String serializeProperties(Map<String, Object> properties) {
        return GSON.toJson(properties);
    }

    /**
     * Deserialize a json map of properties to a HashMap.
     * @param properties The properties json.
     * @return A HashMap.
     */
    public static Map<String, Object> deserializeProperties(String properties) {
        return GSON.fromJson(properties, PROPERTIES_TYPE);
    }

    /**
     * Gets the properties from an element.
     * @param element The element to get the properties from.
     * @return The properties.
     */
    public static Map<String, Object> getProperties(com.tinkerpop.blueprints.Element element) {
        TreeMap<String, Object> map = new TreeMap<>();
        for (String key:element.getPropertyKeys()) {
            if (Property.isValidKey(key)) {
                map.put(key, element.getProperty(key));
            }
        }
        return map;
    }

    /**
     * Gets the properties from an element.
     * @param element The element to get the properties from.
     * @return The properties.
     */
    public static Map<String, Object> getProperties(Element element) {
        TreeMap<String, Object> map = new TreeMap<>();
        for (String key:element.getPropertyKeys()) {
            if (Property.isValidKey(key)) {
                map.put(key, element.getProperty(key));
            }
        }
        return map;
    }

    /**
     * Calculate the SHA-1 hash of the ordered json output of an elements regular properties.
     * @param element The element whose properties will be used to calculate the hash.
     * @return The SHA-1 hash of the regular properties string.
     */
    public static String calculateHash(com.tinkerpop.blueprints.Element element) {
        return SpecialProperty.calculateHash(getProperties(element));
    }

    /**
     * Calculate the SHA-1 hash of the ordered json output of an elements regular properties.
     * @param element The element whose properties will be used to calculate the hash.
     * @return The SHA-1 hash of the regular properties string.
     */
    public static String calculateHash(Element element) {
        return SpecialProperty.calculateHash(getProperties(element));
    }

    /**
     * Given a raw Commit Node, populate it from the Commit.
     * @param commit The Commit.
     * @param graph The Commit Node.
     * @return The newly created Commit Node.
     */
    public static Vertex commitNodeFromCommit(Commit commit, KeyIndexableGraph graph) {

        Vertex commitNode = graph.addVertex(commit.getId());

        commitNode.setProperty(MetaProperty.KEY, MetaProperty.COMMIT_NODE);
        commitNode.setProperty(MetaProperty.COMMIT_ID, commit.getId());
        commitNode.setProperty(MetaProperty.COMMIT_REPO, commit.getRepo());
        commitNode.setProperty(MetaProperty.COMMIT_TIMESTAMP, commit.getTimestamp());
        commitNode.setProperty(MetaProperty.COMMIT_AUTHOR, commit.getAuthor());
        commitNode.setProperty(MetaProperty.COMMIT_EMAIL, commit.getEmail());
        commitNode.setProperty(MetaProperty.COMMIT_MESSAGE, commit.getMessage());
        commitNode.setProperty(MetaProperty.COMMIT_NODES, GSON.toJson(commit.getNodes()));
        commitNode.setProperty(MetaProperty.COMMIT_EDGES, GSON.toJson(commit.getEdges()));

        return commitNode;
    }

    /**
     * Create a Commit from a Commit Node.
     * @param commitNode The Commit Node.
     * @return A Commit.
     */
    public static Commit commitFromCommitNode(Vertex commitNode) {
        return new Commit()
                .setVersion(1)
                .setId(commitNode.<String>getProperty(MetaProperty.COMMIT_ID))
                .setRepo(commitNode.<String>getProperty(MetaProperty.COMMIT_REPO))
                .setTimestamp(commitNode.<Long>getProperty(MetaProperty.COMMIT_TIMESTAMP))
                .setAuthor(commitNode.<String>getProperty(MetaProperty.COMMIT_AUTHOR))
                .setEmail(commitNode.<String>getProperty(MetaProperty.COMMIT_EMAIL))
                .setMessage(commitNode.<String>getProperty(MetaProperty.COMMIT_MESSAGE))
                .setNodes(GSON.<Set<CommitNode>>fromJson(
                        commitNode.<String>getProperty(MetaProperty.COMMIT_NODES), NODES_TYPE))
                .setEdges(GSON.<Set<CommitEdge>>fromJson(
                        commitNode.<String>getProperty(MetaProperty.COMMIT_EDGES), EDGES_TYPE));
    }

    /**
     * Create a CommitNode from the raw Blueprints Node.
     * @param v The blueprints Node.
     * @param action The Action.
     * @param repo If not null, CommitNode will be a boundary with repo.
     * @return The CommitNode.
     */
    public static CommitNode createCommitNode(Vertex v, String action, String repo) {
        Map<String, Object> properties;

        switch(action) {
            case Action.CREATE:
                if (repo == null) {
                    properties = getProperties(v);
                    return new CommitNode()
                            .setId(v.<String>getProperty(SpecialProperty.ID))
                            .setLabel(v.<String>getProperty(SpecialProperty.LABEL))
                            .setAction(Action.CREATE)
                            .setBoundary(false)
                            .setProperties(properties)
                            .setHash(SpecialProperty.calculateHash(properties));
                } else {
                    return new CommitNode()
                            .setId(v.<String>getProperty(SpecialProperty.ID))
                            .setLabel(v.<String>getProperty(SpecialProperty.LABEL))
                            .setAction(Action.CREATE)
                            .setBoundary(true)
                            .setRepo(repo);
                }
            case Action.UPDATE:
                if (repo == null) {
                    properties = getProperties(v);
                    return new CommitNode()
                            .setId(v.<String>getProperty(SpecialProperty.ID))
                            .setLabel(v.<String>getProperty(SpecialProperty.LABEL))
                            .setAction(Action.UPDATE)
                            .setBoundary(false)
                            .setOriginal(deserializeProperties(
                                    v.<String>getProperty(SpecialProperty.ORIGINAL)))
                            .setProperties(properties)
                            .setHash(SpecialProperty.calculateHash(properties));
                } else {
                    throw new VGraphException("You cannot update a boundary node");
                }
            case Action.DELETE:
                if (repo == null) {
                    CommitNode commitNode = new CommitNode()
                            .setId(v.<String>getProperty(SpecialProperty.ID))
                            .setLabel(v.<String>getProperty(SpecialProperty.LABEL))
                            .setAction(Action.DELETE)
                            .setBoundary(false);
                    if (v.getProperty(SpecialProperty.ORIGINAL) != null) {
                        commitNode.setOriginal(deserializeProperties(
                                v.<String>getProperty(SpecialProperty.ORIGINAL)));
                    } else {
                        commitNode.setOriginal(getProperties(v));
                    }
                    return commitNode;
                } else {
                    return new CommitNode()
                            .setId(v.<String>getProperty(SpecialProperty.ID))
                            .setLabel(v.<String>getProperty(SpecialProperty.LABEL))
                            .setAction(Action.DELETE)
                            .setBoundary(true)
                            .setRepo(repo);
                }
            default:
                throw new VGraphException("Unknown Action");
        }
    }

    /**
     * Create a CommitEdge from the raw Blueprints Edge.
     * @param e The Blueprints Edge.
     * @param action The Action.
     * @return The CommitEdge.
     */
    public static CommitEdge createCommitEdge(Edge e, String action) {
        Map<String, Object> properties;

        switch(action) {
            case Action.CREATE:
                properties = getProperties(e);
                return new CommitEdge()
                        .setId(e.<String>getProperty(SpecialProperty.ID))
                        .setLabel(e.<String>getProperty(SpecialProperty.LABEL))
                        .setFrom(e.getVertex(com.tinkerpop.blueprints.Direction.OUT)
                                .<String>getProperty(SpecialProperty.ID))
                        .setTo(e.getVertex(com.tinkerpop.blueprints.Direction.IN)
                                .<String>getProperty(SpecialProperty.ID))
                        .setAction(Action.CREATE)
                        .setProperties(properties)
                        .setHash(SpecialProperty.calculateHash(properties));
            case Action.UPDATE:
                properties = getProperties(e);
                return new CommitEdge()
                        .setId(e.<String>getProperty(SpecialProperty.ID))
                        .setLabel(e.<String>getProperty(SpecialProperty.LABEL))
                        .setFrom(e.getVertex(com.tinkerpop.blueprints.Direction.OUT)
                                .<String>getProperty(SpecialProperty.ID))
                        .setTo(e.getVertex(com.tinkerpop.blueprints.Direction.IN)
                                .<String>getProperty(SpecialProperty.ID))
                        .setAction(Action.UPDATE)
                        .setOriginal(deserializeProperties(e.<String>getProperty(SpecialProperty.ORIGINAL)))
                        .setProperties(properties)
                        .setHash(SpecialProperty.calculateHash(properties));
            case Action.DELETE:
                CommitEdge commitEdge = new CommitEdge()
                        .setId(e.<String>getProperty(SpecialProperty.ID))
                        .setLabel(e.<String>getProperty(SpecialProperty.LABEL))
                        .setFrom(e.getVertex(com.tinkerpop.blueprints.Direction.OUT)
                                .<String>getProperty(SpecialProperty.ID))
                        .setTo(e.getVertex(com.tinkerpop.blueprints.Direction.IN)
                                .<String>getProperty(SpecialProperty.ID))
                        .setAction(Action.DELETE);
                if (e.getProperty(SpecialProperty.ORIGINAL) != null) {
                    commitEdge.setOriginal(deserializeProperties(e.<String>getProperty(SpecialProperty.ORIGINAL)));
                } else {
                    commitEdge.setOriginal(getProperties(e));
                }
                return commitEdge;
            default:
                throw new VGraphException("Unknown Action");
        }
    }

}

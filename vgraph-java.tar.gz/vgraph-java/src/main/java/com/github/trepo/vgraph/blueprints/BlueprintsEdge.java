package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.Property;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraphException;
import com.github.trepo.vgraph.blueprints.util.Util;
import com.tinkerpop.blueprints.Vertex;

import java.util.HashSet;
import java.util.Set;

/**
 * An Element representing an edge in the graph.
 * @author John Clark.
 */
public class BlueprintsEdge extends BlueprintsElement implements Edge {

    /**
     * The wrapped Blueprint Edge.
     */
    private com.tinkerpop.blueprints.Edge edge;

    /**
     * Our vGraph instance.
     */
    private BlueprintsVGraph graph;

    /**
     * Create a vGraph Edge that wraps a Blueprints Edge.
     * @param e The wrapped Blueprint Edge.
     * @param g The vGraph instance.
     */
    public BlueprintsEdge(com.tinkerpop.blueprints.Edge e, BlueprintsVGraph g) {
        edge = e;
        graph = g;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getId() {
        return edge.getProperty(SpecialProperty.ID);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getLabel() {
        return edge.getLabel();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public String getHash() {
        return edge.getProperty(SpecialProperty.HASH);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Set<String> getPropertyKeys() {
        Set<String> keys = new HashSet<>();
        for (String key:edge.getPropertyKeys()) {
            if (Property.isValidKey(key)) {
                keys.add(key);
            }
        }
        return keys;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public Object getProperty(String key) {
        if (!Property.isValidKey(key)) {
            throw new VGraphException("Invalid Regular Key");
        }
        return edge.getProperty(key);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void setProperty(String key, Object value) {
        if (!Property.isValidKey(key)) {
            throw new VGraphException("Invalid Regular Key");
        }
        if (!Property.isValidValue(value)) {
            throw new VGraphException("Invalid Regular Value");
        }
        if (graph.acquireLock()) {
            try {
                if (edge.getProperty(SpecialProperty.DELETED) != null) {
                    throw new VGraphException("Edge deleted");
                }
                graph.setDirty();
                if (edge.getProperty(SpecialProperty.HASH) != null) {
                    edge.setProperty(SpecialProperty.ORIGINAL, Util.serializeProperties(Util.getProperties(edge)));
                }
                edge.removeProperty(SpecialProperty.HASH);
                edge.setProperty(key, value);
            } finally {
                graph.unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void removeProperty(String key) {
        if (!Property.isValidKey(key)) {
            throw new VGraphException("Invalid Regular Key");
        }
        if (graph.acquireLock()) {
            try {
                if (edge.getProperty(SpecialProperty.DELETED) != null) {
                    throw new VGraphException("Edge deleted");
                }
                if (edge.getProperty(SpecialProperty.HASH) != null) {
                    edge.setProperty(SpecialProperty.ORIGINAL, Util.serializeProperties(Util.getProperties(edge)));
                }
                graph.setDirty();
                edge.removeProperty(SpecialProperty.HASH);
                edge.removeProperty(key);
            } finally {
                graph.unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    /**
     * {@inheritDoc}
     */
    public Node getNode(Direction direction) {
        Vertex v = edge.getVertex(Util.blueprintsDirection(direction));
        if (v.getProperty(SpecialProperty.REPO) != null) {
            return new BlueprintsBoundary(v, graph);
        } else {
            return new BlueprintsNode(v, graph);
        }
    }

    /**
     * Get the underlying Blueprints Edge.
     * @return The Blueprints Edge
     */
    public com.tinkerpop.blueprints.Edge getBlueprintsEdge() {
        return edge;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }

        BlueprintsEdge edge1 = (BlueprintsEdge) o;

        if (edge != null ? !edge.equals(edge1.edge) : edge1.edge != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        if (edge != null) {
            return edge.hashCode();
        } else {
            return 0;
        }
    }
}

package com.github.trepo.vgraph.blueprints.util;

import com.github.trepo.vgraph.MetaProperty;
import com.tinkerpop.blueprints.Direction;
import com.tinkerpop.blueprints.Vertex;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * @author John Clark.
 */
public class CommitNodeIterable implements Iterable<Vertex> {

    /**
     * Our starting vertex.
     */
    private Vertex start;

    /**
     * The direction of our travel.
     */
    private Direction direction;

    /**
     * Loop through Commit Nodes in a given direction.
     * @param startNode The starting Node (root or Commit Node).
     * @param iteratorDirection The direction to loop through.
     */
    public CommitNodeIterable(Vertex startNode, Direction iteratorDirection) {
        start = startNode;
        direction = iteratorDirection;
    }

    @Override
    public Iterator<Vertex> iterator() {
        return new CommitNodeIterator();
    }

    /**
     * Iterate over CommitNodes.
     */
    private class CommitNodeIterator implements Iterator<Vertex> {

        /**
         * The current vertex.
         */
        private Vertex currentVertex;

        /**
         * If we have another vertex.
         */
        private Boolean hasNext;

        /**
         * Start at the starting vertex.
         */
        public CommitNodeIterator() {
            currentVertex = start;
            hasNext = null;
        }

        @Override
        public boolean hasNext() {
            if (hasNext == null) {
                setNext();
            }
            return hasNext;
        }

        /**
         * Lazily see if there is another Commit Node.
         */
        private void setNext() {
            // Find the next Commit Node in the given direction
            for (Vertex possiblyNext : currentVertex.getVertices(direction, MetaProperty.COMMIT_EDGE)) {
                // Make sure this vertex is a commit node
                String metaKey = possiblyNext.getProperty(MetaProperty.KEY);
                if (metaKey != null && metaKey.equals(MetaProperty.COMMIT_NODE)) {
                    hasNext = true;
                    currentVertex = possiblyNext;
                    return;
                }
            }
            hasNext = false;
        }

        @Override
        public Vertex next() {
            if (!hasNext()) {
                throw new NoSuchElementException("No more nodes");
            }
            hasNext = null;

            return currentVertex;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Method not implemented");
        }
    }
}

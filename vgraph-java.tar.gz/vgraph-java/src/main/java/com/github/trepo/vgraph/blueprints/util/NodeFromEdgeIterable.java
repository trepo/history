package com.github.trepo.vgraph.blueprints.util;

import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.blueprints.BlueprintsNode;

import java.util.Iterator;

/**
 * @author John Clark.
 */
public class NodeFromEdgeIterable implements Iterable<Node> {

    /**
     * The initial node this iterator started from.
     */
    private BlueprintsNode node;

    /**
     * The internal iterable.
     */
    private Iterable<Edge> itr;

    /**
     * Wrap a blueprints Node Iterable.
     * @param iterable The iterable to wrap.
     * @param initialNode The node this iterable started from.
     */
    public NodeFromEdgeIterable(Iterable<Edge> iterable, BlueprintsNode initialNode) {
        this.itr = iterable;
        this.node = initialNode;
    }

    @Override
    public Iterator<Node> iterator() {
        return new NodesFromEdgeIterator();
    }

    /**
     * A private class that wraps our iterator.
     */
    private class NodesFromEdgeIterator implements Iterator<Node> {

        /**
         * Our wrapped iterator.
         */
        private Iterator<Edge> iterator;

        /**
         * Create an iterator that pulls from the above Iterable.
         */
        public NodesFromEdgeIterator() {
            iterator = itr.iterator();
        }

        @Override
        public boolean hasNext() {
            return iterator.hasNext();
        }

        @Override
        public Node next() {
            Edge e = iterator.next();
            if (e.getNode(Direction.OUT).equals(node)) {
                return e.getNode(Direction.IN);
            } else {
                return e.getNode(Direction.OUT);
            }
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Method not implemented");
        }
    }
}

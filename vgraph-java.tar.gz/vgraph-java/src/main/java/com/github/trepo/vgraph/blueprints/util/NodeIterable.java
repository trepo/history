package com.github.trepo.vgraph.blueprints.util;

import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.blueprints.BlueprintsBoundary;
import com.github.trepo.vgraph.blueprints.BlueprintsNode;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.Vertex;

import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * A Node iterable. Note that this will NOT return deleted nodes.
 * @author John Clark.
 */
public class NodeIterable implements Iterable<Node> {

    /**
     * Our vGraph instance.
     */
    private BlueprintsVGraph graph;

    /**
     * The internal itr.
     */
    private Iterable<Vertex> itr;

    /**
     * Wrap a blueprints Node Iterable.
     * @param iterable The iterable to wrap.
     * @param g The vGraph instance.
     */
    public NodeIterable(Iterable<Vertex> iterable, BlueprintsVGraph g) {
        this.itr = iterable;
        this.graph = g;
    }

    @Override
    public Iterator<Node> iterator() {
        return new NodesFromNodeIterator();
    }

    /**
     * A private class that wraps our iterator.
     */
    private class NodesFromNodeIterator implements Iterator<Node> {

        /**
         * Our wrapped iterator.
         */
        private Iterator<Vertex> iterator;

        /**
         * If we have another vertex.
         */
        private Boolean hasNext = null;

        /**
         * The next vertex.
         */
        private Vertex nextVertex;

        /**
         * Create an iterator that pulls from the above Iterable.
         */
        public NodesFromNodeIterator() {
            iterator = itr.iterator();
        }

        @Override
        public boolean hasNext() {

            if (hasNext == null) {
                setNext();
            }

            return hasNext;
        }

        /**
         * Figure out if we really do have another non-deleted node.
         */
        private void setNext() {
            while (iterator.hasNext()) {
                Vertex tmp = iterator.next();
                // If node is not deleted
                if (tmp.getProperty(SpecialProperty.DELETED) == null) {
                    hasNext = true;
                    nextVertex = tmp;
                    return;
                }
            }
            hasNext = false;
        }

        @Override
        public Node next() {
            if (!hasNext()) {
                throw new NoSuchElementException("No more elements");
            }

            hasNext = null;
            // If repo is set, return a boundary
            if (nextVertex.getProperty(SpecialProperty.REPO) != null) {
                return new BlueprintsBoundary(nextVertex, graph);
            } else {
                return new BlueprintsNode(nextVertex, graph);
            }
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Method not implemented");
        }
    }

}

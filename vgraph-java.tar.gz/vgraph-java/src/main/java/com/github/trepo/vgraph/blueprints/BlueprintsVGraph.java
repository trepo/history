package com.github.trepo.vgraph.blueprints;

import com.github.trepo.vgraph.Action;
import com.github.trepo.vgraph.Commit;
import com.github.trepo.vgraph.CommitEdge;
import com.github.trepo.vgraph.CommitNode;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Info;
import com.github.trepo.vgraph.LogEntry;
import com.github.trepo.vgraph.MetaProperty;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.Property;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.VGraphException;
import com.github.trepo.vgraph.blueprints.util.CommitNodeIterable;
import com.github.trepo.vgraph.blueprints.util.EdgeIterable;
import com.github.trepo.vgraph.blueprints.util.NodeIterable;
import com.github.trepo.vgraph.blueprints.util.Util;
import com.tinkerpop.blueprints.Direction;
import com.tinkerpop.blueprints.Features;
import com.tinkerpop.blueprints.KeyIndexableGraph;
import com.tinkerpop.blueprints.Vertex;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * A versioned graph.
 * @author John Clark
 */
public class BlueprintsVGraph implements VGraph {

    /**
     * The version of the vGraph API that this implements.
     */
    private String version = "0.2.0";

    /**
     * The internal Blueprints Graph.
     */
    private KeyIndexableGraph graph;

    /**
     * The repository identifier for this vGraph.
     */
    private String repo;

    /**
     * The Root Node.
     */
    private Vertex root;

    /**
     * The last commit id.
     */
    private String lastCommit;

    /**
     * If there are outstanding changes in the graph.
     */
    private AtomicBoolean dirty = new AtomicBoolean(false);

    /**
     * A write lock that you MUST acquire before changing things.
     */
    private Lock writeLock = new ReentrantLock();

    /**
     * How long to wait for a write lock.
     */
    private static final int ACQUIRE_TIMEOUT = 10; // In seconds

    /**
     * Create a new vGraph instance.
     * Make sure that there is only one vGraph instance operating on the underlying graph.
     * @param blueprintGraph A blueprints Graph instance.
     * @param repository The repository identifier.
     */
    public BlueprintsVGraph(KeyIndexableGraph blueprintGraph, String repository) {

        if (blueprintGraph == null) {
            throw new VGraphException("Invalid blueprintGraph");
        }

        if (!SpecialProperty.isValidRepo(repository)) {
            throw new VGraphException("Invalid repository");
        }

        // Make sure the supplied graph supports the features we need
        Features features = blueprintGraph.getFeatures();
        if (!features.supportsBooleanProperty || !features.supportsStringProperty
                || !features.supportsIntegerProperty || !features.supportsLongProperty
                || !features.supportsDoubleProperty || !features.supportsFloatProperty
                || !features.supportsPrimitiveArrayProperty || !features.supportsUniformListProperty
                || !features.supportsDuplicateEdges
                || !features.supportsEdgeIteration || !features.supportsEdgeProperties
                || !features.supportsVertexIteration || !features.supportsVertexProperties) {
            throw new VGraphException("Blueprint Graph MUST support the features used by vGraph");
        }

        graph = blueprintGraph;
        repo = repository;

        // Create vertex ID index if needed
        Set<String> vertexKeys = graph.getIndexedKeys(Vertex.class);
        if (!vertexKeys.contains(SpecialProperty.ID)) {
            graph.createKeyIndex(SpecialProperty.ID, Vertex.class);
        }
        // Create vertex meta index if needed
        if (!vertexKeys.contains(MetaProperty.KEY)) {
            graph.createKeyIndex(MetaProperty.KEY, Vertex.class);
        }

        // Create edge ID index if needed
        Set<String> edgeKeys = graph.getIndexedKeys(com.tinkerpop.blueprints.Edge.class);
        if (!edgeKeys.contains(SpecialProperty.ID)) {
            graph.createKeyIndex(SpecialProperty.ID, com.tinkerpop.blueprints.Edge.class);
        }

        // Retrieve/Create the Root node
        Iterator<Vertex> itr = graph.getVertices(MetaProperty.KEY, MetaProperty.ROOT).iterator();
        if (itr.hasNext()) {
            root = itr.next();

            // Get the last commit, if there is one
            Vertex lastCommitNode = getPreviousCommit(root);
            if (lastCommitNode != null) {
                lastCommit = lastCommitNode.getProperty(MetaProperty.COMMIT_ID);
            }

        } else {
            root = graph.addVertex(MetaProperty.ROOT);
            root.setProperty(MetaProperty.KEY, MetaProperty.ROOT);
            root.setProperty(MetaProperty.ROOT_VERSION, version);
        }


        // Check for deleted nodes
        if (graph.query().has(SpecialProperty.ID).has(SpecialProperty.DELETED)
                .vertices().iterator().hasNext()) {
            setDirty();
        }

        // Check for deleted edges
        if (!isDirty() && graph.query().has(SpecialProperty.ID).has(SpecialProperty.DELETED)
                .edges().iterator().hasNext()) {
            setDirty();
        }

        // Check for updated Nodes
        if (!isDirty() && graph.query().has(SpecialProperty.ID).hasNot(SpecialProperty.HASH)
                .vertices().iterator().hasNext()) {
            setDirty();
        }

        // Check for updated Edges
        if (!isDirty() && graph.query().has(SpecialProperty.ID).hasNot(SpecialProperty.HASH)
                .edges().iterator().hasNext()) {
            setDirty();
        }
    }

    @Override
    public Node addNode(String label) {
        if (acquireLock()) {
            try {
                setDirty();
                return addInternalNode(SpecialProperty.generateId(), label);
            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    @Override
    public void removeNode(String id) {
        if (acquireLock()) {
            try {
                Vertex v = getInternalNode(id);
                if (v == null) {
                    return;
                }
                if (v.getProperty(SpecialProperty.DELETED) != null) {
                    return;
                }
                if (v.getProperty(SpecialProperty.REPO) != null) {
                    throw new VGraphException("You may not delete a boundary node");
                }
                Long timestamp = SpecialProperty.generateTimestamp();
                setDirty();
                v.setProperty(SpecialProperty.DELETED, timestamp);
                for (com.tinkerpop.blueprints.Edge e: v.getEdges(com.tinkerpop.blueprints.Direction.BOTH)) {
                    if (e.getProperty(SpecialProperty.DELETED) == null) {
                        e.setProperty(SpecialProperty.DELETED, timestamp);
                    }
                }
            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    @Override
    public Node getNode(String id) {

        Vertex v = getInternalNode(id);

        if (v == null) {
            return null;
        }
        // Return null if node is marked as deleted
        if (v.getProperty(SpecialProperty.DELETED) != null) {
            return null;
        }
        if (v.getProperty(SpecialProperty.REPO) != null) {
            return new BlueprintsBoundary(v, this);
        } else {
            return new BlueprintsNode(v, this);
        }
    }

    @Override
    public Iterable<Node> getNodes() {
        return new NodeIterable(graph.query().has(SpecialProperty.ID).vertices(), this);
    }

    @Override
    public Iterable<Node> getNodes(String key, Object value) {
        if (!Property.isValidKey(key)) {
            throw new VGraphException("Invalid Regular Key");
        }
        if (!Property.isValidValue(value)) {
            throw new VGraphException("Invalid Regular Value");
        }
        return new NodeIterable(graph.query().has(SpecialProperty.ID).has(key, value).vertices(), this);
    }

    @Override
    public Edge addEdge(Node from, Node to, String label) {
        if (from == null) {
            throw new VGraphException("Invalid from");
        }
        // Write lock acquired by from node
        return from.addEdge(to, label);
    }

    @Override
    public void removeEdge(String id) {
        if (acquireLock()) {
            try {
                com.tinkerpop.blueprints.Edge e = getInternalEdge(id);
                if (e == null) {
                    return;
                }
                if (e.getProperty(SpecialProperty.DELETED) != null) {
                    return;
                }
                setDirty();
                e.setProperty(SpecialProperty.DELETED, SpecialProperty.generateTimestamp());
            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    @Override
    public Edge getEdge(String id) {
        com.tinkerpop.blueprints.Edge e = getInternalEdge(id);

        if (e == null) {
            return null;
        }
        // Return null if edge is marked as deleted.
        if (e.getProperty(SpecialProperty.DELETED) != null) {
            return null;
        }
        return new BlueprintsEdge(e, this);
    }

    @Override
    public Iterable<Edge> getEdges() {
        return new EdgeIterable(graph.query().has(SpecialProperty.ID).edges(), this);
    }

    @Override
    public Iterable<Edge> getEdges(String key, Object value) {
        if (!Property.isValidKey(key)) {
            throw new VGraphException("Invalid Regular Key");
        }
        if (!Property.isValidValue(value)) {
            throw new VGraphException("Invalid Regular Value");
        }
        return new EdgeIterable(graph.query().has(SpecialProperty.ID).has(key, value).edges(), this);
    }

    @Override
    public Info info() {
        return new Info(version, repo, lastCommit, !dirty.get());
    }

    @Override
    public List<LogEntry> log(Integer number, Integer offset) {

        if (number <= 0) {
            throw new VGraphException("number must be > 0");
        }

        if (offset < 0) {
            throw new VGraphException("offset must be >= 0");
        }

        int commitNumber = 0;
        int start = offset;
        int end = offset + number;
        ArrayList<LogEntry> entries = new ArrayList<>();

        for (Vertex v: new CommitNodeIterable(root, Direction.IN)) {
            if (commitNumber >= start && commitNumber < end) {
                entries.add(new LogEntry()
                                .setId(v.<String>getProperty(MetaProperty.COMMIT_ID))
                                .setTimestamp(v.<Long>getProperty(MetaProperty.COMMIT_TIMESTAMP))
                                .setAuthor(v.<String>getProperty(MetaProperty.COMMIT_AUTHOR))
                                .setEmail(v.<String>getProperty(MetaProperty.COMMIT_EMAIL))
                                .setMessage(v.<String>getProperty(MetaProperty.COMMIT_MESSAGE))
                );
            }
            if (commitNumber >= end) {
                break;
            }
            commitNumber++;
        }

        return entries;
    }

    @Override
    public Commit status() {
        if (acquireLock()) {
            try {
                return createCommit("", ""
                        , "Automatically generated via status on " + SpecialProperty.generateTimestamp());
            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    @Override
    public void reset() {
        if (acquireLock()) {
            try {

                // Resurrect Edges
                for (com.tinkerpop.blueprints.Edge e: graph.query().has(SpecialProperty.DELETED).edges()) {
                    e.removeProperty(SpecialProperty.DELETED);
                }

                // Reset Edges
                for (com.tinkerpop.blueprints.Edge e: graph.query().has(SpecialProperty.ID)
                        .hasNot(SpecialProperty.HASH).edges()) {
                    String original = e.getProperty(SpecialProperty.ORIGINAL);
                    if (original != null) {
                        for (String key: Util.getProperties(e).keySet()) {
                            e.removeProperty(key);
                        }
                        for (Map.Entry<String, Object> entry : Util.deserializeProperties(original).entrySet()) {
                            e.setProperty(entry.getKey(), entry.getValue());
                        }
                    } else {
                        e.remove();
                    }
                }

                // Resurrect Nodes
                for (Vertex v: graph.query().has(SpecialProperty.DELETED).vertices()) {
                    v.removeProperty(SpecialProperty.DELETED);
                }

                // Reset Nodes
                for (Vertex v: graph.query().has(SpecialProperty.ID).hasNot(SpecialProperty.HASH).vertices()) {
                    String original = v.getProperty(SpecialProperty.ORIGINAL);
                    if (original != null) {
                        for (String key: Util.getProperties(v).keySet()) {
                            v.removeProperty(key);
                        }
                        for (Map.Entry<String, Object> entry : Util.deserializeProperties(original).entrySet()) {
                            v.setProperty(entry.getKey(), entry.getValue());
                        }
                    } else {
                        v.remove();
                    }
                }

                // We are now clean
                dirty.set(false);

            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    @Override
    public Commit commit(String author, String email, String message) {

        if (acquireLock()) {
            try {

                // Create commit
                Commit commit = createCommit(author, email, message);

                // Patch our own graph with the created commit
                applyCommit(commit);

                // We are now clean
                dirty.set(false);

                // Return the commit
                return commit;

            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }

    }

    @Override
    public List<String> undo(String id) {

        if (!SpecialProperty.isValidId(id)) {
            throw new VGraphException("invalid commit id");
        }

        if (acquireLock()) {
            try {

                if (dirty.get()) {
                    throw new VGraphException("cannot undo a dirty graph");
                }

                // Loop through and find Commit
                boolean exists = false;
                for (Vertex v: new CommitNodeIterable(root, Direction.IN)) {
                    if (v.getProperty(MetaProperty.COMMIT_ID).equals(id)) {
                        exists = true;
                        break;
                    }
                }

                // If commit doesn't exist, error
                if (!exists) {
                    throw new VGraphException("commit does not exist");
                }

                ArrayList<String> undoneCommits = new ArrayList<>();

                // For each Commit, undo it
                Vertex toUndo = null;
                for (Vertex prevCommit: new CommitNodeIterable(root, Direction.IN)) {
                    if (toUndo == null) {
                        toUndo = prevCommit;
                        continue;
                    }
                    // If we've undone everything, we're done
                    if (toUndo.getProperty(MetaProperty.COMMIT_ID).equals(id)) {
                        break;
                    }

                    // Add an edge from the previous commit to root
                    prevCommit.addEdge(MetaProperty.COMMIT_EDGE, root);

                    // Reconstitute Commit
                    Commit commit = Util.commitFromCommitNode(toUndo);

                    // Undo DELETE Node
                    for (CommitNode commitNode: commit.getNodes()) {
                        if (commitNode.getAction().equals(Action.DELETE)) {
                            // Add Node
                            Vertex newNode = addInternalNode(commitNode.getId()
                                    , commitNode.getLabel()).getBlueprintsNode();
                            // If Boundary just set repo
                            if (commitNode.isBoundary()) {
                                newNode.setProperty(SpecialProperty.REPO, commitNode.getRepo());
                            } else {
                                // Add original properties and set hash
                                for (Map.Entry<String, Object> entry: commitNode.getOriginal().entrySet()) {
                                    newNode.setProperty(entry.getKey(), entry.getValue());
                                }
                                newNode.setProperty(SpecialProperty.HASH
                                        , SpecialProperty.calculateHash(commitNode.getOriginal()));
                            }
                        }
                    }

                    // Undo DELETE Edge
                    for (CommitEdge commitEdge: commit.getEdges()) {
                        if (commitEdge.getAction().equals(Action.DELETE)) {
                            // Add edge
                            com.tinkerpop.blueprints.Edge newEdge = getInternalNode(commitEdge.getFrom())
                                    .addEdge(commitEdge.getLabel(), getInternalNode(commitEdge.getTo()));
                            newEdge.setProperty(SpecialProperty.ID, commitEdge.getId());
                            newEdge.setProperty(SpecialProperty.LABEL, commitEdge.getLabel());
                            // Add original properties and set hash
                            for (Map.Entry<String, Object> entry: commitEdge.getOriginal().entrySet()) {
                                newEdge.setProperty(entry.getKey(), entry.getValue());
                            }
                            newEdge.setProperty(SpecialProperty.HASH
                                    , SpecialProperty.calculateHash(commitEdge.getOriginal()));

                        }
                    }

                    // Undo UPDATE Edge
                    for (CommitEdge commitEdge: commit.getEdges()) {
                        if (commitEdge.getAction().equals(Action.UPDATE)) {
                            // Get edge
                            com.tinkerpop.blueprints.Edge changedEdge = getInternalEdge(commitEdge.getId());
                            // Remove old properties
                            for (String key: changedEdge.getPropertyKeys()) {
                                if (Property.isValidKey(key)) {
                                    changedEdge.removeProperty(key);
                                }
                            }
                            // Add original properties and set hash
                            for (Map.Entry<String, Object> entry: commitEdge.getOriginal().entrySet()) {
                                changedEdge.setProperty(entry.getKey(), entry.getValue());
                            }
                            changedEdge.setProperty(SpecialProperty.HASH
                                    , SpecialProperty.calculateHash(commitEdge.getOriginal()));
                        }
                    }

                    // Undo CREATE Edge
                    for (CommitEdge commitEdge: commit.getEdges()) {
                        if (commitEdge.getAction().equals(Action.CREATE)) {
                            // Get and remove edge
                            getInternalEdge(commitEdge.getId()).remove();
                        }
                    }

                    // Undo UPDATE Node
                    for (CommitNode commitNode: commit.getNodes()) {
                        if (commitNode.getAction().equals(Action.UPDATE)) {
                            // Get node
                            Vertex changedNode = getInternalNode(commitNode.getId());
                            // Remove old properties
                            for (String key: changedNode.getPropertyKeys()) {
                                if (Property.isValidKey(key)) {
                                    changedNode.removeProperty(key);
                                }
                            }
                            // Add original properties and set hash
                            for (Map.Entry<String, Object> entry: commitNode.getOriginal().entrySet()) {
                                changedNode.setProperty(entry.getKey(), entry.getValue());
                            }
                            changedNode.setProperty(SpecialProperty.HASH
                                    , SpecialProperty.calculateHash(commitNode.getOriginal()));
                        }
                    }

                    // Undo CREATE Node
                    for (CommitNode commitNode: commit.getNodes()) {
                        if (commitNode.getAction().equals(Action.CREATE)) {
                            // Get and remove Node if it's not a boundary node for this graph
                            if (!commitNode.isBoundary() || !commitNode.getRepo().equals(repo)) {
                                getInternalNode(commitNode.getId()).remove();
                            }
                        }
                    }

                    // Add commit id to undoneCommits
                    undoneCommits.add(toUndo.<String>getProperty(MetaProperty.COMMIT_ID));

                    // Set lastCommit
                    lastCommit = prevCommit.getProperty(MetaProperty.COMMIT_ID);

                    // Remove commit
                    toUndo.remove();

                    // Go back one more commit
                    toUndo = prevCommit;
                }

                return undoneCommits;

            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    @Override
    public void patch(Commit commit) {

        // Validate the commit
        commit.validate();

        if (acquireLock()) {
            try {

                if (dirty.get()) {
                    throw new VGraphException("cannot patch a dirty graph");
                }

                if (!((commit.getPrev() == null && lastCommit == null)
                        || (commit.getPrev() != null && commit.getPrev().equals(lastCommit)))) {
                    throw new VGraphException("previous commit mismatch. Did you mean to merge?");
                }

                applyCommit(commit);

            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    @Override
    public Iterable<Commit> cloneGraph() {
        if (acquireLock()) {
            try {

                if (dirty.get()) {
                    throw new VGraphException("cannot clone a dirty graph");
                }

                ArrayList<Commit> commits = new ArrayList<>();
                String prevCommitId = null;

                for (Vertex commitNode: new CommitNodeIterable(root, Direction.OUT)) {
                    Commit commit = Util.commitFromCommitNode(commitNode).setPrev(prevCommitId);
                    prevCommitId = commit.getId();
                    commits.add(commit);
                }

                return commits;

            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }

    }

    @Override
    public Iterable<Commit> cloneGraph(Iterable<Node> nodes) {
        if (acquireLock()) {
            try {

                if (dirty.get()) {
                    throw new VGraphException("cannot clone a dirty graph");
                }

                HashSet<String> nodeIds = new HashSet<>();
                HashSet<String> edgeIds = new HashSet<>();

                for (Node node: nodes) {
                    nodeIds.add(node.getId());
                    for (Edge edge: node.getEdges(com.github.trepo.vgraph.Direction.BOTH)) {
                        edgeIds.add(edge.getId());
                    }
                }

                ArrayList<Commit> commits = new ArrayList<>();
                String prevCommitId = null;

                for (Vertex v: new CommitNodeIterable(root, Direction.OUT)) {
                    Commit currentCommit = Util.commitFromCommitNode(v);

                    // Adding the same node/edge twice will not overwrite
                    HashSet<CommitNode> commitNodes = new HashSet<>();
                    HashSet<CommitEdge> commitEdges = new HashSet<>();
                    HashSet<String> potentialBoundaryNodes = new HashSet<>();

                    // Add edges and mark potential boundaries
                    for (CommitEdge commitEdge: currentCommit.getEdges()) {
                        if (edgeIds.contains(commitEdge.getId())) {
                            commitEdges.add(commitEdge);
                            // Only add boundary nodes for action != delete
                            if (!commitEdge.getAction().equals(Action.DELETE)) {
                                potentialBoundaryNodes.add(commitEdge.getFrom());
                                potentialBoundaryNodes.add(commitEdge.getTo());
                            }
                        }
                    }

                    // Add nodes and required boundary nodes
                    for (CommitNode commitNode: currentCommit.getNodes()) {
                        if (nodeIds.contains(commitNode.getId())) {
                            commitNodes.add(commitNode);
                            continue;
                        }
                        if (potentialBoundaryNodes.contains(commitNode.getId())) {
                            if (commitNode.isBoundary()) {
                                commitNodes.add(new CommitNode()
                                                .setId(commitNode.getId())
                                                .setLabel(commitNode.getLabel())
                                                .setAction(Action.CREATE)
                                                .setBoundary(true)
                                                .setRepo(commitNode.getRepo())
                                );
                            } else {
                                commitNodes.add(new CommitNode()
                                                .setId(commitNode.getId())
                                                .setLabel(commitNode.getLabel())
                                                .setAction(Action.CREATE)
                                                .setBoundary(true)
                                                .setRepo(repo)
                                );
                            }
                        }
                    }
                    // Create and add commit if we have nodes or edges
                    if (!commitNodes.isEmpty() || !commitEdges.isEmpty()) {
                        Commit newCommit = new Commit()
                                .setVersion(1)
                                .setId(SpecialProperty.generateId())
                                .setPrev(prevCommitId)
                                .setRepo(currentCommit.getRepo())
                                .setTimestamp(currentCommit.getTimestamp())
                                .setAuthor(currentCommit.getAuthor())
                                .setEmail(currentCommit.getEmail())
                                .setMessage(currentCommit.getMessage())
                                .setNodes(commitNodes)
                                .setEdges(commitEdges);
                        prevCommitId = newCommit.getId();
                        commits.add(newCommit);
                    }
                }

                return commits;
            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    @Override
    public Commit copy(String author, String email, String message) {

        if (acquireLock()) {
            try {

                if (dirty.get()) {
                    throw new VGraphException("cannot copy a dirty graph");
                }

                // Set of CommitNodes
                Set<CommitNode> commitNodes = new HashSet<>();
                // Set of CommitEdges
                Set<CommitEdge> commitEdges = new HashSet<>();

                for (Vertex v: graph.query().has(SpecialProperty.ID).vertices()) {
                    // If node is a boundary
                    String nodeRepo = v.getProperty(SpecialProperty.REPO);
                    if (nodeRepo != null) {
                        commitNodes.add(Util.createCommitNode(v, Action.CREATE, nodeRepo));
                    } else {
                        commitNodes.add(Util.createCommitNode(v, Action.CREATE, null));
                    }
                }

                for (com.tinkerpop.blueprints.Edge e: graph.query().has(SpecialProperty.ID).edges()) {
                    commitEdges.add(Util.createCommitEdge(e, Action.CREATE));
                }

                return new Commit()
                        .setVersion(1)
                        .setId(SpecialProperty.generateId())
                        .setRepo(repo)
                        .setTimestamp(SpecialProperty.generateTimestamp())
                        .setAuthor(author)
                        .setEmail(email)
                        .setMessage(message)
                        .setNodes(commitNodes)
                        .setEdges(commitEdges);
            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }

    @Override
    public Commit copy(Iterable<Node> nodes, String author, String email, String message) {

        if (acquireLock()) {
            try {

                if (dirty.get()) {
                    throw new VGraphException("cannot copy a dirty graph");
                }

                // Set of Touched Nodes
                Set<Node> nodesTouched = new HashSet<>();

                // Set of CommitNodes (duplicates are discarded when adding)
                Set<CommitNode> commitNodes = new HashSet<>();
                // Set of CommitEdges
                Set<CommitEdge> commitEdges = new HashSet<>();

                for (Node n: nodes) {
                    if (n.isBoundary()) {
                        commitNodes.add(new CommitNode()
                                        .setId(n.getId())
                                        .setLabel(n.getLabel())
                                        .setAction(Action.CREATE)
                                        .setBoundary(true)
                                        .setRepo(n.getRepo())
                        );
                    } else {
                        Map<String, Object> properties = Util.getProperties(n);
                        commitNodes.add(new CommitNode()
                                        .setId(n.getId())
                                        .setLabel(n.getLabel())
                                        .setAction(Action.CREATE)
                                        .setBoundary(false)
                                        .setProperties(properties)
                                        .setHash(SpecialProperty.calculateHash(properties))
                        );
                    }
                    for (Edge e: n.getEdges(com.github.trepo.vgraph.Direction.IN)) {
                        Map<String, Object> properties = Util.getProperties(e);
                        commitEdges.add(new CommitEdge()
                                        .setId(e.getId())
                                        .setLabel(e.getLabel())
                                        .setFrom(e.getNode(com.github.trepo.vgraph.Direction.OUT).getId())
                                        .setTo(e.getNode(com.github.trepo.vgraph.Direction.IN).getId())
                                        .setAction(Action.CREATE)
                                        .setProperties(properties)
                                        .setHash(SpecialProperty.calculateHash(properties))
                        );
                        nodesTouched.add(e.getNode(com.github.trepo.vgraph.Direction.OUT));
                    }
                    for (Edge e: n.getEdges(com.github.trepo.vgraph.Direction.OUT)) {
                        Map<String, Object> properties = Util.getProperties(e);
                        commitEdges.add(new CommitEdge()
                                        .setId(e.getId())
                                        .setLabel(e.getLabel())
                                        .setFrom(e.getNode(com.github.trepo.vgraph.Direction.OUT).getId())
                                        .setTo(e.getNode(com.github.trepo.vgraph.Direction.IN).getId())
                                        .setAction(Action.CREATE)
                                        .setProperties(properties)
                                        .setHash(SpecialProperty.calculateHash(properties))
                        );
                        nodesTouched.add(e.getNode(com.github.trepo.vgraph.Direction.IN));
                    }
                }

                // Add any remaining nodes as boundary nodes
                for (Node n: nodesTouched) {
                    if (n.isBoundary()) {
                        commitNodes.add(new CommitNode()
                                        .setId(n.getId())
                                        .setLabel(n.getLabel())
                                        .setAction(Action.CREATE)
                                        .setBoundary(true)
                                        .setRepo(n.getRepo())
                        );
                    } else {
                        commitNodes.add(new CommitNode()
                                        .setId(n.getId())
                                        .setLabel(n.getLabel())
                                        .setAction(Action.CREATE)
                                        .setBoundary(true)
                                        .setRepo(repo)
                        );
                    }
                }

                return new Commit()
                        .setVersion(1)
                        .setId(SpecialProperty.generateId())
                        .setRepo(repo)
                        .setTimestamp(SpecialProperty.generateTimestamp())
                        .setAuthor(author)
                        .setEmail(email)
                        .setMessage(message)
                        .setNodes(commitNodes)
                        .setEdges(commitEdges);
            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }

    }

    @Override
    public Commit merge(Commit commit, String author, String email, String message) {

        // Validate the commit
        commit.validate();

        if (acquireLock()) {
            try {

                if (dirty.get()) {
                    throw new VGraphException("cannot merge with a dirty graph");
                }

                // Set of CommitNodes
                HashSet<CommitNode> commitNodes = new HashSet<>();
                // Set of CommitEdges
                HashSet<CommitEdge> commitEdges = new HashSet<>();

                // HashMap of CommitEdge IDs to actions
                HashMap<String, String> commitEdgeActions = new HashMap<>();

                for (CommitEdge commitEdge: commit.getEdges()) {
                    commitEdgeActions.put(commitEdge.getId(), commitEdge.getAction());
                }

                for (CommitNode commitNode: commit.getNodes()) {
                    Vertex v = getInternalNode(commitNode.getId());
                    if (commitNode.getAction().equals(Action.DELETE)) {
                        if (v == null) {
                            continue;
                        }
                        for (com.tinkerpop.blueprints.Edge e: v.getEdges(Direction.BOTH)) {
                            String edgeId = e.getProperty(SpecialProperty.ID);
                            String edgeAction = commitEdgeActions.get(edgeId);
                            if (edgeAction == null || !edgeAction.equals(Action.DELETE)) {
                                throw new VGraphException("Merge Conflict: edge " + edgeId
                                        + " is present when trying to delete node " + commitNode.getId());
                            }
                        }
                        if (commitNode.isBoundary()) {
                            commitNodes.add(commitNode);
                        } else {
                            commitNodes.add(new CommitNode()
                                    .setId(commitNode.getId())
                                    .setLabel(commitNode.getLabel())
                                    .setAction(Action.DELETE)
                                    .setBoundary(false)
                                    .setOriginal(Util.getProperties(v))
                            );
                        }
                    }
                    if (commitNode.getAction().equals(Action.UPDATE)) {
                        if (v == null) {
                            commitNodes.add(new CommitNode()
                                    .setId(commitNode.getId())
                                    .setLabel(commitNode.getLabel())
                                    .setAction(Action.CREATE)
                                    .setBoundary(false)
                                    .setProperties(commitNode.getProperties())
                                    .setHash(commitNode.getHash())
                            );
                        } else {
                            commitNodes.add(new CommitNode()
                                    .setId(commitNode.getId())
                                    .setLabel(commitNode.getLabel())
                                    .setAction(Action.UPDATE)
                                    .setBoundary(false)
                                    .setOriginal(Util.getProperties(v))
                                    .setProperties(commitNode.getProperties())
                                    .setHash(commitNode.getHash())
                            );
                        }
                    }
                    if (commitNode.getAction().equals(Action.CREATE)) {
                        if (v == null) {
                            commitNodes.add(commitNode);
                        } else {
                            if (commitNode.isBoundary()) {
                                commitNodes.add(commitNode);
                            } else {
                                commitNodes.add(new CommitNode()
                                                .setId(commitNode.getId())
                                                .setLabel(commitNode.getLabel())
                                                .setAction(Action.UPDATE)
                                                .setBoundary(false)
                                                .setOriginal(Util.getProperties(v))
                                                .setProperties(commitNode.getProperties())
                                                .setHash(commitNode.getHash())
                                );
                            }
                        }
                    }
                }

                for (CommitEdge commitEdge: commit.getEdges()) {
                    com.tinkerpop.blueprints.Edge e = getInternalEdge(commitEdge.getId());
                    if (commitEdge.getAction().equals(Action.DELETE)) {
                        if (e == null) {
                            continue;
                        }
                        commitEdges.add(new CommitEdge()
                                .setId(commitEdge.getId())
                                .setLabel(commitEdge.getLabel())
                                .setFrom(commitEdge.getFrom())
                                .setTo(commitEdge.getTo())
                                .setAction(Action.DELETE)
                                .setOriginal(Util.getProperties(e))
                        );
                    }
                    if (commitEdge.getAction().equals(Action.UPDATE)) {
                        if (e == null) {
                            commitEdges.add(new CommitEdge()
                                    .setId(commitEdge.getId())
                                    .setLabel(commitEdge.getLabel())
                                    .setFrom(commitEdge.getFrom())
                                    .setTo(commitEdge.getTo())
                                    .setAction(Action.CREATE)
                                    .setProperties(commitEdge.getProperties())
                                    .setHash(commitEdge.getHash())
                            );
                        } else {
                            commitEdges.add(new CommitEdge()
                                    .setId(commitEdge.getId())
                                    .setLabel(commitEdge.getLabel())
                                    .setFrom(commitEdge.getFrom())
                                    .setTo(commitEdge.getTo())
                                    .setAction(Action.UPDATE)
                                    .setOriginal(Util.getProperties(e))
                                    .setProperties(commitEdge.getProperties())
                                    .setHash(commitEdge.getHash())
                            );
                        }
                    }
                    if (commitEdge.getAction().equals(Action.CREATE)) {
                        if (e == null) {
                            commitEdges.add(commitEdge);
                        } else {
                            commitEdges.add(new CommitEdge()
                                            .setId(commitEdge.getId())
                                            .setLabel(commitEdge.getLabel())
                                            .setFrom(commitEdge.getFrom())
                                            .setTo(commitEdge.getTo())
                                            .setAction(Action.UPDATE)
                                            .setOriginal(Util.getProperties(e))
                                            .setProperties(commitEdge.getProperties())
                                            .setHash(commitEdge.getHash())
                            );
                        }
                    }
                }

                return new Commit()
                        .setVersion(1)
                        .setId(SpecialProperty.generateId())
                        .setPrev(lastCommit)
                        .setRepo(commit.getRepo())
                        .setTimestamp(SpecialProperty.generateTimestamp())
                        .setAuthor(author)
                        .setEmail(email)
                        .setMessage(message)
                        .setNodes(commitNodes)
                        .setEdges(commitEdges);

            } finally {
                unlock();
            }
        } else {
            throw new VGraphException("Unable to acquire write lock");
        }
    }


    /*********************************
     ** Blueprints Specific Methods **
     *********************************/


    /**
     * Gets the underlying Blueprints graph.
     * @return The KeyIndexableGraph Blueprints graph.
     */
    public KeyIndexableGraph getBlueprintsGraph() {
        return graph;
    }

    /**
     * Set the dirty flag to true.
     */
    protected void setDirty() {
        dirty.set(true);
    }

    /**
     * Gets the dirty flag.
     * @return If the graph is dirty or not.
     */
    public boolean isDirty() {
        return dirty.get();
    }
    /**
     * Attempt to acquire a write lock.
     * @return True if the write lock was acquired before the timeout.
     */
    protected boolean acquireLock() {
        try {
            return writeLock.tryLock(ACQUIRE_TIMEOUT, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            throw new VGraphException("tryLock interrupted", e);
        }
    }

    /**
     * Release the write lock.
     */
    protected void unlock() {
        writeLock.unlock();
    }

    /**
     * A privately available method used for adding nodes during a patch.
     * @param id The id to give the new node.
     * @param label The new node's label.
     * @return The newly created node.
     */
    private BlueprintsNode addInternalNode(String id, String label) {

        if (!SpecialProperty.isValidLabel(label)) {
            throw new VGraphException("Invalid Label");
        }

        Vertex v = graph.addVertex(id);
        v.setProperty(SpecialProperty.ID, id);
        v.setProperty(SpecialProperty.LABEL, label);

        return new BlueprintsNode(v, this);
    }

    /**
     * Get an internal blueprints node.
     * @param id The node id.
     * @return The Vertex.
     */
    private Vertex getInternalNode(String id) {
        Iterator<Vertex> itr = graph.getVertices(SpecialProperty.ID, id).iterator();
        if (itr.hasNext()) {
            return itr.next();
        }
        return null;
    }

    /**
     * Get an internal blueprints edge.
     * @param id The node id.
     * @return The Edge.
     */
    private com.tinkerpop.blueprints.Edge getInternalEdge(String id) {
        Iterator<com.tinkerpop.blueprints.Edge> itr = graph.getEdges(SpecialProperty.ID, id).iterator();
        if (itr.hasNext()) {
            return itr.next();
        }
        return null;
    }

    /**
     * Given v, get the previous commit.
     * @param v The current vertex.
     * @return The previous commit vertex.
     */
    private Vertex getPreviousCommit(Vertex v) {
        for (Vertex n : v.getVertices(Direction.IN, MetaProperty.COMMIT_EDGE)) {
            // Only return this node if it is a Commit Node
            if (n.<String>getProperty(MetaProperty.KEY).equals(MetaProperty.COMMIT_NODE)) {
                return n;
            }
        }
        return null;
    }

    /**
     * Create a commit.
     * Make sure you have a write lock before calling this function.
     * @param author The Committer's author.
     * @param email The Committer's email.
     * @param message A message to associate with this commit.
     * @return The commit object.
     */
    private Commit createCommit(String author, String email, String message) {

        // Set of CommitNodes
        HashSet<CommitNode> commitNodes = new HashSet<>();
        // Set of CommitEdges
        HashSet<CommitEdge> commitEdges = new HashSet<>();

        // Loop through all deleted nodes
        for (Vertex v: graph.query().has(SpecialProperty.DELETED).vertices()) {
            // Silently delete nodes that were added and deleted in the same commit
            if (v.getProperty(SpecialProperty.HASH) == null && v.getProperty(SpecialProperty.ORIGINAL) == null) {
                v.remove();
            } else {
                commitNodes.add(Util.createCommitNode(v, Action.DELETE, null));
            }
        }

        // Loop through all deleted edges
        for (com.tinkerpop.blueprints.Edge e: graph.query().has(SpecialProperty.DELETED).edges()) {
            // Silently delete nodes that were added and deleted in the same commit
            if (e.getProperty(SpecialProperty.HASH) == null && e.getProperty(SpecialProperty.ORIGINAL) == null) {
                e.remove();
            } else {
                commitEdges.add(Util.createCommitEdge(e, Action.DELETE));
            }
        }

        // Loop through all updated Nodes
        for (Vertex v: graph.query().has(SpecialProperty.ID)
                .hasNot(SpecialProperty.HASH).hasNot(SpecialProperty.DELETED).vertices()) {
            if (v.getProperty(SpecialProperty.ORIGINAL) != null) {
                commitNodes.add(Util.createCommitNode(v, Action.UPDATE, null));
            } else {
                commitNodes.add(Util.createCommitNode(v, Action.CREATE, null));
            }
        }

        // Loop through all updated Edges
        for (com.tinkerpop.blueprints.Edge e : graph.query().has(SpecialProperty.ID)
                .hasNot(SpecialProperty.HASH).hasNot(SpecialProperty.DELETED).edges()) {
            if (e.getProperty(SpecialProperty.ORIGINAL) != null) {
                commitEdges.add(Util.createCommitEdge(e, Action.UPDATE));
            } else {
                commitEdges.add(Util.createCommitEdge(e, Action.CREATE));
            }
            // Add BOTH Nodes to CommitNodes as boundary nodes (If already updated it won't be added twice)
            Vertex fromNode = e.getVertex(Direction.OUT);
            if (fromNode.getProperty(SpecialProperty.REPO) != null) {
                commitNodes.add(Util.createCommitNode(fromNode, Action.CREATE
                        , fromNode.<String>getProperty(SpecialProperty.REPO)));
            } else {
                commitNodes.add(Util.createCommitNode(fromNode, Action.CREATE, repo));
            }
            Vertex toNode = e.getVertex(Direction.IN);
            if (toNode.getProperty(SpecialProperty.REPO) != null) {
                commitNodes.add(Util.createCommitNode(toNode, Action.CREATE
                        , toNode.<String>getProperty(SpecialProperty.REPO)));
            } else {
                commitNodes.add(Util.createCommitNode(toNode, Action.CREATE, repo));
            }
        }

        // Create and return Commit
        return new Commit()
                .setVersion(1)
                .setId(SpecialProperty.generateId())
                .setPrev(lastCommit)
                .setRepo(repo)
                .setTimestamp(SpecialProperty.generateTimestamp())
                .setAuthor(author)
                .setEmail(email)
                .setMessage(message)
                .setNodes(commitNodes)
                .setEdges(commitEdges);
    }

    /**
     * Apply a commit.
     * Make sure you have a write lock before calling this function.
     * @param commit The commit to apply.
     */
    private void applyCommit(Commit commit) {

        // Get last Commit Node/Edge
        Vertex lastCommitNode = null;
        com.tinkerpop.blueprints.Edge lastCommitEdge = null;
        Iterator<Vertex> itr = root.getVertices(Direction.IN, MetaProperty.COMMIT_EDGE).iterator();
        if (itr.hasNext()) {
            lastCommitNode = itr.next();
            lastCommitEdge = lastCommitNode.getEdges(Direction.OUT).iterator().next();
        }

        // Create new CommitNode
        Vertex newCommitNode = Util.commitNodeFromCommit(commit, graph);

        // Add Commit Edge from new Commit Node to the Root Node
        newCommitNode.addEdge(MetaProperty.COMMIT_EDGE, root);

        // Add Commit Edge from last Commit Node or the root node to the new Commit Node
        if (lastCommitNode != null) {
            lastCommitNode.addEdge(MetaProperty.COMMIT_EDGE, newCommitNode);
        } else {
            root.addEdge(MetaProperty.COMMIT_EDGE, newCommitNode);
        }

        // Create/update nodes
        for (CommitNode commitNode : commit.getNodes()) {
            if (commitNode.getAction().equals(Action.CREATE) || commitNode.getAction().equals(Action.UPDATE)) {
                Vertex v = getInternalNode(commitNode.getId());
                // Create node if null
                if (v == null) {
                    v = graph.addVertex(commitNode.getId());
                    v.setProperty(SpecialProperty.ID, commitNode.getId());
                    v.setProperty(SpecialProperty.LABEL, commitNode.getLabel());
                    // If a boundary, set repo
                    if (commitNode.isBoundary()) {
                        v.setProperty(SpecialProperty.REPO, commitNode.getRepo());
                    }
                }
                // If we're not a boundary remove old properties and add new ones
                if (!commitNode.isBoundary()) {
                    for (String key: Util.getProperties(v).keySet()) {
                        v.removeProperty(key);
                    }
                    for (Map.Entry<String, Object> entry : commitNode.getProperties().entrySet()) {
                        v.setProperty(entry.getKey(), entry.getValue());
                    }
                }
                // Always set the hash and clear out original
                v.setProperty(SpecialProperty.HASH, Util.calculateHash(new BlueprintsNode(v, this)));
                v.removeProperty(SpecialProperty.ORIGINAL);
            }
        }

        // Create/update/delete edges
        for (CommitEdge commitEdge : commit.getEdges()) {
            com.tinkerpop.blueprints.Edge e = getInternalEdge(commitEdge.getId());

            if (commitEdge.getAction().equals(Action.CREATE) || commitEdge.getAction().equals(Action.UPDATE)) {
                // If edge doesn't exist, create it
                if (e == null) {
                    Vertex v1 = getInternalNode(commitEdge.getFrom());
                    Vertex v2 = getInternalNode(commitEdge.getTo());
                    e = v1.addEdge(commitEdge.getLabel(), v2);
                    e.setProperty(SpecialProperty.ID, commitEdge.getId());
                    e.setProperty(SpecialProperty.LABEL, commitEdge.getLabel());
                }
                // Remove old properties and add new ones
                for (String key: Util.getProperties(e).keySet()) {
                    e.removeProperty(key);
                }
                for (Map.Entry<String, Object> entry : commitEdge.getProperties().entrySet()) {
                    e.setProperty(entry.getKey(), entry.getValue());
                }
                // Always set the hash and clear out origina;
                e.setProperty(SpecialProperty.HASH, Util.calculateHash(new BlueprintsEdge(e, this)));
                e.removeProperty(SpecialProperty.ORIGINAL);
            }

            if (commitEdge.getAction().equals(Action.DELETE)) {
                // If edge exists, delete it
                if (e != null) {
                    e.remove();
                }
            }
        }

        // Delete nodes
        for (CommitNode commitNode : commit.getNodes()) {
            if (commitNode.getAction().equals(Action.DELETE)) {
                getInternalNode(commitNode.getId()).remove();
            }
        }

        // If lastCommitEdge exists, delete it
        if (lastCommitEdge != null) {
            lastCommitEdge.remove();
        }

        // Set lastCommit
        lastCommit = commit.getId();
    }

    /**
     * Shutdown the graph. Required for a clean exit.
     */
    public void shutdown() {
        graph.shutdown();
    }
}

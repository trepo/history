/**
 * vGraph, a distributable versioned property graph.
 * @author John Clark.
 */
package com.github.trepo.vgraph.blueprints;

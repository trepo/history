package com.github.trepo.server.factory;

import org.testng.annotations.Test;

/**
 * @author John Clark.
 */
public class VGraphFactoryTest {

    @Test
    public void shouldWork() {
        // TODO get rid of global singleton and use Guice.
    }
}

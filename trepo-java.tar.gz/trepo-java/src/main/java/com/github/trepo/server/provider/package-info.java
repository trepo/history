/**
 * various JAX-RS providers.
 * @author John Clark.
 */
package com.github.trepo.server.provider;

/**
 * Trepo jax-rs applications.
 * @author John Clark.
 */
package com.github.trepo.server.application;

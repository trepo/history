/**
 * Various Trepo Models.
 * @author John Clark.
 */
package com.github.trepo.server.model;

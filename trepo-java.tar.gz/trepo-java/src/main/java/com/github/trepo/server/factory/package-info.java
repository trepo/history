/**
 * Inject Factories.
 * @author John Clark.
 */
package com.github.trepo.server.factory;

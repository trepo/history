/**
 * Root Trepo Resources.
 * @author John Clark.
 */
package com.github.trepo.server.rest.root;

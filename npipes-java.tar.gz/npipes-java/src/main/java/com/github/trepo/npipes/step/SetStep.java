package com.github.trepo.npipes.step;

import com.github.trepo.npipes.NPipesException;
import com.github.trepo.npipes.Step;
import com.github.trepo.npipes.Traversal;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.VGraph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Sets a key/value pair in the payload.
 * @author John Clark.
 */
public class SetStep implements Step {

    /**
     * The key.
     */
    private String key;

    /**
     * The value.
     */
    private Object value;

    /**
     * Create a new Set Step.
     * @param payloadKey The key.
     * @param payloadValue The value.
     */
    public SetStep(String payloadKey, Object payloadValue) {
        key = payloadKey;
        value = payloadValue;
    }

    /**
     * Create a new Set Step from a parameters object.
     * @param parameters The parameter object.
     */
    public SetStep(Map<String, Object> parameters) {
        if (parameters == null || !parameters.containsKey("key") || !parameters.containsKey("value")) {
            throw new NPipesException("Invalid parameters for set step");
        }

        Object keyObj = parameters.get("key");
        if (keyObj instanceof String) {
            key = (String) keyObj;
        } else {
            throw new NPipesException("set step requires a valid key");
        }

        value = parameters.get("value");
    }

    @Override
    public ArrayList<Traversal> execute(Traversal traversal, VGraph graph) {

        traversal.addToPayload(key, value);

        return null;
    }

    @Override
    public SerializableStep toSerializableStep() {
        HashMap<String, Object> parameters = new HashMap<>();
        parameters.put("key", key);
        parameters.put("value", value);
        return new SerializableStep("set", parameters);
    }

    /**
     * Get the key.
     * @return the key.
     */
    public String getKey() {
        return key;
    }

    /**
     * Get the value.
     * @return The value.
     */
    public Object getValue() {
        return value;
    }
}

package com.github.trepo.npipes.step;

import com.github.trepo.npipes.NPipesException;
import com.github.trepo.npipes.Status;
import com.github.trepo.npipes.Step;
import com.github.trepo.npipes.Traversal;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.Direction;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Travel to adjacent nodes filtered (optionally) by one or more labels.
 * @author John Clark.
 */
public class OutStep implements Step {

    /**
     * The array of labels to filter the edge by.
     */
    private String[] labels;

    /**
     * Create a new Out Step.
     * @param edgeLabels The edge labels to filter by.
     */
    public OutStep(String... edgeLabels) {
        labels = edgeLabels;
    }

    /**
     * Create a new Out Step from a parameters object.
     * @param parameters The parameter object.
     */
    public OutStep(Map<String, Object> parameters) {
        if (parameters == null || !parameters.containsKey("labels")) {
            throw new NPipesException("Invalid parameters for out step");
        }

        Object labelObj = parameters.get("labels");
        if (labelObj instanceof String[]) {
            labels = (String[]) labelObj;
        } else if (labelObj instanceof ArrayList) {
            ArrayList<String> newList = new ArrayList<>();
            for (Object obj: (ArrayList) labelObj) {
                if (obj instanceof String) {
                    newList.add((String) obj);
                } else {
                    throw new NPipesException("Invalid label for out step");
                }
            }
            labels = newList.toArray(new String[newList.size()]);
        }
    }

    @Override
    public ArrayList<Traversal> execute(Traversal traversal, VGraph graph) {
        Node node = null;

        // Get current element. If not node, error.
        if (traversal.getCurrentElement() instanceof Node) {
            node = (Node) traversal.getCurrentElement();
        }
        if (node == null) {
            traversal.setStatus(Status.INVALID_STATE);
            return null;
        }

        // Get all edges coming in, optionally filtered by the list of labels
        int num = 0;
        Edge firstEdge = null;
        ArrayList<Traversal> newTraversals = new ArrayList<>();
        Node inNode;
        for (Edge edge: node.getEdges(Direction.OUT, labels)) {
            num++;
            // If first edge, just save a reference so we can clone correctly
            if (num == 1) {
                firstEdge = edge;
            } else {
                // For each edge, clone traversal (in pre-step state) and add to return.
                Traversal newTraversal = traversal.copy();

                newTraversal.addToPath(edge, graph.info().getRepo());
                inNode = edge.getNode(Direction.IN);
                newTraversal.addToPath(inNode, inNode.getRepo());
                if (inNode.isBoundary()) {
                    newTraversal.setStatus(Status.BOUNDARY);
                } else {
                    newTraversal.setCurrentElement(inNode);
                }

                newTraversals.add(newTraversal);
            }

        }
        // If we had at least one edge, update path and current element
        if (firstEdge != null) {
            traversal.addToPath(firstEdge, graph.info().getRepo());
            inNode = firstEdge.getNode(Direction.IN);
            traversal.addToPath(inNode, inNode.getRepo());
            if (inNode.isBoundary()) {
                traversal.setCurrentElement(null);
                traversal.setStatus(Status.BOUNDARY);
            } else {
                traversal.setCurrentElement(inNode);
            }
        } else {
            // Else, end traversal
            if (traversal.getStep() >= traversal.getSteps().size()) {
                traversal.setStatus(Status.FINISHED);
            } else {
                traversal.setStatus(Status.DONE);
            }
            return null;
        }

        return newTraversals;
    }

    @Override
    public SerializableStep toSerializableStep() {
        HashMap<String, Object> parameters = new HashMap<>();
        parameters.put("labels", labels);
        return new SerializableStep("out", parameters);
    }

    /**
     * Get labels.
     * @return The labels.
     */
    public String[] getLabels() {
        return labels;
    }
}

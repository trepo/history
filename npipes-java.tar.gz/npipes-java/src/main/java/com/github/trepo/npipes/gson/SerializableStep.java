package com.github.trepo.npipes.gson;

import java.util.Map;

/**
 * A special Serializable Step used to serialize/deserialize Steps.
 * @author John Clark.
 */
public class SerializableStep {

    /**
     * The name of the Step.
     */
    private String name;

    /**
     * The Step parameters.
     */
    private Map<String, Object> parameters;

    /**
     * Create an empty Serializable Step.
     */
    public SerializableStep() {

    }

    /**
     * Create a new Serializable Step.
     * @param stepName The step name.
     * @param stepParameters The step parameters.
     */
    public SerializableStep(String stepName, Map<String, Object> stepParameters) {
        name = stepName;
        parameters = stepParameters;
    }

    /**
     * Get the Step Name.
     * @return The Step Name.
     */
    public String getName() {
        return name;
    }

    /**
     * Set the Step Name.
     * @param stepName The Step Name.
     */
    public void setName(String stepName) {
        name = stepName;
    }

    /**
     * Get the Step Parameters.
     * @return The Step Parameters.
     */
    public Map<String, Object> getParameters() {
        return parameters;
    }

    /**
     * Set the Step Parameters.
     * @param stepParameters The Step Parameters.
     */
    public void setParameters(Map<String, Object> stepParameters) {
        parameters = stepParameters;
    }
}

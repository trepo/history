package com.github.trepo.npipes;

/**
 * Traversal Status Codes.
 * @author John Clark.
 */
public enum Status {

    /**
     * A Undefined Status.
     */
    OTHER(0, "Other"),

    /**
     * The Traversal is Running.
     */
    RUNNING(10, "Running"),

    /**
     * The Traversal is Paused.
     */
    PAUSED(11, "Paused"),

    /**
     * The Traversal completed and executed all steps.
     */
    FINISHED(20, "Finished"),

    /**
     * The Traversal completed and did not execute all steps.
     */
    DONE(21, "Done"),

    /**
     * The Traversal encountered a boundary node and needs to resume in another repository.
     */
    BOUNDARY(30, "Boundary"),

    /**
     * The Traversal backtracked and needs to resume in another repository.
     */
    BACKTRACK(30, "BackTrack"),

    /**
     * The traversal encountered a remote error.
     */
    REMOTE_ERROR(40, "Remote Error"),

    /**
     * The Traversal attempted to continue a traversal remotely but did not have sufficient permissions.
     */
    UNAUTHORIZED(41, "Unauthorized"),

    /**
     * There was a Traversal error.
     */
    TRAVERSAL_ERROR(50, "Traversal Error"),

    /**
     * The Traversal encountered an invalid state.
     */
    INVALID_STATE(51, "Invalid State"),

    /**
     * The Traversal timed out.
     */
    TIMEOUT(52, "Timeout"),

    /**
     * The Traversal encountered a missing element.
     */
    MISSING_ELEMENT(53, "Missing Element");

    /**
     * The Status Code.
     */
    private final int code;

    /**
     * The Status Code Reason Phrase.
     */
    private final String reason;

    /**
     * The Class or Group the Code belongs to.
     */
    private final Family family;

    /**
     * The Class or Group the Code belongs to.
     */
    public enum Family {EXECUTING, COMPLETE, REDIRECTION, REMOTE_ERROR, TRAVERSAL_ERROR, OTHER}

    /**
     * Create a Status Code.
     * @param statusCode The Status Code.
     * @param reasonPhrase The Reason Phrase.
     */
    Status(final int statusCode, final String reasonPhrase) {
        code = statusCode;
        reason = reasonPhrase;
        switch (code/10) {
            case 1:
                family = Family.EXECUTING;
                break;
            case 2:
                family = Family.COMPLETE;
                break;
            case 3:
                family = Family.REDIRECTION;
                break;
            case 4:
                family = Family.REMOTE_ERROR;
                break;
            case 5:
                family = Family.TRAVERSAL_ERROR;
                break;
            default:
                family = Family.OTHER;
        }
    }

    /**
     * Get the Status Code.
     * @return The Status Code.
     */
    public int getStatusCode() {
        return code;
    }

    /**
     * Get the Reason Phrase.
     * @return The Reason Phrase.
     */
    public String getReasonPhrase() {
        return reason;
    }

    /**
     * Get the Class or Group of the Status Code.
     * @return The Class or Group of the Status Code.
     */
    public Family getFamily() {
        return family;
    }

    /**
     * Get the reason phrase.
     * @return The reason phrase.
     */
    @Override
    public String toString() {
        return reason;
    }

    /**
     * Convert a numerical status code into the corresponding Status.
     * @param statusCode The numerical status code.
     * @return The matching Status or null is no matching Status is defined.
     */
    public static Status fromStatusCode(final int statusCode) {
        for (Status s : Status.values()) {
            if (s.code == statusCode) {
                return s;
            }
        }
        return null;
    }
}

package com.github.trepo.npipes;

import com.github.trepo.vgraph.SpecialProperty;

import java.util.HashSet;

/**
 * @author John Clark.
 */
public class PathElement {

    /**
     * The element's ID.
     */
    private String id;

    /**
     * The element's type.
     */
    private PathElementType type;

    /**
     * The element's repo.
     */
    private String repo;

    /**
     * The element's marker set.
     */
    private HashSet<String> markers;

    /**
     * Empty constructor for serialization.
     */
    public PathElement() {

    }

    /**
     * Create a new path element.
     * @param elementId The element's id.
     * @param elementType The element's type.
     * @param elementRepo the element's repository identifier.
     */
    public PathElement(String elementId, PathElementType elementType, String elementRepo) {
        id = elementId;
        type = elementType;
        repo = elementRepo;
        markers = new HashSet<>();
    }

    /**
     * Create a new path element.
     * @param elementId The element's id.
     * @param elementType The element's type.
     * @param elementRepo The element's repository identifier.
     * @param elementMarkers The element's markers.
     */
    public PathElement(String elementId, PathElementType elementType, String elementRepo, HashSet<String> elementMarkers) {
        id = elementId;
        type = elementType;
        repo = elementRepo;
        markers = elementMarkers;
    }

    /**
     * Validate this path element.
     */
    public void validate() {
        if (!SpecialProperty.isValidId(id)) {
            throw new NPipesException("invalid id");
        }
        if (type == null) {
            throw new NPipesException("invalid type");
        }
        if (repo == null) {
            throw new NPipesException("invalid repo");
        }
        if (markers == null) {
            throw new NPipesException("invalid markers");
        }
    }

    /**
     * Return a new copy of the PathElement.
     * @return The new PathElement.
     */
    public PathElement copy() {
        return new PathElement(id, type, repo, new HashSet<>(markers));
    }

    /**
     * Get the id.
     * @return The id.
     */
    public String getId() {
        return id;
    }

    /**
     * Set the id.
     * @param elementId The id.
     */
    public void setId(String elementId) {
        id = elementId;
    }

    /**
     * Get the type.
     * @return The type.
     */
    public PathElementType getType() {
        return type;
    }

    /**
     * Set the type.
     * @param elementType The type.
     */
    public void setType(PathElementType elementType) {
        type = elementType;
    }

    /**
     * Get the repo.
     * @return The repo.
     */
    public String getRepo() {
        return repo;
    }

    /**
     * Set the repo.
     * @param elementRepo The repo.
     */
    public void setRepo(String elementRepo) {
        repo = elementRepo;
    }

    /**
     * Get the markers.
     * @return The markers.
     */
    public HashSet<String> getMarkers() {
        return markers;
    }

    /**
     * Set the markers.
     * @param elementMarkers The markers.
     */
    public void setMarkers(HashSet<String> elementMarkers) {
        markers = elementMarkers;
    }

    /**
     * Check if this element contains the marker.
     * @param marker The marker.
     * @return true if markers contains the marker.
     */
    public boolean hasMarker(String marker) {
        return markers.contains(marker);
    }

    /**
     * Add a marker to the markers.
     * @param marker The marker.
     */
    public void addMarker(String marker) {
        markers.add(marker);
    }
}

package com.github.trepo.npipes.step;

import com.github.trepo.npipes.NPipesException;
import com.github.trepo.npipes.Status;
import com.github.trepo.npipes.Step;
import com.github.trepo.npipes.Traversal;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.Element;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Stores a property from the current element in the traversal's payload.
 * @author John Clark.
 */
public class StoreStep implements Step {

    /**
     * The property key.
     */
    private String property;

    /**
     * The payload key.
     */
    private String payload;

    /**
     * Create a new store step.
     * @param propertyKey The property key.
     * @param payloadKey The payload key.
     */
    public StoreStep(String propertyKey, String payloadKey) {
        this.property = propertyKey;
        this.payload = payloadKey;
    }

    /**
     * Create a new Store Step from a parameters object.
     * @param parameters The parameter object.
     */
    public StoreStep(Map<String, Object> parameters) {
        if (parameters == null || !parameters.containsKey("property") || !parameters.containsKey("payload")) {
            throw new NPipesException("Invalid parameters for store step");
        }

        Object propertyObj = parameters.get("property");
        if (propertyObj instanceof String) {
            property = (String) propertyObj;
            // TODO make sure property is a vailid regular or special property
        } else {
            throw new NPipesException("store step requires a valid property");
        }

        Object payloadObj = parameters.get("payload");
        if (payloadObj instanceof String) {
            payload = (String) payloadObj;
        } else {
            throw new NPipesException("store step requires a valid payload");
        }
    }

    @Override
    public ArrayList<Traversal> execute(Traversal traversal, VGraph graph) {

        Element element = traversal.getCurrentElement();

        if (element == null) {
            traversal.setStatus(Status.INVALID_STATE);
            return null;
        }

        switch(property) {
            case SpecialProperty.ID:
                traversal.addToPayload(payload, element.getId());
                break;
            case SpecialProperty.LABEL:
                traversal.addToPayload(payload, element.getLabel());
                break;
            case SpecialProperty.REPO:
                if (element instanceof Node) {
                    traversal.addToPayload(payload, ((Node) element).getRepo());
                } else {
                    traversal.addToPayload(payload, graph.info().getRepo());
                }
                break;
            default:
                traversal.addToPayload(payload, element.getProperty(property));
        }

        return null;
    }

    @Override
    public SerializableStep toSerializableStep() {
        HashMap<String, Object> parameters = new HashMap<>();
        parameters.put("property", property);
        parameters.put("payload", payload);
        return new SerializableStep("store", parameters);
    }

    /**
     * Get the property key.
     * @return The property key.
     */
    public String getProperty() {
        return property;
    }

    /**
     * Get the payload key.
     * @return The payload key.
     */
    public String getPayload() {
        return payload;
    }
}

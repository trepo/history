package com.github.trepo.npipes.rest;

import com.github.trepo.npipes.NPipesException;
import com.github.trepo.npipes.Step;
import com.github.trepo.npipes.gson.StepTypeAdapter;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.VGraphException;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.inject.Inject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author John Clark.
 */
@Path("/query")
public class Query {

    /**
     * Our injected graph instance.
     */
    private VGraph graph;

    /**
     * Run a nPipes Query.
     * @param query The query.
     * @return The executed query.
     */
    @POST
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response post(com.github.trepo.npipes.Query query) {
        try {
            query.validate();
        } catch (NPipesException e) {
            throw new WebApplicationException("Invalid request: " + e.getMessage(), e,
                    Response.Status.BAD_REQUEST);
        }

        query.execute(getGraph());
        return Response
                .status(Response.Status.OK)
                .entity(query)
                .build();

    }

    /**
     * Sets the vGraph instance to use via Injection.
     * @param graphInstance The vGraph instance.
     */
    @Inject
    public void setGraph(VGraph graphInstance) {
        graph = graphInstance;
    }

    /**
     * Get our vGraph instance.
     * @return The vGraph instance.
     */
    public VGraph getGraph() {
        return graph;
    }
}

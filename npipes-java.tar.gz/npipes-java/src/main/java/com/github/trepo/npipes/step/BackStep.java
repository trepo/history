package com.github.trepo.npipes.step;

import com.github.trepo.npipes.*;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.VGraph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Unwind the traversal back to the Element identified by Marker.
 * @author John Clark.
 */
public class BackStep implements Step {

    /**
     * The marker.
     */
    private String marker;

    /**
     * Create a new Back Step.
     * @param elementMarker The element marker.
     */
    public BackStep(String elementMarker) {
        marker = elementMarker;
    }

    /**
     * Create a new Back Step from a parameters object.
     * @param parameters The parameter object.
     */
    public BackStep(Map<String, Object> parameters) {
        if (parameters == null || !parameters.containsKey("marker")) {
            throw new NPipesException("Invalid parameters for back step");
        }

        Object markerObj = parameters.get("marker");
        if (markerObj instanceof String) {
            marker = (String) markerObj;
        } else {
            throw new NPipesException("back step requires a marker value");
        }
    }

    @Override
    public ArrayList<Traversal> execute(Traversal traversal, VGraph graph) {

        // Find marker in the path
        ArrayList<PathElement> path = traversal.getPath();
        int index = -1;
        for (int i = path.size() - 1; i >= 0; i--) {
            if (path.get(i).hasMarker(marker)) {
                index = i;
                break;
            }
        }

        // If marker does not exist, error
        if (index == -1) {
            traversal.setStatus(Status.INVALID_STATE);
            return null;
        }

        // Rewind Path
        //http://stackoverflow.com/a/2289191/1486397
        path.subList(index + 1, path.size()).clear();

        // Set currentElement
        PathElement lastPathElement = path.get(path.size() - 1);
        // If new last step is in this repo, set currentElement
        if (lastPathElement.getRepo().equals(graph.info().getRepo())) {
            if (lastPathElement.getType() == PathElementType.EDGE) {
                traversal.setCurrentElement(graph.getEdge(lastPathElement.getId()));
            } else {
                traversal.setCurrentElement(graph.getNode(lastPathElement.getId()));
            }
        } else {
            traversal.setCurrentElement(null);
            traversal.setStatus(Status.BACKTRACK);
        }

        return null;
    }

    @Override
    public SerializableStep toSerializableStep() {
        HashMap<String, Object> parameters = new HashMap<>();
        parameters.put("marker", marker);
        return new SerializableStep("back", parameters);
    }

    /**
     * Get the marker.
     * @return The marker.
     */
    public String getMarker() {
        return marker;
    }
}

package com.github.trepo.npipes;

import com.github.trepo.vgraph.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.UUID;

/**
 * @author John Clark.
 */
public class Traversal {

    /**
     * The current element.
     */
    private transient Element currentElement;

    /**
     * The id of this traversal.
     */
    private String id;

    /**
     * The traversal's path.
     */
    private ArrayList<PathElement> path;

    /**
     * The traversal's payload.
     */
    private HashMap<String, Object> payload;

    /**
     * The set of steps to execute.
     */
    private ArrayList<Step> steps;

    /**
     * The current step to execute.
     */
    private Integer step;

    /**
     * The status of this traversal.
     */
    private Status status;

    /**
     * An empty constructor so we can deserialize.
     */
    public Traversal() {

    }

    /**
     * Create a new traversal with the supplied steps.
     * @param traversalSteps The steps to use.
     */
    public Traversal(ArrayList<Step> traversalSteps) {
        id = UUID.randomUUID().toString();
        path = new ArrayList<>();
        payload = new HashMap<>();
        steps = traversalSteps;
        step = 0;
        status = Status.RUNNING;
    }

    /**
     * Validate this traversal.
     */
    public void validate() {

        // Check ID
        if (!SpecialProperty.isValidId(id)) {
            throw new NPipesException("invalid id");
        }

        // Check Path
        if (path == null) {
            throw new NPipesException("invalid path");
        }
        for (int i = 0; i < path.size(); i++) {
            try {
                path.get(i).validate();
            } catch (NPipesException e) {
                throw new NPipesException("invalid path element " + i + ": " + e.getMessage());
            }
        }

        // Check Payload
        if (payload == null) {
            throw new NPipesException("invalid payload");
        }

        // Check Steps
        if (steps == null) {
            throw new NPipesException("invalid steps");
        }

        // Check Step
        if (step == null || step < 0 || step > steps.size()) {
            throw new NPipesException("invalid step");
        }

        // Check Status
        if (status == null) {
            throw new NPipesException("invalid status");
        }
    }

    /**
     * Execute this traversal as far as we can and return any
     * newly generated traversals NOT including this one.
     * @param graph The graph to execute this traversal in.
     * @return A list of newly created traversals.
     */
    public ArrayList<Traversal> execute(VGraph graph) {

        ArrayList<Traversal> newTraversals = new ArrayList<>();

        // Get and set the current element to last element in path (if any).
        if (!path.isEmpty()) {
            PathElement lastPathElement = path.get(path.size() - 1);
            if (lastPathElement.getType() == PathElementType.EDGE) {
                currentElement = graph.getEdge(lastPathElement.getId());
            } else {
                currentElement = graph.getNode(lastPathElement.getId());
            }

            // If current element is null, error
            if (currentElement == null) {
                setStatus(Status.MISSING_ELEMENT);
                return newTraversals;
            }

            if (currentElement instanceof Node) {
                Node currentNode = (Node) currentElement;

                // If current element is a boundary, add to path and pause
                // Happens when a boundary in repo1 points to a boundary in repo2 which points to a node in repo3
                if (currentNode.isBoundary()) {
                    addToPath(currentNode, currentNode.getRepo());
                    setStatus(Status.BOUNDARY);
                    return newTraversals;
                }
                // If lastPathElement is a boundary and currentElement is a node, add to path
                // Happens when a boundary in repo1 points to a node in repo2
                if (lastPathElement.getType() == PathElementType.BOUNDARY) {
                    addToPath(currentNode, currentNode.getRepo());
                }
            }
        }

        // While our status is running and there are steps left, execute steps.
        for (; step < steps.size(); ) {
            if (status != Status.RUNNING) {
                break;
            }
            step++; // Step will always point to the next step when executing a step.
            ArrayList<Traversal> returnedTraversals = steps.get(step-1).execute(this, graph);
            if (returnedTraversals != null) {
                newTraversals.addAll(returnedTraversals);
            }
        }

        // If we finished all our steps, mark this traversal as complete.
        if (status == Status.RUNNING && step == steps.size()) {
            setStatus(Status.FINISHED);
        }

        return newTraversals;
    }

    /**
     * Copy this traversal.
     * @return A copy of this traversal with a new ID.
     */
    public Traversal copy() {
        Traversal newTraversal = new Traversal();
        newTraversal.setId(UUID.randomUUID().toString());
        ArrayList<PathElement> newPath = new ArrayList<>();
        for(PathElement elem: path) {
            newPath.add(elem.copy());
        }
        newTraversal.setPath(newPath);
        newTraversal.setPayload(new HashMap<>(payload)); // TODO Do we need a deep copy?
        newTraversal.setSteps(new ArrayList<>(steps)); // No need for a deep copy
        newTraversal.setStep(step);
        newTraversal.setStatus(status);

        return newTraversal;
    }

    /**
     * Add the edge to the path.
     * @param edge The edge to add.
     * @param repo The repo to use.
     * @return This traversal.
     */
    public Traversal addToPath(Edge edge, String repo) {
        return addToPath(edge.getId(), PathElementType.getType(edge), repo);
    }

    /**
     * Add the node to the path.
     * @param node The node to add.
     * @param repo the repo to use.
     * @return This traversal.
     */
    public Traversal addToPath(Node node, String repo) {
        return addToPath(node.getId(), PathElementType.getType(node), repo);
    }

    /**
     * Add a PathElement to the path.
     * @param elementId The element id.
     * @param elementType The element type.
     * @param elementRepo The element repo.
     * @return This traversal.
     */
    public Traversal addToPath(String elementId, PathElementType elementType, String elementRepo) {
        path.add(new PathElement(elementId, elementType, elementRepo));
        return this;
    }

    /**
     * Add a key/value pair to the payload.
     * @param key The key.
     * @param value The value
     * @return This traversal.
     */
    public Traversal addToPayload(String key, Object value) {
        payload.put(key, value);
        return this;
    }

    /**
     * Get a value from the payload. If casting fails, will return null.
     * @param key The payload key.
     * @param clazz The Class to cast to.
     * @param <T> The type.
     * @return The payload value for key cast to clazz Type, or null.
     */
    public <T> T getFromPayload(String key, Class<T> clazz) {
        try {
            return clazz.cast(payload.get(key));
        } catch(ClassCastException e) {
            return null;
        }
    }

    /**
     * Get the current element.
     * @return The current element.
     */
    public Element getCurrentElement() {
        return currentElement;
    }

    /**
     * Set the current element.
     * @param newElement The new current element.
     */
    public void setCurrentElement(Element newElement) {
        currentElement = newElement;
    }

    /**
     * Get the traversal id.
     * @return The traversal id.
     */
    public String getId() {
        return id;
    }

    /**
     * Set the traversal id.
     * @param traversalId The traversal id
     */
    public void setId(String traversalId) {
        id = traversalId;
    }

    /**
     * Get the traversal's path.
     * @return The path.
     */
    public ArrayList<PathElement> getPath() {
        return path;
    }

    /**
     * Set the traversal path.
     * @param newPath The path.
     */
    public void setPath(ArrayList<PathElement> newPath) {
        this.path = newPath;
    }

    /**
     * Get the traversal's payload.
     * @return The payload.
     */
    public HashMap<String, Object> getPayload() {
        return payload;
    }

    /**
     * Set the traversal's payload.
     * @param newPayload The payload.
     */
    public void setPayload(HashMap<String, Object> newPayload) {
        payload = newPayload;
    }

    /**
     * Get the traversal's steps.
     * @return The steps.
     */
    public ArrayList<Step> getSteps() {
        return steps;
    }

    /**
     * Set the traversal's steps.
     * @param newSteps The steps.
     */
    public void setSteps(ArrayList<Step> newSteps) {
        steps = newSteps;
    }

    /**
     * Get the current step number.
     * @return The step.
     */
    public Integer getStep() {
        return step;
    }

    /**
     * Set the current step.
     * @param newStep The current step.
     */
    public void setStep(Integer newStep) {
        this.step = newStep;
    }

    /**
     * Get the traversal status.
     * @return The status.
     */
    public Status getStatus() {
        return status;
    }

    /**
     * Set the traversal status.
     * @param status The status.
     */
    public void setStatus(Status status) {
        this.status = status;
    }
}

package com.github.trepo.npipes;

import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.VGraph;

import java.util.ArrayList;

/**
 * A general Step.
 * @author John Clark.
 */
public interface Step {

    /**
     * Execute this step.
     * @param traversal The traversal reference.
     * @param graph The graph reference.
     * @return A list of new Traversals if branching, null otherwise.
     */
    ArrayList<Traversal> execute(Traversal traversal, VGraph graph);

    /**
     * Convert this step to a serializable step.
     * @return The SerializableStep.
     */
    SerializableStep toSerializableStep();
}

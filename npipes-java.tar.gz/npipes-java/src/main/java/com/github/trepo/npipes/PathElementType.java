package com.github.trepo.npipes;

import com.github.trepo.vgraph.Boundary;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Element;
import com.github.trepo.vgraph.Node;

/**
 * The type of the path element.
 * @author John Clark.
 */
public enum PathElementType {

    /**
     * vGraph Node.
     */
    NODE ("node"),

    /**
     * vGraph Boundary Node.
     */
    BOUNDARY ("boundary"),

    /**
     * vGraph Edge.
     */
    EDGE ("edge");

    /**
     * The Type.
     */
    private final String type;

    /**
     * Create a new PathElementType.
     * @param elementType The type.
     */
    private PathElementType(String elementType) {
        type = elementType;
    }

    /**
     * Get the type.
     * @return The type.
     */
    public String getTypeString() {
        return type;
    }

    /**
     * Gets the PathElementType for a given vGraph element.
     * @param e The vGraph element.
     * @return The PathElementType.
     */
    public static PathElementType getType(Element e) {
        if (e instanceof Boundary) {
            return PathElementType.BOUNDARY;
        } else if (e instanceof Node) {
            return PathElementType.NODE;
        } else if (e instanceof Edge) {
            return PathElementType.EDGE;
        } else {
            throw new IllegalArgumentException("Unknown Type");
        }
    }
}

package com.github.trepo.npipes.step;

import com.github.trepo.npipes.NPipesException;
import com.github.trepo.npipes.Status;
import com.github.trepo.npipes.Step;
import com.github.trepo.npipes.Traversal;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Gets the specified Node.
 * @author John Clark.
 */
public class NodeStep implements Step {

    /**
     * The id of the node to go to.
     */
    private String id;

    /**
     * Create a new vertex step.
     * @param nodeId The node id.
     */
    public NodeStep(String nodeId) {
        id = nodeId;
    }

    /**
     * Create a new Vertex Step from a parameters object.
     * @param parameters The parameter object.
     */
    public NodeStep(Map<String, Object> parameters) {
        if (parameters == null || !parameters.containsKey("id")) {
            throw new NPipesException("Invalid parameters for vertex step");
        }

        Object idObj = parameters.get("id");
        if (idObj instanceof String) {
            id = (String) idObj;
        } else {
            throw new NPipesException("vertex step requires an id value");
        }
    }

    @Override
    public ArrayList<Traversal> execute(Traversal traversal, VGraph graph) {

        Node node = graph.getNode(id);

        if (node == null) {
            traversal.setStatus(Status.MISSING_ELEMENT);
            return null;
        }

        // Append to path
        traversal.addToPath(node, node.getRepo());

        // If node is a boundary, set status, else update current element
        if (node.isBoundary()) {
            traversal.setStatus(Status.BOUNDARY);
        } else {
            traversal.setCurrentElement(node);
        }

        return null;
    }

    @Override
    public SerializableStep toSerializableStep() {
        HashMap<String, Object> parameters = new HashMap<>();
        parameters.put("id", id);
        return new SerializableStep("n", parameters);
    }

    /**
     * Get the requested vertex id.
     * @return The id.
     */
    public String getId() {
        return id;
    }
}

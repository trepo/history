package com.github.trepo.npipes;

import com.github.trepo.vgraph.VGraph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;

/**
 * @author John Clark.
 */
public class Query {

    /**
     * The current list of traversals.
     */
    private HashMap<String, Traversal> traversals;

    /**
     * Create a new Query.
     */
    public Query() {
        traversals = new HashMap<>();
    }

    /**
     * Create a new Query using the passed in Traversals.
     * @param t The Traversals.
     */
    public Query(HashMap<String, Traversal> t) {
        traversals = t;
    }

    /**
     * Add a traversal to traversals.
     * @param traversal The traversal to add.
     * @return This Query.
     */
    public Query addTraversal(Traversal traversal) {
        traversals.put(traversal.getId(), traversal);
        return this;
    }

    /**
     * Get the traversals.
     * @return The traversals.
     */
    public HashMap<String, Traversal> getTraversals() {
        return traversals;
    }

    /**
     * Executes all of the traversals with a running status.
     * @param graph The VGraph instance to use during execution.
     */
    public void execute(VGraph graph) {

        // Loop through and add traversals to the queue
        LinkedList<Traversal> traversalQueue = new LinkedList<>();
        for (Traversal traversal: traversals.values()) {
            if (traversal.getStatus() == Status.RUNNING) {
                traversalQueue.add(traversal);
            }
        }

        // execute traversals until we are done
        while (!traversalQueue.isEmpty()) {
            Traversal currentTraversal = traversalQueue.remove();

            ArrayList<Traversal> newTraversals = currentTraversal.execute(graph);

            // Add new traversals to queue and final return
            for (Traversal traversal: newTraversals) {
                traversalQueue.add(traversal);
                traversals.put(traversal.getId(), traversal);
            }
        }

    }

    public void validate() {
        for (Traversal traversal: traversals.values()) {
            try {
                traversal.validate();
            } catch (NPipesException e) {
                throw new NPipesException("invalid traversal " + traversal.getId() + ": " + e.getMessage());
            }
        }
    }
}

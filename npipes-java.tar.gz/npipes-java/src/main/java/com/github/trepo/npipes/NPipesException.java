package com.github.trepo.npipes;

/**
 * The base Exception class for nPipes.
 * @author John Clark.
 */
public class NPipesException extends RuntimeException {

    /**
     * Create a NPipesException.
     * @param s The message.
     */
    public NPipesException(String s) {
        super(s);
    }

    /**
     * Create a NPipesException.
     * @param s The message.
     * @param e The exception.
     */
    public NPipesException(String s, Exception e) {
        super(s, e);
    }
}

package com.github.trepo.npipes.gson;

import com.github.trepo.npipes.NPipesException;
import com.github.trepo.npipes.Step;
import com.github.trepo.npipes.step.*;
import com.google.gson.*;

import java.lang.reflect.Type;

/**
 * Serialize and Deserialize Steps using GSON.
 * Must be registered using registerTypeHierarchyAdapter so that all classes implementing Step use this adapter.
 * @author John Clark.
 */
public class StepTypeAdapter implements JsonSerializer<Step>, JsonDeserializer<Step> {
    @Override
    public Step deserialize(JsonElement jsonElement, Type type, JsonDeserializationContext context) throws JsonParseException {

        SerializableStep serializableStep = context.deserialize(jsonElement, SerializableStep.class);

        switch(serializableStep.getName()) {
            case "as":
                return new AsStep(serializableStep.getParameters());
            case "back":
                return new BackStep(serializableStep.getParameters());
            case "in":
                return new InStep(serializableStep.getParameters());
            case "out":
                return new OutStep(serializableStep.getParameters());
            case "set":
                return new SetStep(serializableStep.getParameters());
            case "store":
                return new StoreStep(serializableStep.getParameters());
            case "n":
                return new NodeStep(serializableStep.getParameters());
            default:
                throw new NPipesException("Invalid Step Name");
        }
    }

    @Override
    public JsonElement serialize(Step step, Type type, JsonSerializationContext context) {
        return context.serialize(step.toSerializableStep());
    }
}

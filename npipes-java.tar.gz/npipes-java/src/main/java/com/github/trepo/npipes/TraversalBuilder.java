package com.github.trepo.npipes;

import com.github.trepo.npipes.step.*;

import java.util.ArrayList;

/**
 * Build a new traversal.
 * @author John Clark.
 */
public class TraversalBuilder {

    /**
     * Our steps.
     */
    private ArrayList<Step> steps;

    /**
     * Create a new Traversal.
     */
    public TraversalBuilder() {
        steps = new ArrayList<>();
    }

    /**
     * Return a new Traversal using the steps so far.
     * @return A new Traversal.
     */
    public Traversal traversal() {
        return new Traversal(steps);
    }

    /**
     * Add an As Step
     * @param marker The marker.
     * @return The TraversalBuilder.
     */
    public TraversalBuilder as(String marker) {
        steps.add(new AsStep(marker));
        return this;
    }

    /**
     * Add a Back Step.
     * @param marker The marker.
     * @return The TraversalBuilder.
     */
    public TraversalBuilder back(String marker) {
        steps.add(new BackStep(marker));
        return this;
    }

    /**
     * Add an In Step.
     * @param labels The labels.
     * @return The TraversalBuilder.
     */
    public TraversalBuilder in(String... labels) {
        steps.add(new InStep(labels));
        return this;
    }

    /**
     * Add an Out Step.
     * @param labels The labels.
     * @return The TraversalBuilder.
     */
    public TraversalBuilder out(String... labels) {
        steps.add(new OutStep(labels));
        return this;
    }

    /**
     * Add a Set Step.
     * @param payloadKey The payload key.
     * @param payloadValue The payload value.
     * @return The TraversalBuilder.
     */
    public TraversalBuilder set(String payloadKey, Object payloadValue) {
        steps.add(new SetStep(payloadKey, payloadValue));
        return this;
    }

    /**
     * Add a Store Step.
     * @param propertyKey The property key.
     * @param payloadKey The payload key.
     * @return The TraversalBuilder.
     */
    public TraversalBuilder store(String propertyKey, String payloadKey) {
        steps.add(new StoreStep(propertyKey, payloadKey));
        return this;
    }

    /**
     * Add a Node Step.
     * @param id The node id.
     * @return The TraversalBuilder.
     */
    public TraversalBuilder n(String id) {
        steps.add(new NodeStep(id));
        return this;
    }

}

package com.github.trepo.npipes.step;

import com.github.trepo.npipes.*;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.VGraph;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

/**
 * Mark an Element with marker.
 * @author John Clark.
 */
public class AsStep implements Step {

    /**
     * The marker.
     */
    private String marker;

    /**
     * Create a new As Step.
     * @param elementMarker The element marker.
     */
    public AsStep(String elementMarker) {
        marker = elementMarker;
    }

    /**
     * Create a new As Step from a parameters object.
     * @param parameters The parameter object.
     */
    public AsStep(Map<String, Object> parameters) {
        if (parameters == null || !parameters.containsKey("marker")) {
            throw new NPipesException("Invalid parameters for as step");
        }

        Object markerObj = parameters.get("marker");
        if (markerObj instanceof String) {
            marker = (String) markerObj;
        } else {
            throw new NPipesException("as step requires a marker value");
        }
    }

    @Override
    public ArrayList<Traversal> execute(Traversal traversal, VGraph graph) {

        // Get last PathElement
        ArrayList<PathElement> path = traversal.getPath();
        if (path.isEmpty()) {
            traversal.setStatus(Status.INVALID_STATE);
            return null;
        }
        path.get(path.size() - 1).addMarker(marker);

        return null;
    }

    @Override
    public SerializableStep toSerializableStep() {
        HashMap<String, Object> parameters = new HashMap<>();
        parameters.put("marker", marker);
        return new SerializableStep("as", parameters);
    }

    /**
     * Get the marker.
     * @return The marker.
     */
    public String getMarker() {
        return marker;
    }
}

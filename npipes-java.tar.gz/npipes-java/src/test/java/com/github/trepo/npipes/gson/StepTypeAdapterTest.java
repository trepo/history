package com.github.trepo.npipes.gson;

import com.github.trepo.npipes.NPipesException;
import com.github.trepo.npipes.Step;
import com.github.trepo.npipes.step.*;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class StepTypeAdapterTest {
    Gson gson = new GsonBuilder()
            .registerTypeHierarchyAdapter(Step.class, new StepTypeAdapter())
            .create();

    /**
     * serialize
     */
    @Test
    public void serialize_shouldWork() {
        Step step = new AsStep("marker");

        String str = gson.toJson(step);

        assertThat(str.contains("\"name\":\"as\"")).isTrue();
        assertThat(str.contains("\"parameters\":{\"marker\":\"marker\"}")).isTrue();
    }

    /**
     * deserialize
     */
    @Test
    public void deserialize_asShouldWork() {
        String str = "{\"name\":\"as\",\"parameters\":{\"marker\":\"marker\"}}";

        Step step = gson.fromJson(str, Step.class);

        if (step instanceof AsStep) {
            AsStep castStep = (AsStep) step;
            assertThat(castStep.getMarker()).isEqualTo("marker");
        } else {
            fail("Step is not the correct type");
        }
    }

    @Test
    public void deserialize_backShouldWork() {
        String str = "{\"name\":\"back\",\"parameters\":{\"marker\":\"the marker\"}}";

        Step step = gson.fromJson(str, Step.class);

        if (step instanceof BackStep) {
            BackStep castStep = (BackStep) step;
            assertThat(castStep.getMarker()).isEqualTo("the marker");
        } else {
            fail("Step is not the correct type");
        }
    }

    @Test
    public void deserialize_inShouldWork() {
        String str = "{\"name\":\"in\",\"parameters\":{\"labels\":[\"label\"]}}";

        Step step = gson.fromJson(str, Step.class);

        if (step instanceof InStep) {
            InStep castStep = (InStep) step;
            assertThat(castStep.getLabels()).isEqualTo(new String[]{"label"});
        } else {
            fail("Step is not the correct type");
        }
    }

    @Test
    public void deserialize_outShouldWork() {
        String str = "{\"name\":\"out\",\"parameters\":{\"labels\":[\"label\"]}}";

        Step step = gson.fromJson(str, Step.class);

        if (step instanceof OutStep) {
            OutStep castStep = (OutStep) step;
            assertThat(castStep.getLabels()).isEqualTo(new String[]{"label"});
        } else {
            fail("Step is not the correct type");
        }
    }

    @Test
    public void deserialize_setShouldWork() {
        String str = "{\"name\":\"set\",\"parameters\":{\"key\":\"key\",\"value\":\"value\"}}";

        Step step = gson.fromJson(str, Step.class);

        if (step instanceof SetStep) {
            SetStep castStep = (SetStep) step;
            assertThat(castStep.getKey()).isEqualTo("key");
            assertThat(castStep.getValue()).isEqualTo("value");
        } else {
            fail("Step is not the correct type");
        }
    }

    @Test
    public void deserialize_storeShouldWork() {
        String str = "{\"name\":\"store\",\"parameters\":{\"property\":\"property\",\"payload\":\"payload\"}}";

        Step step = gson.fromJson(str, Step.class);

        if (step instanceof StoreStep) {
            StoreStep castStep = (StoreStep) step;
            assertThat(castStep.getProperty()).isEqualTo("property");
            assertThat(castStep.getPayload()).isEqualTo("payload");
        } else {
            fail("Step is not the correct type");
        }
    }

    @Test
    public void deserialize_vertexShouldWork() {
        String str = "{\"name\":\"n\",\"parameters\":{\"id\":\"id\"}}";

        Step step = gson.fromJson(str, Step.class);

        if (step instanceof NodeStep) {
            NodeStep castStep = (NodeStep) step;
            assertThat(castStep.getId()).isEqualTo("id");
        } else {
            fail("Step is not the correct type");
        }
    }

    @Test
    public void deserialize_invalidStepShouldFail() {
        String str = "{\"name\":\"bogus\",\"parameters\":{\"id\":\"id\"}}";

        try {
            gson.fromJson(str, Step.class);
            fail("Should have thrown an error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid Step Name");
        }
    }
}

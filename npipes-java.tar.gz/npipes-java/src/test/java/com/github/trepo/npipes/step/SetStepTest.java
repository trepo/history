package com.github.trepo.npipes.step;

import com.github.trepo.npipes.NPipesException;
import com.github.trepo.npipes.Step;
import com.github.trepo.npipes.Traversal;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class SetStepTest {
    private VGraph graph;
    private Traversal traversal;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        traversal = new Traversal(new ArrayList<Step>());
    }

    /**
     * constructor
     */
    @Test
    public void constructor_shouldWork() {
        Map<String, Object> parameters = null;


        try {
            new SetStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for set step");
        }

        parameters = new HashMap<>();
        parameters.put("value", "value");
        try {
            new SetStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for set step");
        }

        parameters = new HashMap<>();
        parameters.put("key", "key");
        try {
            new SetStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for set step");
        }

        parameters = new HashMap<>();
        parameters.put("key", new ArrayList<String>());
        parameters.put("value", "value");
        try {
            new SetStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("set step requires a valid key");
        }

        parameters = new HashMap<>();
        parameters.put("key", "key");
        parameters.put("value", new String[]{"one", "two", "three"});

        SetStep step = new SetStep(parameters);

        assertThat(step.getKey()).isEqualTo("key");
        assertThat(step.getValue()).isEqualTo(new String[]{"one", "two", "three"});
    }

    /**
     * getters
     */
    @Test
    public void getters_shouldWork() {

        SetStep step = new SetStep("key", "value");

        assertThat(step.getKey()).isEqualTo("key");
        assertThat(step.getValue()).isEqualTo("value");
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldWork() {

        SetStep step = new SetStep("key", "value");

        step.execute(traversal, graph);

        assertThat(traversal.getPayload().containsKey("key")).isTrue();
        assertThat(traversal.getPayload().get("key")).isEqualTo("value");
    }

    /**
     * toSerializableStep
     */
    @Test
    public void toSerializableStep_shouldWork() {
        SetStep step = new SetStep("key", "value");

        SerializableStep serializableStep = step.toSerializableStep();

        assertThat(serializableStep.getName()).isEqualTo("set");

        Map<String, Object> map = serializableStep.getParameters();

        assertThat(map.size()).isEqualTo(2);
        assertThat(map.get("key")).isEqualTo("key");
        assertThat(map.get("value")).isEqualTo("value");

    }
}

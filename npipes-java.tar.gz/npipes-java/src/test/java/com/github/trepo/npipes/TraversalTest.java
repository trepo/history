package com.github.trepo.npipes;

import com.github.trepo.npipes.step.*;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Fail.fail;

/**
 * @author John Clark.
 */
public class TraversalTest {

    private TinkerGraph tinkerGraph;
    private VGraph graph;
    private ArrayList<Step> steps;

    @BeforeMethod
    public void setup() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, "repo");
        steps = new ArrayList<>();
    }

    /**
     * constructors, getters, & setters
     */
    @Test
    public void constructors_getters_setters_shouldWork() {
        Traversal traversal = new Traversal();

        assertThat(traversal.getCurrentElement()).isNull();
        assertThat(traversal.getId()).isNull();
        assertThat(traversal.getPath()).isNull();
        assertThat(traversal.getPayload()).isNull();
        assertThat(traversal.getSteps()).isNull();
        assertThat(traversal.getStep()).isNull();
        assertThat(traversal.getStatus()).isNull();

        Node currentElement = graph.addNode("label");
        String id = "1234";
        ArrayList<PathElement> path = new ArrayList<>();
        path.add(new PathElement("5678", PathElementType.NODE, "repo"));
        HashMap<String, Object> payload = new HashMap<>();
        payload.put("key", "value");
        ArrayList<Step> steps = new ArrayList<>();
        steps.add(new NodeStep("1234"));
        steps.add(new StoreStep("key", "key"));
        Integer step = 1;

        traversal.setCurrentElement(currentElement);
        traversal.setId(id);
        traversal.setPath(path);
        traversal.setPayload(payload);
        traversal.setSteps(steps);
        traversal.setStep(step);
        traversal.setStatus(Status.BOUNDARY);

        assertThat(traversal.getCurrentElement()).isEqualTo(currentElement);
        assertThat(traversal.getId()).isEqualTo(id);
        assertThat(traversal.getPath()).isEqualTo(path);
        assertThat(traversal.getPayload()).isEqualTo(payload);
        assertThat(traversal.getSteps()).isEqualTo(steps);
        assertThat(traversal.getStep()).isEqualTo(step);
        assertThat(traversal.getStatus()).isEqualTo(Status.BOUNDARY);

        traversal = new Traversal(steps);

        assertThat(traversal.getCurrentElement()).isNull();
        assertThat(traversal.getId()).isNotNull();
        assertThat(traversal.getPath()).isEqualTo(new ArrayList<PathElement>());
        assertThat(traversal.getPayload()).isEqualTo(new HashMap<String, Object>());
        assertThat(traversal.getSteps()).isEqualTo(steps);
        assertThat(traversal.getStep()).isEqualTo(0);
        assertThat(traversal.getStatus()).isEqualTo(Status.RUNNING);
    }

    /**
     * copy
     */
    @Test
    public void copy_shouldWork() {
        Traversal traversal = new Traversal();

        Node currentElement = graph.addNode("label");
        String id = "1234";
        ArrayList<PathElement> path = new ArrayList<>();
        path.add(new PathElement("5678", PathElementType.NODE, "repo"));
        HashMap<String, Object> payload = new HashMap<>();
        payload.put("key", "value");
        ArrayList<Step> steps = new ArrayList<>();
        steps.add(new NodeStep("1234"));
        steps.add(new StoreStep("key", "key"));
        Integer step = 1;

        traversal.setCurrentElement(currentElement);
        traversal.setId(id);
        traversal.setPath(path);
        traversal.setPayload(payload);
        traversal.setSteps(steps);
        traversal.setStep(step);
        traversal.setStatus(Status.BACKTRACK);

        Traversal newTraversal = traversal.copy();

        assertThat(newTraversal.getCurrentElement()).isNull();
        assertThat(newTraversal.getId()).isNotEqualTo(id);
        assertThat(newTraversal.getPath().size()).isEqualTo(1);
        assertThat(newTraversal.getPayload().containsKey("key")).isTrue();
        assertThat(newTraversal.getSteps().size()).isEqualTo(2);
        assertThat(newTraversal.getStep()).isEqualTo(step);
        assertThat(newTraversal.getStatus()).isEqualTo(Status.BACKTRACK);
    }

    /**
     * addToPath
     */
    @Test
    public void addToPath_Edge_shouldWork() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "label");

        Traversal traversal = new Traversal(new ArrayList<Step>());

        traversal.addToPath(edge, "repo");

        assertThat(traversal.getPath().size()).isEqualTo(1);
        PathElement pathElement = traversal.getPath().get(0);
        assertThat(pathElement.getId()).isEqualTo(edge.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.EDGE);
        assertThat(pathElement.getRepo()).isEqualTo("repo");
        assertThat(pathElement.getMarkers()).isEqualTo(new HashSet<String>());
    }

    @Test
    public void addToPath_Node_shouldWork() {
        Node node = graph.addNode("label");

        Traversal traversal = new Traversal(new ArrayList<Step>());

        traversal.addToPath(node, "repo");

        assertThat(traversal.getPath().size()).isEqualTo(1);
        PathElement pathElement = traversal.getPath().get(0);
        assertThat(pathElement.getId()).isEqualTo(node.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.NODE);
        assertThat(pathElement.getRepo()).isEqualTo("repo");
        assertThat(pathElement.getMarkers()).isEqualTo(new HashSet<String>());
    }

    @Test
    public void addToPath_Boundary_shouldWork() {
        String boundaryId = SpecialProperty.generateId();
        Vertex v = tinkerGraph.addVertex(boundaryId);
        v.setProperty(SpecialProperty.ID, boundaryId);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "externalRepo");
        Node node = graph.getNode(boundaryId);

        Traversal traversal = new Traversal(new ArrayList<Step>());

        traversal.addToPath(node, "externalRepo");

        assertThat(traversal.getPath().size()).isEqualTo(1);
        PathElement pathElement = traversal.getPath().get(0);
        assertThat(pathElement.getId()).isEqualTo(node.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.BOUNDARY);
        assertThat(pathElement.getRepo()).isEqualTo("externalRepo");
        assertThat(pathElement.getMarkers()).isEqualTo(new HashSet<String>());

    }

    @Test
    public void addToPath_Custom_shouldWork() {
        Traversal traversal = new Traversal(new ArrayList<Step>());

        traversal.addToPath("1234", PathElementType.NODE, "repo");

        assertThat(traversal.getPath().size()).isEqualTo(1);
        PathElement pathElement = traversal.getPath().get(0);
        assertThat(pathElement.getId()).isEqualTo("1234");
        assertThat(pathElement.getType()).isEqualTo(PathElementType.NODE);
        assertThat(pathElement.getRepo()).isEqualTo("repo");
        assertThat(pathElement.getMarkers()).isEqualTo(new HashSet<String>());
    }

    /**
     * addToPayload
     */
    @Test
    public void addToPayload_shouldWork() {
        Traversal traversal = new Traversal(new ArrayList<Step>());

        assertThat(traversal.getPayload().containsKey("key")).isFalse();

        traversal.addToPayload("key", "value");

        assertThat(traversal.getPayload().containsKey("key")).isTrue();
        assertThat(traversal.getPayload().get("key")).isEqualTo("value");
    }

    /**
     * getFromPayload
     */
    @Test
    public void getFromPayload_shouldWork() {
        Traversal traversal = new Traversal(new ArrayList<Step>());

        traversal.addToPayload("key", "value");

        assertThat(traversal.getFromPayload("key", String.class)).isEqualTo("value");
        assertThat(traversal.getFromPayload("key", Integer.class)).isNull();
        assertThat(traversal.getFromPayload("bogus key", String.class)).isNull();
    }

    /**
     * validate
     */
    @Test
    public void validate_shouldErrorOnInvalidId() {
        Traversal traversal = new Traversal();
        traversal.setId(null);
        traversal.setPath(new ArrayList<PathElement>());
        traversal.setPayload(new HashMap<String, Object>());
        traversal.setSteps(new ArrayList<Step>());
        traversal.setStep(0);
        traversal.setStatus(Status.RUNNING);

        try {
            traversal.validate();
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid id");
        }

        traversal.setId("1234");

        try {
            traversal.validate();
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid id");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidPath() {
        Traversal traversal = new Traversal();
        traversal.setId(SpecialProperty.generateId());
        traversal.setPath(null);
        traversal.setPayload(new HashMap<String, Object>());
        traversal.setSteps(new ArrayList<Step>());
        traversal.setStep(0);
        traversal.setStatus(Status.RUNNING);

        try {
            traversal.validate();
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid path");
        }

        ArrayList<PathElement> path = new ArrayList<>();
        path.add(new PathElement());
        traversal.setPath(path);

        try {
            traversal.validate();
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid path element 0: invalid id");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidPayload() {
        Traversal traversal = new Traversal();
        traversal.setId(SpecialProperty.generateId());
        traversal.setPath(new ArrayList<PathElement>());
        traversal.setPayload(null);
        traversal.setSteps(new ArrayList<Step>());
        traversal.setStep(0);
        traversal.setStatus(Status.RUNNING);

        try {
            traversal.validate();
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid payload");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidSteps() {
        Traversal traversal = new Traversal();
        traversal.setId(SpecialProperty.generateId());
        traversal.setPath(new ArrayList<PathElement>());
        traversal.setPayload(new HashMap<String, Object>());
        traversal.setSteps(null);
        traversal.setStep(0);
        traversal.setStatus(Status.RUNNING);

        try {
            traversal.validate();
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid steps");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidStep() {
        Traversal traversal = new Traversal();
        traversal.setId(SpecialProperty.generateId());
        traversal.setPath(new ArrayList<PathElement>());
        traversal.setPayload(new HashMap<String, Object>());
        traversal.setSteps(new ArrayList<Step>());
        traversal.setStep(-1);
        traversal.setStatus(Status.RUNNING);

        try {
            traversal.validate();
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid step");
        }

        traversal.getSteps().add(new InStep());
        traversal.setStep(2);

        try {
            traversal.validate();
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid step");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidStatus() {
        Traversal traversal = new Traversal();
        traversal.setId(SpecialProperty.generateId());
        traversal.setPath(new ArrayList<PathElement>());
        traversal.setPayload(new HashMap<String, Object>());
        traversal.setSteps(new ArrayList<Step>());
        traversal.setStep(0);
        traversal.setStatus(null);

        try {
            traversal.validate();
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid status");
        }
    }

    @Test
    public void validate_shouldWork() {
        Traversal traversal = new Traversal();
        traversal.setId(SpecialProperty.generateId());
        ArrayList<PathElement> path = new ArrayList<>();
        path.add(new PathElement(SpecialProperty.generateId(), PathElementType.NODE, "repo"));
        traversal.setPath(path);
        traversal.setPayload(new HashMap<String, Object>());
        ArrayList<Step> steps = new ArrayList<>();
        steps.add(new InStep());
        traversal.setSteps(steps);
        traversal.setStep(0);
        traversal.setStatus(Status.RUNNING);

        traversal.validate();
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldWorkOnBasicTraversal() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        node2.setProperty("itWorks", true);
        Edge edge = graph.addEdge(node1, node2, "label");

        steps.add(new NodeStep(node1.getId()));
        steps.add(new OutStep());
        steps.add(new StoreStep("itWorks", "payloadKey"));

        Traversal traversal = new Traversal(steps);

        ArrayList<Traversal> newTraversals = traversal.execute(graph);

        assertThat(newTraversals.size()).isEqualTo(0);

        assertThat(traversal.getCurrentElement()).isEqualTo(node2);
        assertThat(traversal.getStatus()).isEqualTo(Status.FINISHED);

        assertThat(traversal.getPayload().get("payloadKey")).isEqualTo(true);
        ArrayList<PathElement> path = traversal.getPath();

        assertThat(path.size()).isEqualTo(3);
        assertThat(path.get(0).getId()).isEqualTo(node1.getId());
        assertThat(path.get(1).getId()).isEqualTo(edge.getId());
        assertThat(path.get(2).getId()).isEqualTo(node2.getId());
    }

    @Test
    public void execute_shouldWorkOnBranchingTraversal() {
        Node start = graph.addNode("label");
        Node branch = graph.addNode("label");
        Node leaf1 = graph.addNode("label");
        Node leaf2 = graph.addNode("label");
        Node leaf3 = graph.addNode("label");

        Edge startEdge = graph.addEdge(start, branch, "label");
        Edge leafEdge1 = graph.addEdge(branch, leaf1, "label");
        Edge leafEdge2 = graph.addEdge(branch, leaf2, "label");
        Edge leafEdge3 = graph.addEdge(branch, leaf3, "label");

        leaf1.setProperty("type", "leaf");
        leaf2.setProperty("type", "leaf");
        leaf3.setProperty("type", "leaf");

        steps.add(new NodeStep(start.getId()));
        steps.add(new OutStep());
        steps.add(new OutStep());
        steps.add(new StoreStep("type", "payloadKey"));

        Traversal traversal = new Traversal(steps);

        ArrayList<Traversal> newTraversals = traversal.execute(graph);

        Traversal newTraversal;
        ArrayList<PathElement> path;

        // Check new Traversals
        assertThat(newTraversals.size()).isEqualTo(2);

        newTraversal = newTraversals.get(0);
        path = newTraversal.getPath();
        assertThat(newTraversal.getStep()).isEqualTo(3);
        assertThat(path.size()).isEqualTo(5);
        assertThat(path.get(2).getId()).isEqualTo(branch.getId());
        assertThat(path.get(4).getId()).isIn(leaf1.getId(), leaf2.getId(), leaf3.getId());

        newTraversal = newTraversals.get(1);
        path = newTraversal.getPath();
        assertThat(newTraversal.getStep()).isEqualTo(3);
        assertThat(path.size()).isEqualTo(5);
        assertThat(path.get(2).getId()).isEqualTo(branch.getId());
        assertThat(path.get(4).getId()).isIn(leaf1.getId(), leaf2.getId(), leaf3.getId());

        // Check original traversal
        path = traversal.getPath();

        assertThat(traversal.getStatus()).isEqualTo(Status.FINISHED);
        assertThat(traversal.getPayload().containsKey("payloadKey")).isTrue();
        assertThat(traversal.getPayload().get("payloadKey")).isEqualTo("leaf");
        assertThat(path.size()).isEqualTo(5);
        assertThat(path.get(0).getId()).isEqualTo(start.getId());
        assertThat(path.get(1).getId()).isEqualTo(startEdge.getId());
        assertThat(path.get(2).getId()).isEqualTo(branch.getId());
        assertThat(path.get(3).getId()).isIn(leafEdge1.getId(), leafEdge2.getId(), leafEdge3.getId());
        assertThat(path.get(4).getId()).isIn(leaf1.getId(), leaf2.getId(), leaf3.getId());
    }

    @Test
    public void execute_shouldWorkOnCrossRepo() {
        // Create boundary node
        String boundaryId = SpecialProperty.generateId();
        Vertex v = tinkerGraph.addVertex(boundaryId);
        v.setProperty(SpecialProperty.ID, boundaryId);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "externalRepo");

        Node start = graph.addNode("label");
        Node boundary = graph.getNode(boundaryId);

        Edge edge = graph.addEdge(start, boundary, "label");

        steps.add(new NodeStep(start.getId()));
        steps.add(new OutStep());
        steps.add(new OutStep());
        steps.add(new StoreStep("type", "payloadKey"));

        Traversal traversal = new Traversal(steps);

        ArrayList<Traversal> newTraversals = traversal.execute(graph);

        // Check new Traversals
        assertThat(newTraversals.size()).isEqualTo(0);

        assertThat(traversal.getStatus()).isEqualTo(Status.BOUNDARY);
        assertThat(traversal.getStep()).isEqualTo(2);

        ArrayList<PathElement> path = traversal.getPath();

        assertThat(path.size()).isEqualTo(3);
        assertThat(path.get(0).getId()).isEqualTo(start.getId());
        assertThat(path.get(1).getId()).isEqualTo(edge.getId());
        assertThat(path.get(2).getId()).isEqualTo(boundary.getId());

    }

    @Test
    public void execute_shouldWorkOnCrossRepoRestart() {
        String startId = SpecialProperty.generateId();
        Node restart = graph.addNode("label");
        Node leaf = graph.addNode("label");

        String startEdgeId = SpecialProperty.generateId();
        Edge edge = graph.addEdge(restart, leaf, "label");

        leaf.setProperty("type", "leaf");

        steps.add(new NodeStep(startId));
        steps.add(new OutStep());
        steps.add(new OutStep());
        steps.add(new StoreStep("type", "payloadKey"));

        Traversal traversal = new Traversal(steps);

        // Set proper state in Traversal
        traversal.addToPath(startId, PathElementType.NODE, "externalRepo");
        traversal.addToPath(startEdgeId, PathElementType.EDGE, "externalRepo");
        traversal.addToPath(restart.getId(), PathElementType.BOUNDARY, "externalRepo");
        traversal.setStep(2);

        ArrayList<Traversal> newTraversals = traversal.execute(graph);

        assertThat(newTraversals.size()).isEqualTo(0);

        assertThat(traversal.getStatus()).isEqualTo(Status.FINISHED);
        assertThat(traversal.getStep()).isEqualTo(4);
        assertThat(traversal.getPayload().containsKey("payloadKey")).isTrue();
        assertThat(traversal.getPayload().get("payloadKey")).isEqualTo("leaf");

        ArrayList<PathElement> path = traversal.getPath();
        assertThat(path.size()).isEqualTo(6);
        assertThat(path.get(0).getId()).isEqualTo(startId);
        assertThat(path.get(1).getId()).isEqualTo(startEdgeId);
        assertThat(path.get(2).getId()).isEqualTo(restart.getId());
        assertThat(path.get(2).getType()).isEqualTo(PathElementType.BOUNDARY);
        assertThat(path.get(3).getId()).isEqualTo(restart.getId());
        assertThat(path.get(3).getType()).isEqualTo(PathElementType.NODE);
        assertThat(path.get(4).getId()).isEqualTo(edge.getId());
        assertThat(path.get(5).getId()).isEqualTo(leaf.getId());
    }

    @Test
    public void execute_shouldWorkOnCrossRepoRestartWithBranch() {
        String startId = SpecialProperty.generateId();
        Node restart = graph.addNode("label");
        Node leaf1 = graph.addNode("label");
        Node leaf2 = graph.addNode("label");

        String startEdgeId = SpecialProperty.generateId();
        Edge edge1 = graph.addEdge(restart, leaf1, "label");
        Edge edge2 = graph.addEdge(restart, leaf2, "label");

        leaf1.setProperty("type", "leaf1");
        leaf2.setProperty("type", "leaf2");

        steps.add(new NodeStep(startId));
        steps.add(new OutStep());
        steps.add(new OutStep());
        steps.add(new StoreStep("type", "payloadKey"));

        Traversal traversal = new Traversal(steps);

        // Set proper state in Traversal
        traversal.addToPath(startId, PathElementType.NODE, "externalRepo");
        traversal.addToPath(startEdgeId, PathElementType.EDGE, "externalRepo");
        traversal.addToPath(restart.getId(), PathElementType.BOUNDARY, "externalRepo");
        traversal.setStep(2);

        ArrayList<Traversal> newTraversals = traversal.execute(graph);

        assertThat(newTraversals.size()).isEqualTo(1);

        Traversal newTraversal = newTraversals.get(0);

        assertThat(newTraversal.getStatus()).isEqualTo(Status.RUNNING);
        assertThat(newTraversal.getStep()).isEqualTo(3);
        assertThat(newTraversal.getPath().size()).isEqualTo(6);


        assertThat(traversal.getStatus()).isEqualTo(Status.FINISHED);
        assertThat(traversal.getStep()).isEqualTo(4);
        assertThat(traversal.getPayload().containsKey("payloadKey")).isTrue();
        assertThat(traversal.getPayload().get("payloadKey")).isIn("leaf1", "leaf2");

        ArrayList<PathElement> path = traversal.getPath();
        assertThat(path.size()).isEqualTo(6);
        assertThat(path.get(0).getId()).isEqualTo(startId);
        assertThat(path.get(1).getId()).isEqualTo(startEdgeId);
        assertThat(path.get(2).getId()).isEqualTo(restart.getId());
        assertThat(path.get(2).getType()).isEqualTo(PathElementType.BOUNDARY);
        assertThat(path.get(3).getId()).isEqualTo(restart.getId());
        assertThat(path.get(3).getType()).isEqualTo(PathElementType.NODE);
        assertThat(path.get(4).getId()).isIn(edge1.getId(), edge2.getId());
        assertThat(path.get(5).getId()).isIn(leaf1.getId(), leaf2.getId());

    }

    @Test
    public void execute_shouldWorkOnBackTrackToNode() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Node node3 = graph.addNode("label");
        Node node4 = graph.addNode("label");

        Edge edge1 = graph.addEdge(node1, node2, "label");
        graph.addEdge(node2, node3, "label");
        graph.addEdge(node3, node4, "label");

        node2.setProperty("val", "node2");
        node4.setProperty("val", "node4");

        steps.add(new NodeStep(node1.getId()));
        steps.add(new OutStep());
        steps.add(new AsStep("x")); // Mark node2
        steps.add(new OutStep());
        steps.add(new OutStep());
        steps.add(new StoreStep("val", "endNode"));
        steps.add(new BackStep("x")); // Go to node2
        steps.add(new StoreStep("val", "backNode"));

        Traversal traversal = new Traversal(steps);

        ArrayList<Traversal> newTraversals = traversal.execute(graph);

        assertThat(newTraversals.size()).isEqualTo(0);

        assertThat(traversal.getStatus()).isEqualTo(Status.FINISHED);

        assertThat(traversal.getPayload().containsKey("endNode")).isTrue();
        assertThat(traversal.getPayload().get("endNode")).isEqualTo("node4");
        assertThat(traversal.getPayload().containsKey("backNode")).isTrue();
        assertThat(traversal.getPayload().get("backNode")).isEqualTo("node2");

        ArrayList<PathElement> path = traversal.getPath();
        assertThat(path.size()).isEqualTo(3);
        assertThat(path.get(0).getId()).isEqualTo(node1.getId());
        assertThat(path.get(1).getId()).isEqualTo(edge1.getId());
        assertThat(path.get(2).getId()).isEqualTo(node2.getId());
    }

    @Test
    public void execute_shouldWorkOnBackTrackToEdge() {
        // TODO when we can traverse to an edge
    }

    @Test
    public void execute_shouldWorkOnCrossRepoRestartWithBacktrack() {
        String startId = SpecialProperty.generateId();
        Node restart = graph.addNode("label");
        Node leaf = graph.addNode("label");

        String startEdgeId = SpecialProperty.generateId();
        graph.addEdge(restart, leaf, "label");

        leaf.setProperty("val", "leaf");

        steps.add(new NodeStep(startId));
        steps.add(new AsStep("x"));
        steps.add(new OutStep());
        steps.add(new OutStep()); // Starting on this step
        steps.add(new StoreStep("val", "payloadKey"));
        steps.add(new BackStep("x"));
        steps.add(new StoreStep("val", "newKey"));

        Traversal traversal = new Traversal(steps);

        // Set proper state in Traversal
        traversal.addToPath(startId, PathElementType.NODE, "externalRepo");
        traversal.getPath().get(0).addMarker("x");
        traversal.addToPath(startEdgeId, PathElementType.EDGE, "externalRepo");
        traversal.addToPath(restart.getId(), PathElementType.BOUNDARY, "externalRepo");
        traversal.setStep(3);

        ArrayList<Traversal> newTraversals = traversal.execute(graph);

        assertThat(newTraversals.size()).isEqualTo(0);

        assertThat(traversal.getStatus()).isEqualTo(Status.BACKTRACK);
        assertThat(traversal.getStep()).isEqualTo(6);

        assertThat(traversal.getPayload().containsKey("payloadKey")).isTrue();
        assertThat(traversal.getPayload().get("payloadKey")).isEqualTo("leaf");

        ArrayList<PathElement> path = traversal.getPath();
        assertThat(path.size()).isEqualTo(1);
        assertThat(path.get(0).getId()).isEqualTo(startId);
    }

    @Test
    public void execute_shouldSetStatusOnMissingElement() {
        String startId = SpecialProperty.generateId();
        Node restart = graph.addNode("label");
        Node leaf = graph.addNode("label");

        String startEdgeId = SpecialProperty.generateId();
        graph.addEdge(restart, leaf, "label");

        leaf.setProperty("type", "leaf");

        steps.add(new NodeStep(startId));
        steps.add(new OutStep());
        steps.add(new OutStep());
        steps.add(new StoreStep("type", "payloadKey"));

        Traversal traversal = new Traversal(steps);

        // Set proper state in Traversal
        traversal.addToPath(startId, PathElementType.NODE, "externalRepo");
        traversal.addToPath(startEdgeId, PathElementType.EDGE, "externalRepo");
        traversal.addToPath(restart.getId(), PathElementType.BOUNDARY, "externalRepo");
        traversal.setStep(2);

        // Simulate a missing element
        graph.removeNode(restart.getId());

        ArrayList<Traversal> newTraversals = traversal.execute(graph);

        assertThat(newTraversals.size()).isEqualTo(0);

        assertThat(traversal.getStatus()).isEqualTo(Status.MISSING_ELEMENT);
    }

    @Test
    public void execute_shouldReturnOnDoubleBoundary() {
        String startId = SpecialProperty.generateId();
        String restartId = SpecialProperty.generateId();
        Vertex v = tinkerGraph.addVertex(restartId);
        v.setProperty(SpecialProperty.ID, restartId);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "externalRepo2");
        Node restart = graph.getNode(restartId);

        String startEdgeId = SpecialProperty.generateId();

        steps.add(new NodeStep(startId));
        steps.add(new OutStep());
        steps.add(new OutStep());
        steps.add(new StoreStep("type", "payloadKey"));

        Traversal traversal = new Traversal(steps);

        // Set proper state in Traversal
        traversal.addToPath(startId, PathElementType.NODE, "externalRepo");
        traversal.addToPath(startEdgeId, PathElementType.EDGE, "externalRepo");
        traversal.addToPath(restart.getId(), PathElementType.BOUNDARY, "externalRepo");
        traversal.setStep(2);

        ArrayList<Traversal> newTraversals = traversal.execute(graph);

        assertThat(newTraversals.size()).isEqualTo(0);

        assertThat(traversal.getStatus()).isEqualTo(Status.BOUNDARY);
        assertThat(traversal.getStep()).isEqualTo(2);


        ArrayList<PathElement> path = traversal.getPath();
        assertThat(path.size()).isEqualTo(4);
        assertThat(path.get(0).getId()).isEqualTo(startId);
        assertThat(path.get(1).getId()).isEqualTo(startEdgeId);
        assertThat(path.get(2).getId()).isEqualTo(restart.getId());
        assertThat(path.get(2).getType()).isEqualTo(PathElementType.BOUNDARY);
        assertThat(path.get(2).getRepo()).isEqualTo("externalRepo");
        assertThat(path.get(3).getId()).isEqualTo(restart.getId());
        assertThat(path.get(3).getType()).isEqualTo(PathElementType.BOUNDARY);
        assertThat(path.get(3).getRepo()).isEqualTo("externalRepo2");
    }
}

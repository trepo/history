package com.github.trepo.npipes.step;

import com.github.trepo.npipes.NPipesException;
import com.github.trepo.npipes.Status;
import com.github.trepo.npipes.Step;
import com.github.trepo.npipes.Traversal;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class StoreStepTest {
    private String repo = "repo";
    private TinkerGraph tinkerGraph;
    private VGraph graph;
    private Traversal traversal;

    @BeforeMethod
    public void setup() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
        traversal = new Traversal(new ArrayList<Step>());
    }

    /**
     * constructor
     */
    @Test
    public void constructor_shouldWork() {
        Map<String, Object> parameters = null;


        try {
            new StoreStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for store step");
        }

        parameters = new HashMap<>();
        parameters.put("payload", "payload");
        try {
            new StoreStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for store step");
        }

        parameters = new HashMap<>();
        parameters.put("property", "property");
        try {
            new StoreStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for store step");
        }

        parameters = new HashMap<>();
        parameters.put("property", new ArrayList<String>());
        parameters.put("payload", "payload");
        try {
            new StoreStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("store step requires a valid property");
        }

        parameters = new HashMap<>();
        parameters.put("property", "property");
        parameters.put("payload", new ArrayList<String>());
        try {
            new StoreStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("store step requires a valid payload");
        }

        parameters = new HashMap<>();
        parameters.put("property", "property");
        parameters.put("payload", "payload");

        StoreStep step = new StoreStep(parameters);

        assertThat(step.getProperty()).isEqualTo("property");
        assertThat(step.getPayload()).isEqualTo("payload");
    }

    /**
     * getters
     */
    @Test
    public void getters_shouldWork() {

        StoreStep step = new StoreStep("propertyKey", "payloadKey");

        assertThat(step.getProperty()).isEqualTo("propertyKey");
        assertThat(step.getPayload()).isEqualTo("payloadKey");
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldSetStatusOnCurrentElementNull() {

        StoreStep step = new StoreStep("propertyKey", "payloadKey");

        step.execute(traversal, graph);

        assertThat(traversal.getStatus()).isEqualTo(Status.INVALID_STATE);
    }

    @Test
    public void execute_shouldSaveNull() {
        Node node = graph.addNode("label");
        traversal.setCurrentElement(node);

        StoreStep step = new StoreStep("propertyKey", "payloadKey");

        step.execute(traversal, graph);

        assertThat(traversal.getPayload().containsKey("payloadKey")).isTrue();
        assertThat(traversal.getPayload().get("payloadKey")).isNull();
    }

    @Test
    public void execute_shouldSaveValue() {
        Node node = graph.addNode("label");
        node.setProperty("propertyKey","propertyValue");

        traversal.setCurrentElement(node);

        StoreStep step = new StoreStep("propertyKey", "payloadKey");

        step.execute(traversal, graph);

        assertThat(traversal.getPayload().containsKey("payloadKey")).isTrue();
        assertThat(traversal.getPayload().get("payloadKey")).isEqualTo("propertyValue");
    }

    @Test
    public void execute_shouldSaveSpecialPropertyId() {
        Node node = graph.addNode("label");

        traversal.setCurrentElement(node);

        StoreStep step = new StoreStep(SpecialProperty.ID, "key");

        step.execute(traversal, graph);

        assertThat(traversal.getPayload().get("key")).isEqualTo(node.getId());
    }

    @Test
    public void execute_shouldSaveSpecialPropertyLabel() {
        Node node = graph.addNode("label");

        traversal.setCurrentElement(node);

        StoreStep step = new StoreStep(SpecialProperty.LABEL, "key");

        step.execute(traversal, graph);

        assertThat(traversal.getPayload().get("key")).isEqualTo(node.getLabel());
    }

    @Test
    public void execute_shouldSaveSpecialPropertyRepoOnEdge() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "label");

        traversal.setCurrentElement(edge);

        StoreStep step = new StoreStep(SpecialProperty.REPO, "key");

        step.execute(traversal, graph);

        assertThat(traversal.getPayload().get("key")).isEqualTo(repo);
    }

    @Test
    public void execute_shouldSaveSpecialPropertyRepoOnNode() {
        Node node = graph.addNode("label");

        traversal.setCurrentElement(node);

        StoreStep step = new StoreStep(SpecialProperty.REPO, "key");

        step.execute(traversal, graph);

        assertThat(traversal.getPayload().get("key")).isEqualTo(repo);
    }

    @Test
    public void execute_shouldSaveSpecialPropertyRepoOnBoundary() {
        String id = SpecialProperty.generateId();
        Vertex v = tinkerGraph.addVertex(id);
        v.setProperty(SpecialProperty.ID, id);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "externalRepo");
        Node node = graph.getNode(id);

        traversal.setCurrentElement(node);

        StoreStep step = new StoreStep(SpecialProperty.REPO, "key");

        step.execute(traversal, graph);

        assertThat(traversal.getPayload().get("key")).isEqualTo("externalRepo");
    }

    /**
     * toSerializableStep
     */
    @Test
    public void toSerializableStep_shouldWork() {
        StoreStep step = new StoreStep("property", "payload");

        SerializableStep serializableStep = step.toSerializableStep();

        assertThat(serializableStep.getName()).isEqualTo("store");

        Map<String, Object> map = serializableStep.getParameters();

        assertThat(map.size()).isEqualTo(2);
        assertThat(map.get("property")).isEqualTo("property");
        assertThat(map.get("payload")).isEqualTo("payload");

    }
}

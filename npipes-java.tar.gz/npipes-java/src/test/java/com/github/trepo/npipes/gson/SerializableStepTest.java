package com.github.trepo.npipes.gson;

import org.testng.annotations.Test;

import java.util.HashMap;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author john
 */
public class SerializableStepTest {

    /**
     * getters and setters.
     */
    @Test
    public void shouldWork() {
        String name = "name";
        HashMap<String, Object> map = new HashMap<>();
        map.put("key", "value");
        SerializableStep step = new SerializableStep();

        assertThat(step.getName()).isNull();
        assertThat(step.getParameters()).isNull();

        step.setName(name);
        step.setParameters(map);

        assertThat(step.getName()).isEqualTo(name);
        assertThat(step.getParameters()).isEqualTo(map);

        step = new SerializableStep(name, map);

        assertThat(step.getName()).isEqualTo(name);
        assertThat(step.getParameters()).isEqualTo(map);
    }
}

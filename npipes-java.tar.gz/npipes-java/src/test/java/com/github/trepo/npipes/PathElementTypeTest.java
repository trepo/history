package com.github.trepo.npipes;

import com.github.trepo.vgraph.blueprints.BlueprintsBoundary;
import com.github.trepo.vgraph.blueprints.BlueprintsEdge;
import com.github.trepo.vgraph.blueprints.BlueprintsNode;
import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class PathElementTypeTest {

    /**
     * getTypeString
     */
    @Test
    public void getTypeString_shouldWork() {

        assertThat(PathElementType.NODE.getTypeString()).isEqualTo("node");
        assertThat(PathElementType.BOUNDARY.getTypeString()).isEqualTo("boundary");
        assertThat(PathElementType.EDGE.getTypeString()).isEqualTo("edge");
    }

    /**
     * getType
     */
    @Test
    public void getType_shouldWork() {

        assertThat(PathElementType.getType(new BlueprintsNode(null, null))).isEqualTo(PathElementType.NODE);
        assertThat(PathElementType.getType(new BlueprintsBoundary(null, null))).isEqualTo(PathElementType.BOUNDARY);
        assertThat(PathElementType.getType(new BlueprintsEdge(null, null))).isEqualTo(PathElementType.EDGE);

        try {
            PathElementType.getType(null);
            fail("should have thrown error");
        } catch(IllegalArgumentException e) {
            assertThat(e.getMessage()).isEqualTo("Unknown Type");
        }
    }
}

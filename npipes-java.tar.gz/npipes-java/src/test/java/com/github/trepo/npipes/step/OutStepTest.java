package com.github.trepo.npipes.step;

import com.github.trepo.npipes.*;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class OutStepTest {
    private String repo = "repo";
    private TinkerGraph tinkerGraph;
    private VGraph graph;
    private Traversal traversal;

    @BeforeMethod
    public void setup() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
        traversal = new Traversal(new ArrayList<Step>());
    }

    /**
     * constructor
     */
    @Test
    public void constructor_shouldWork() {
        OutStep step;
        Map<String, Object> parameters = null;
        ArrayList<Object> labels;

        try {
            new OutStep(parameters);
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for out step");
        }

        parameters = new HashMap<>();
        try {
            new OutStep(parameters);
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for out step");
        }

        labels = new ArrayList<>();
        labels.add("String");
        labels.add(false);
        parameters.put("labels", labels);
        try {
            new OutStep(parameters);
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid label for out step");
        }

        parameters.put("labels", new String[]{"label"});
        step = new OutStep(parameters);
        assertThat(step.getLabels()).isEqualTo(new String[]{"label"});

        labels = new ArrayList<>();
        labels.add("label1");
        labels.add("label2");
        parameters.put("labels", labels);
        step = new OutStep(parameters);
        assertThat(step.getLabels()).isEqualTo(new String[]{"label1", "label2"});
    }

    /**
     * getters
     */
    @Test
    public void getters_shouldWork() {
        String[] labels = {"label1", "label2"};

        OutStep step = new OutStep(labels);

        assertThat(step.getLabels()).isEqualTo(labels);
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldSetStatusOnCurrentElementNull() {

        OutStep step = new OutStep();

        ArrayList<Traversal> traversals = step.execute(traversal, graph);

        assertThat(traversals).isNull();
        assertThat(traversal.getStatus()).isEqualTo(Status.INVALID_STATE);
    }

    @Test
    public void execute_shouldSetStatusOnCurrentElementEdge() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "edge_label");
        traversal.setCurrentElement(edge);
        OutStep step = new OutStep();

        ArrayList<Traversal> traversals = step.execute(traversal, graph);

        assertThat(traversals).isNull();
        assertThat(traversal.getStatus()).isEqualTo(Status.INVALID_STATE);
    }

    @Test
    public void execute_shouldFollow1Edge() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "edge_label");
        traversal.setCurrentElement(node1);
        OutStep step = new OutStep();

        assertThat(traversal.getCurrentElement()).isEqualTo(node1);
        assertThat(traversal.getPath().size()).isEqualTo(0);

        ArrayList<Traversal> traversals = step.execute(traversal, graph);

        assertThat(traversals.size()).isEqualTo(0);

        assertThat(traversal.getCurrentElement()).isEqualTo(node2);
        assertThat(traversal.getPath().size()).isEqualTo(2);

        PathElement pathElement = traversal.getPath().get(0);
        assertThat(pathElement.getId()).isEqualTo(edge.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.EDGE);
        assertThat(pathElement.getRepo()).isEqualTo(repo);

        pathElement = traversal.getPath().get(1);
        assertThat(pathElement.getId()).isEqualTo(node2.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.NODE);
        assertThat(pathElement.getRepo()).isEqualTo(repo);
    }

    @Test
    public void execute_shouldFollow0EdgesWhenFiltering() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        graph.addEdge(node1, node2, "edge_label");
        traversal.setCurrentElement(node1);
        OutStep step = new OutStep("nonexistent_label");

        assertThat(traversal.getCurrentElement()).isEqualTo(node1);
        assertThat(traversal.getPath().size()).isEqualTo(0);

        ArrayList<Traversal> traversals = step.execute(traversal, graph);

        assertThat(traversals).isNull();

        // Nothing should have changed except complete is true
        assertThat(traversal.getCurrentElement()).isEqualTo(node1);
        assertThat(traversal.getPath().size()).isEqualTo(0);
        assertThat(traversal.getStatus()).isEqualTo(Status.FINISHED);
    }

    @Test
    public void execute_shouldFollow3Edges() {
        Node nodeFrom = graph.addNode("label");
        Node nodeTo1 = graph.addNode("label");
        Node nodeTo2 = graph.addNode("label");
        Node nodeTo3 = graph.addNode("label");
        Edge edge1 = graph.addEdge(nodeFrom, nodeTo1, "edge_label");
        Edge edge2 = graph.addEdge(nodeFrom, nodeTo2, "edge_label");
        Edge edge3 = graph.addEdge(nodeFrom, nodeTo3, "edge_label");
        traversal.setCurrentElement(nodeFrom);
        traversal.setStep(1); // Step should point to next step when executing
        OutStep step = new OutStep();

        ArrayList<Traversal> traversals = step.execute(traversal, graph);

        Traversal newTraversal;
        PathElement pathElement;

        assertThat(traversals.size()).isEqualTo(2);

        // Check first new traversal
        newTraversal = traversals.get(0);
        assertThat(newTraversal.getCurrentElement()).isIn(nodeTo1, nodeTo2, nodeTo3);
        assertThat(newTraversal.getStep()).isEqualTo(1);

        assertThat(newTraversal.getPath().size()).isEqualTo(2);

        pathElement = newTraversal.getPath().get(0);
        assertThat(pathElement.getId()).isIn(edge1.getId(), edge2.getId(), edge3.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.EDGE);
        assertThat(pathElement.getRepo()).isEqualTo(repo);

        pathElement = newTraversal.getPath().get(1);
        assertThat(pathElement.getId()).isIn(nodeTo1.getId(), nodeTo2.getId(), nodeTo3.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.NODE);
        assertThat(pathElement.getRepo()).isEqualTo(repo);

        // Check second new traversal
        newTraversal = traversals.get(1);
        assertThat(newTraversal.getCurrentElement()).isIn(nodeTo1, nodeTo2, nodeTo3);
        assertThat(newTraversal.getStep()).isEqualTo(1);

        assertThat(newTraversal.getPath().size()).isEqualTo(2);

        pathElement = newTraversal.getPath().get(0);
        assertThat(pathElement.getId()).isIn(edge1.getId(), edge2.getId(), edge3.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.EDGE);
        assertThat(pathElement.getRepo()).isEqualTo(repo);

        pathElement = newTraversal.getPath().get(1);
        assertThat(pathElement.getId()).isIn(nodeTo1.getId(), nodeTo2.getId(), nodeTo3.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.NODE);
        assertThat(pathElement.getRepo()).isEqualTo(repo);

        // Check original traversal
        assertThat(traversal.getCurrentElement()).isIn(nodeTo1, nodeTo2, nodeTo3);

        assertThat(traversal.getPath().size()).isEqualTo(2);

        pathElement = traversal.getPath().get(0);
        assertThat(pathElement.getId()).isIn(edge1.getId(), edge2.getId(), edge3.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.EDGE);
        assertThat(pathElement.getRepo()).isEqualTo(repo);

        pathElement = traversal.getPath().get(1);
        assertThat(pathElement.getId()).isIn(nodeTo1.getId(), nodeTo2.getId(), nodeTo3.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.NODE);
        assertThat(pathElement.getRepo()).isEqualTo(repo);
    }

    @Test
    public void execute_shouldFollow2EdgesToBoundaries() {
        Node node = graph.addNode("label");

        String boundary1Id = SpecialProperty.generateId();
        Vertex v1 = tinkerGraph.addVertex(boundary1Id);
        v1.setProperty(SpecialProperty.ID, boundary1Id);
        v1.setProperty(SpecialProperty.LABEL, "label");
        v1.setProperty(SpecialProperty.REPO, "externalRepo");
        Node boundary1 = graph.getNode(boundary1Id);

        String boundary2Id = SpecialProperty.generateId();
        Vertex v2 = tinkerGraph.addVertex(boundary2Id);
        v2.setProperty(SpecialProperty.ID, boundary2Id);
        v2.setProperty(SpecialProperty.LABEL, "label");
        v2.setProperty(SpecialProperty.REPO, "externalRepo");
        Node boundary2 = graph.getNode(boundary2Id);

        Edge edge1 = graph.addEdge(node, boundary1, "label");
        Edge edge2 = graph.addEdge(node, boundary2, "label");

        traversal.setCurrentElement(node);
        traversal.setStep(1); // Step should point to next step when executing
        OutStep step = new OutStep();

        ArrayList<Traversal> traversals = step.execute(traversal, graph);

        Traversal newTraversal;
        PathElement pathElement;

        assertThat(traversals.size()).isEqualTo(1);

        // Check first new traversal
        newTraversal = traversals.get(0);
        assertThat(newTraversal.getCurrentElement()).isNull();
        assertThat(newTraversal.getStep()).isEqualTo(1);
        assertThat(newTraversal.getStatus()).isEqualTo(Status.BOUNDARY);

        assertThat(newTraversal.getPath().size()).isEqualTo(2);

        pathElement = newTraversal.getPath().get(0);
        assertThat(pathElement.getId()).isIn(edge1.getId(), edge2.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.EDGE);
        assertThat(pathElement.getRepo()).isEqualTo(repo);

        pathElement = newTraversal.getPath().get(1);
        assertThat(pathElement.getId()).isIn(boundary1.getId(), boundary2.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.BOUNDARY);
        assertThat(pathElement.getRepo()).isEqualTo("externalRepo");

        // Check original traversal
        assertThat(traversal.getCurrentElement()).isNull();
        assertThat(traversal.getStatus()).isEqualTo(Status.BOUNDARY);

        assertThat(traversal.getPath().size()).isEqualTo(2);

        pathElement = traversal.getPath().get(0);
        assertThat(pathElement.getId()).isIn(edge1.getId(), edge2.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.EDGE);
        assertThat(pathElement.getRepo()).isEqualTo(repo);

        pathElement = traversal.getPath().get(1);
        assertThat(pathElement.getId()).isIn(boundary1.getId(), boundary2.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.BOUNDARY);
        assertThat(pathElement.getRepo()).isEqualTo("externalRepo");
    }

    @Test
    public void execute_shouldSetStatusCorrectlyOn0Edges() {
        Node node = graph.addNode("label");
        OutStep step = new OutStep();


        // Check Last Step
        traversal.setCurrentElement(node);
        traversal.getSteps().add(step);
        traversal.setStep(1); // Points to next step (which is none)

        // Verify we set things up correctly
        assertThat(traversal.getCurrentElement()).isEqualTo(node);
        assertThat(traversal.getPath().size()).isEqualTo(0);
        assertThat(traversal.getStatus()).isEqualTo(Status.RUNNING);

        ArrayList<Traversal> traversals = step.execute(traversal, graph);

        // Nothing should have changed except status
        assertThat(traversals).isNull();
        assertThat(traversal.getCurrentElement()).isEqualTo(node);
        assertThat(traversal.getPath().size()).isEqualTo(0);
        assertThat(traversal.getStatus()).isEqualTo(Status.FINISHED);


        // Check Not Last Step
        traversal = new Traversal(new ArrayList<Step>());
        traversal.setCurrentElement(node);
        traversal.getSteps().add(step);
        traversal.getSteps().add(new InStep());
        traversal.getSteps().add(new InStep());
        traversal.setStep(1); // Points to next step

        // Verify we set things up correctly
        assertThat(traversal.getCurrentElement()).isEqualTo(node);
        assertThat(traversal.getPath().size()).isEqualTo(0);
        assertThat(traversal.getStatus()).isEqualTo(Status.RUNNING);

        traversals = step.execute(traversal, graph);

        // Nothing should have changed except status
        assertThat(traversals).isNull();
        assertThat(traversal.getCurrentElement()).isEqualTo(node);
        assertThat(traversal.getPath().size()).isEqualTo(0);
        assertThat(traversal.getStatus()).isEqualTo(Status.DONE);
    }

    /**
     * toSerializableStep
     */
    @Test
    public void toSerializableStep_shouldWork() {
        OutStep step = new OutStep("label");

        SerializableStep serializableStep = step.toSerializableStep();

        assertThat(serializableStep.getName()).isEqualTo("out");

        Map<String, Object> map = serializableStep.getParameters();

        assertThat(map.size()).isEqualTo(1);
        assertThat(map.get("labels")).isEqualTo(new String[]{"label"});

    }
}

package com.github.trepo.npipes;

import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class StatusTest {

    @Test
    public void getStatusCode_shouldWork() {
        assertThat(Status.OTHER.getStatusCode()).isEqualTo(0);
        assertThat(Status.RUNNING.getStatusCode()).isEqualTo(10);
        assertThat(Status.PAUSED.getStatusCode()).isEqualTo(11);
        assertThat(Status.FINISHED.getStatusCode()).isEqualTo(20);
        assertThat(Status.DONE.getStatusCode()).isEqualTo(21);
        assertThat(Status.BOUNDARY.getStatusCode()).isEqualTo(30);
        assertThat(Status.REMOTE_ERROR.getStatusCode()).isEqualTo(40);
        assertThat(Status.UNAUTHORIZED.getStatusCode()).isEqualTo(41);
        assertThat(Status.TRAVERSAL_ERROR.getStatusCode()).isEqualTo(50);
        assertThat(Status.INVALID_STATE.getStatusCode()).isEqualTo(51);
        assertThat(Status.TIMEOUT.getStatusCode()).isEqualTo(52);
    }

    @Test
    public void getReasonPhrase_shouldWork() {
        assertThat(Status.RUNNING.getReasonPhrase()).isEqualTo("Running");
    }

    @Test
    public void getFamily_shouldWork() {
        assertThat(Status.RUNNING.toString()).isEqualTo("Running");
    }

    @Test
    public void toString_shouldWork() {
        assertThat(Status.RUNNING.getFamily()).isEqualTo(Status.Family.EXECUTING);
    }

    @Test
    public void fromStatusCode_shouldWork() {
        assertThat(Status.fromStatusCode(10)).isEqualTo(Status.RUNNING);
        assertThat(Status.fromStatusCode(-1)).isEqualTo(null);
    }
}

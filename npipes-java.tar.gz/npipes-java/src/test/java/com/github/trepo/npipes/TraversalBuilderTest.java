package com.github.trepo.npipes;

import com.github.trepo.npipes.step.*;
import org.testng.annotations.Test;

import java.util.ArrayList;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class TraversalBuilderTest {

    @Test
    public void shouldWork() {
        Traversal traversal = new TraversalBuilder()
                .as("x")
                .back("x")
                .in("label")
                .out("label")
                .set("key", "value")
                .store("key", "payloadKey")
                .n("1234")
                .traversal();

        ArrayList<Step> steps = traversal.getSteps();

        assertThat(steps.size()).isEqualTo(7);
        assertThat(steps.get(0) instanceof AsStep).isTrue();
        assertThat(steps.get(1) instanceof BackStep).isTrue();
        assertThat(steps.get(2) instanceof InStep).isTrue();
        assertThat(steps.get(3) instanceof OutStep).isTrue();
        assertThat(steps.get(4) instanceof SetStep).isTrue();
        assertThat(steps.get(5) instanceof StoreStep).isTrue();
        assertThat(steps.get(6) instanceof NodeStep).isTrue();
    }
}

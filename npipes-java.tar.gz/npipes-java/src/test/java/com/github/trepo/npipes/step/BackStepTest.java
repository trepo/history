package com.github.trepo.npipes.step;

import com.github.trepo.npipes.*;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.Edge;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class BackStepTest {
    private String repo = "repo";
    private VGraph graph;
    private Traversal traversal;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), repo);
        traversal = new Traversal(new ArrayList<Step>());
    }

    /**
     * constructor
     */
    @Test
    public void constructor_shouldWork() {
        Map<String, Object> parameters = null;


        try {
            new BackStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for back step");
        }

        parameters = new HashMap<>();
        try {
            new BackStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for back step");
        }

        parameters.put("marker", new ArrayList<String>());
        try {
            new BackStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("back step requires a marker value");
        }

        parameters.put("marker", "the marker");

        BackStep step = new BackStep(parameters);

        assertThat(step.getMarker()).isEqualTo("the marker");
    }

    /**
     * getters
     */
    @Test
    public void getters_shouldWork() {
        BackStep step = new BackStep("marker");

        assertThat(step.getMarker()).isEqualTo("marker");
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldSetStatusOnMissingMarker() {

        BackStep step = new BackStep("marker");

        step.execute(traversal, graph);

        assertThat(traversal.getStatus()).isEqualTo(Status.INVALID_STATE);

        traversal = new Traversal(new ArrayList<Step>());

        traversal.addToPath("id", PathElementType.NODE, repo);
        traversal.addToPath("id2", PathElementType.NODE, repo);
        traversal.addToPath("id3", PathElementType.NODE, repo);

        step.execute(traversal, graph);

        assertThat(traversal.getStatus()).isEqualTo(Status.INVALID_STATE);
    }

    @Test
    public void execute_shouldRewindCorrectly() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "label");

        // Create path
        traversal.addToPath(node1.getId(), PathElementType.NODE, repo);
        traversal.addToPath(edge.getId(), PathElementType.EDGE, repo);
        traversal.addToPath(node2.getId(), PathElementType.NODE, repo);
        // Set current Element
        traversal.setCurrentElement(node2);
        // Add marker
        traversal.getPath().get(0).addMarker("marker");

        BackStep step = new BackStep("marker");

        step.execute(traversal, graph);

        assertThat(traversal.getCurrentElement()).isEqualTo(node1);

        ArrayList<PathElement> path = traversal.getPath();

        assertThat(path.size()).isEqualTo(1);
        assertThat(path.get(0).getId()).isEqualTo(node1.getId());
    }

    @Test
    public void execute_shouldDoNothingIfAlreadyThere() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "label");

        // Create path
        traversal.addToPath(node1.getId(), PathElementType.NODE, repo);
        traversal.addToPath(edge.getId(), PathElementType.EDGE, repo);
        // Set current Element
        traversal.setCurrentElement(edge);
        // Add marker
        traversal.getPath().get(1).addMarker("marker");

        BackStep step = new BackStep("marker");

        step.execute(traversal, graph);

        assertThat(traversal.getCurrentElement()).isEqualTo(edge);

        ArrayList<PathElement> path = traversal.getPath();

        assertThat(path.size()).isEqualTo(2);
        assertThat(path.get(1).getId()).isEqualTo(edge.getId());
    }

    @Test
    public void execute_shouldRewindToExternalNode() {
        Node node1 = graph.addNode("label");
        Node node2 = graph.addNode("label");
        Edge edge = graph.addEdge(node1, node2, "label");

        // Create path
        traversal.addToPath("externalNode", PathElementType.NODE, "externalRepo");
        traversal.addToPath("externalEdge", PathElementType.EDGE, "externalRepo");
        traversal.addToPath("externalBoundary", PathElementType.BOUNDARY, "externalRepo");
        traversal.addToPath(node1.getId(), PathElementType.NODE, repo);
        traversal.addToPath(edge.getId(), PathElementType.EDGE, repo);
        traversal.addToPath(node2.getId(), PathElementType.NODE, repo);
        // Set current Element
        traversal.setCurrentElement(node2);
        // Add marker
        traversal.getPath().get(0).addMarker("marker");

        BackStep step = new BackStep("marker");

        step.execute(traversal, graph);

        assertThat(traversal.getCurrentElement()).isNull();
        assertThat(traversal.getStatus()).isEqualTo(Status.BACKTRACK);

        ArrayList<PathElement> path = traversal.getPath();

        assertThat(path.size()).isEqualTo(1);
        assertThat(path.get(0).getId()).isEqualTo("externalNode");
    }

    /**
     * toSerializableStep
     */
    @Test
    public void toSerializableStep_shouldWork() {
        BackStep step = new BackStep("the marker");

        SerializableStep serializableStep = step.toSerializableStep();

        assertThat(serializableStep.getName()).isEqualTo("back");

        Map<String, Object> map = serializableStep.getParameters();

        assertThat(map.size()).isEqualTo(1);
        assertThat(map.get("marker")).isEqualTo("the marker");

    }
}

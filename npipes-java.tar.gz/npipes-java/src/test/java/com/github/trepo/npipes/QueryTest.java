package com.github.trepo.npipes;

import com.github.trepo.npipes.step.OutStep;
import com.github.trepo.npipes.step.StoreStep;
import com.github.trepo.npipes.step.NodeStep;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Fail.fail;

/**
 * @author John Clark.
 */
public class QueryTest {

    private VGraph graph;
    private ArrayList<Step> steps;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), "repo");
        steps = new ArrayList<>();
    }

    /**
     * Constructors
     */
    @Test
    public void constructors_shouldWork() {
        Query query = new Query();

        assertThat(query).isNotNull();
        assertThat(query.getTraversals()).isNotNull();
        assertThat(query.getTraversals().size()).isEqualTo(0);

        HashMap<String, Traversal> traversals = new HashMap<>();
        Traversal traversal = new Traversal(new ArrayList<Step>());
        traversals.put(traversal.getId(), traversal);

        query = new Query(traversals);

        assertThat(query).isNotNull();
        assertThat(query.getTraversals()).isEqualTo(traversals);
    }

    /**
     * Getters & Setters
     */
    @Test
    public void getters_and_setters_shouldWork() {
        HashMap<String, Traversal> traversals = new HashMap<>();
        Traversal traversal = new Traversal(new ArrayList<Step>());
        traversals.put(traversal.getId(), traversal);

        Query query = new Query(traversals);

        assertThat(query.getTraversals()).isEqualTo(traversals);
    }

    /**
     * Add Traversal
     */
    @Test
    public void addTraversal_shouldWork() {
        Query query = new Query();

        assertThat(query.getTraversals().size()).isEqualTo(0);

        Traversal traversal = new Traversal(new ArrayList<Step>());

        query.addTraversal(traversal);
        assertThat(query.getTraversals().size()).isEqualTo(1);
        assertThat(query.getTraversals().get(traversal.getId())).isEqualTo(traversal);
    }

    /**
     * Execute
     */
    @Test
    public void execute_basicTraversalshouldWork() {
        Node start = graph.addNode("label");
        Node branch = graph.addNode("label");
        Node leaf1 = graph.addNode("label");
        Node leaf2 = graph.addNode("label");
        Node leaf3 = graph.addNode("label");

        graph.addEdge(start, branch, "label");
        graph.addEdge(branch, leaf1, "label");
        graph.addEdge(branch, leaf2, "label");
        graph.addEdge(branch, leaf3, "label");

        leaf1.setProperty("type", "leaf1");
        leaf2.setProperty("type", "leaf2");
        leaf3.setProperty("type", "leaf3");

        steps.add(new NodeStep(start.getId()));
        steps.add(new OutStep());
        steps.add(new OutStep());
        steps.add(new StoreStep("type", "payloadKey"));

        Traversal traversal = new Traversal(steps);

        Query query = new Query();
        query.addTraversal(traversal);

        query.execute(graph);

        assertThat(query.getTraversals().size()).isEqualTo(3);

        for(Traversal executedTraversal: query.getTraversals().values()) {
            assertThat(executedTraversal.getStatus()).isEqualTo(Status.FINISHED);
            assertThat(executedTraversal.getPayload().get("payloadKey")).isIn("leaf1", "leaf2", "leaf3");
        }
    }

    /**
     * validate
     */
    @Test
    public void validate_shouldErrorOnBadTraversal() {
        Traversal traversal = new Traversal(new ArrayList<Step>());
        traversal.setStep(-1);

        Query query = new Query();
        query.addTraversal(traversal);

        try {
            query.validate();
            fail("Should have thrown error");
        } catch (NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid traversal " + traversal.getId() + ": invalid step");
        }
    }

    @Test
    public void validate_shouldWork() {
        Query query = new Query();
        query.addTraversal(new Traversal(new ArrayList<Step>()));
        query.addTraversal(new Traversal(new ArrayList<Step>()));
        query.addTraversal(new Traversal(new ArrayList<Step>()));

        query.validate();
    }
}

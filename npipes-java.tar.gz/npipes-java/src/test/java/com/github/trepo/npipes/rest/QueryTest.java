package com.github.trepo.npipes.rest;

import com.github.trepo.npipes.Status;
import com.github.trepo.npipes.Step;
import com.github.trepo.npipes.Traversal;
import com.github.trepo.npipes.gson.StepTypeAdapter;
import com.github.trepo.npipes.step.InStep;
import com.github.trepo.npipes.step.NodeStep;
import com.github.trepo.npipes.step.StoreStep;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import javax.ws.rs.WebApplicationException;
import java.util.ArrayList;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Fail.fail;

/**
 * @author John Clark.
 */
public class QueryTest {

    private static Gson gson = new GsonBuilder()
                        .registerTypeHierarchyAdapter(Step.class, new StepTypeAdapter())
                        .create();

    private TinkerGraph tinkerGraph;
    private VGraph graph;
    private ArrayList<Step> steps;

    @BeforeMethod
    public void setup() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, "repo");
        steps = new ArrayList<>();
    }

    /**
     * post
     */
    @Test
    public void post_shouldErrorOnValidation() {
        Traversal traversal = new Traversal(new ArrayList<Step>());
        traversal.setStep(-1);

        com.github.trepo.npipes.Query nPipesQuery = new com.github.trepo.npipes.Query();
        nPipesQuery.addTraversal(traversal);

        Query query = new Query();
        query.setGraph(graph);

        try {
            query.post(nPipesQuery);
            fail("Should have thrown an error");
        } catch (WebApplicationException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid request: invalid traversal " + traversal.getId() + ": invalid step");
        }
    }

    @Test
    public void post_shouldWorkExecution() {
        Node node = graph.addNode("label");
        node.setProperty("working", true);
        ArrayList<Step> steps = new ArrayList<>();
        steps.add(new NodeStep(node.getId()));
        steps.add(new StoreStep("working", "key"));
        Traversal traversal = new Traversal(steps);

        com.github.trepo.npipes.Query nPipesQuery = new com.github.trepo.npipes.Query();
        nPipesQuery.addTraversal(traversal);

        Query query = new Query();
        query.setGraph(graph);

        query.post(nPipesQuery);

        assertThat(traversal.getStatus()).isEqualTo(Status.FINISHED);
        assertThat(traversal.getPayload().get("key")).isEqualTo(true);
    }
}

package com.github.trepo.npipes;

import com.github.trepo.vgraph.SpecialProperty;
import org.testng.annotations.Test;

import java.util.HashSet;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.testng.Assert.fail;

/**
 * @author John Clark.
 */
public class PathElementTest {

    /**
     * constructor
     */
    @Test
    public void constructors_shouldWork() {
        PathElement pathElement = new PathElement();

        assertThat(pathElement.getId()).isNull();
        assertThat(pathElement.getType()).isNull();
        assertThat(pathElement.getRepo()).isNull();
        assertThat(pathElement.getMarkers()).isNull();

        pathElement = new PathElement("id", PathElementType.EDGE, "repo1");

        assertThat(pathElement.getId()).isEqualTo("id");
        assertThat(pathElement.getType()).isEqualTo(PathElementType.EDGE);
        assertThat(pathElement.getRepo()).isEqualTo("repo1");
        assertThat(pathElement.getMarkers().size()).isEqualTo(0);

        HashSet<String> markers = new HashSet<>();
        markers.add("marker");
        pathElement = new PathElement("id", PathElementType.EDGE, "repo1", markers);

        assertThat(pathElement.getId()).isEqualTo("id");
        assertThat(pathElement.getType()).isEqualTo(PathElementType.EDGE);
        assertThat(pathElement.getRepo()).isEqualTo("repo1");
        assertThat(pathElement.getMarkers().size()).isEqualTo(1);
        assertThat(pathElement.getMarkers().contains("marker")).isTrue();
    }

    /**
     * Getters & Setters
     */
    @Test
    public void getters_setters_shouldWork() {
        PathElement pathElement = new PathElement();

        assertThat(pathElement.getId()).isNull();
        assertThat(pathElement.getType()).isNull();
        assertThat(pathElement.getRepo()).isNull();
        assertThat(pathElement.getMarkers()).isNull();

        pathElement.setId("id");
        pathElement.setType(PathElementType.EDGE);
        pathElement.setRepo("repo1");
        HashSet<String> markers = new HashSet<>();
        markers.add("marker1");
        markers.add("marker2");
        pathElement.setMarkers(markers);

        assertThat(pathElement.getId()).isEqualTo("id");
        assertThat(pathElement.getType()).isEqualTo(PathElementType.EDGE);
        assertThat(pathElement.getRepo()).isEqualTo("repo1");
        assertThat(pathElement.getMarkers()).isEqualTo(markers);
    }

    /**
     * hasMarker
     */
    @Test
    public void hasMarker_shouldWork() {
        PathElement pathElement = new PathElement();

        HashSet<String> markers = new HashSet<>();
        markers.add("marker1");
        markers.add("marker2");
        pathElement.setMarkers(markers);

        assertThat(pathElement.hasMarker("marker1")).isTrue();
        assertThat(pathElement.hasMarker("marker2")).isTrue();
        assertThat(pathElement.hasMarker("marker3")).isFalse();
    }

    /**
     * addMarker
     */
    @Test
    public void addMarker_shouldWork() {
        PathElement pathElement = new PathElement();

        HashSet<String> markers = new HashSet<>();
        pathElement.setMarkers(markers);

        assertThat(pathElement.hasMarker("marker")).isFalse();

        pathElement.addMarker("marker");

        assertThat(pathElement.hasMarker("marker")).isTrue();
    }

    /**
     * validate
     */
    @Test
    public void validate_shouldErrorOnInvalidId() {
        PathElement pathElement = new PathElement();
        pathElement.setId(null);
        pathElement.setType(PathElementType.NODE);
        pathElement.setRepo("1234");
        pathElement.setMarkers(new HashSet<String>());

        try {
            pathElement.validate();
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid id");
        }

        pathElement.setId("1234");

        try {
            pathElement.validate();
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid id");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidType() {
        PathElement pathElement = new PathElement();
        pathElement.setId(SpecialProperty.generateId());
        pathElement.setType(null);
        pathElement.setRepo("1234");
        pathElement.setMarkers(new HashSet<String>());

        try {
            pathElement.validate();
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid type");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidRepo() {
        PathElement pathElement = new PathElement();
        pathElement.setId(SpecialProperty.generateId());
        pathElement.setType(PathElementType.NODE);
        pathElement.setRepo(null);
        pathElement.setMarkers(new HashSet<String>());

        try {
            pathElement.validate();
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid repo");
        }
    }

    @Test
    public void validate_shouldErrorOnInvalidMarkers() {
        PathElement pathElement = new PathElement();
        pathElement.setId(SpecialProperty.generateId());
        pathElement.setType(PathElementType.NODE);
        pathElement.setRepo("1234");
        pathElement.setMarkers(null);

        try {
            pathElement.validate();
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("invalid markers");
        }
    }

    @Test
    public void validate_shouldWork() {
        PathElement pathElement = new PathElement();
        pathElement.setId(SpecialProperty.generateId());
        pathElement.setType(PathElementType.NODE);
        pathElement.setRepo("1234");
        pathElement.setMarkers(new HashSet<String>());

        pathElement.validate();
    }

    /**
     * Serialization/Deserialization
     */
    // TODO
}

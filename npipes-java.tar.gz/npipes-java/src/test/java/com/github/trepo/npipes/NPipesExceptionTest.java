package com.github.trepo.npipes;

import org.testng.annotations.Test;

import static org.fest.assertions.api.Assertions.assertThat;

/**
 * @author John Clark.
 */
public class NPipesExceptionTest {
    /**
     * constructor(message)
     */
    @Test
    public void constructor_message_shouldWork() {
        NPipesException e = new NPipesException("TESTING...");
        assertThat(e.getMessage()).isEqualTo("TESTING...");
    }

    /**
     * constructor(message, exception)
     */
    @Test
    public void constructor_message_exception_shouldWork() {
        Exception newE = new Exception("underlying-exception");
        NPipesException e = new NPipesException("main-exception", newE);

        assertThat(e.getMessage()).isEqualTo("main-exception");
        assertThat(e.getCause().getMessage()).isEqualTo("underlying-exception");
    }
}

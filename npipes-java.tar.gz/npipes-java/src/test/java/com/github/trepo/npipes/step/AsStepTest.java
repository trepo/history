package com.github.trepo.npipes.step;

import com.github.trepo.npipes.*;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class AsStepTest {
    private String repo = "repo";
    private VGraph graph;
    private Traversal traversal;

    @BeforeMethod
    public void setup() {
        graph = new BlueprintsVGraph(new TinkerGraph(), repo);
        traversal = new Traversal(new ArrayList<Step>());
    }

    /**
     * constructor
     */
    @Test
    public void constructor_shouldWork() {
        Map<String, Object> parameters = null;


        try {
            new AsStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for as step");
        }

        parameters = new HashMap<>();
        try {
            new AsStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for as step");
        }

        parameters.put("marker", new ArrayList<String>());
        try {
            new AsStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("as step requires a marker value");
        }

        parameters.put("marker", "the marker");

        AsStep step = new AsStep(parameters);

        assertThat(step.getMarker()).isEqualTo("the marker");
    }

    /**
     * getters
     */
    @Test
    public void getters_shouldWork() {
        AsStep step = new AsStep("marker");

        assertThat(step.getMarker()).isEqualTo("marker");
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldSetStateOnEmptyPath() {

        AsStep step = new AsStep("marker");

        step.execute(traversal, graph);

        assertThat(traversal.getStatus()).isEqualTo(Status.INVALID_STATE);
    }

    @Test
    public void execute_shouldWork() {
        traversal.addToPath("1234", PathElementType.EDGE, repo);
        AsStep step = new AsStep("marker");

        step.execute(traversal, graph);

        PathElement pathElement = traversal.getPath().get(0);

        assertThat(pathElement.hasMarker("marker")).isTrue();
    }

    /**
     * toSerializableStep
     */
    @Test
    public void toSerializableStep_shouldWork() {
        AsStep step = new AsStep("the marker");

        SerializableStep serializableStep = step.toSerializableStep();

        assertThat(serializableStep.getName()).isEqualTo("as");

        Map<String, Object> map = serializableStep.getParameters();

        assertThat(map.size()).isEqualTo(1);
        assertThat(map.get("marker")).isEqualTo("the marker");

    }
}

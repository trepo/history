package com.github.trepo.npipes.step;

import com.github.trepo.npipes.*;
import com.github.trepo.npipes.gson.SerializableStep;
import com.github.trepo.vgraph.Node;
import com.github.trepo.vgraph.SpecialProperty;
import com.github.trepo.vgraph.VGraph;
import com.github.trepo.vgraph.blueprints.BlueprintsVGraph;
import com.tinkerpop.blueprints.Vertex;
import com.tinkerpop.blueprints.impls.tg.TinkerGraph;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import static org.fest.assertions.api.Assertions.assertThat;
import static org.fest.assertions.api.Assertions.fail;

/**
 * @author John Clark.
 */
public class NodeStepTest {

    private String repo = "repo";
    private TinkerGraph tinkerGraph;
    private VGraph graph;
    private Traversal traversal;

    @BeforeMethod
    public void setup() {
        tinkerGraph = new TinkerGraph();
        graph = new BlueprintsVGraph(tinkerGraph, repo);
        traversal = new Traversal(new ArrayList<Step>());
    }

    /**
     * constructor
     */
    @Test
    public void constructor_shouldWork() {
        Map<String, Object> parameters = null;


        try {
            new NodeStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for vertex step");
        }

        parameters = new HashMap<>();
        try {
            new NodeStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("Invalid parameters for vertex step");
        }

        parameters.put("id", new ArrayList<String>());
        try {
            new NodeStep(parameters);
            fail("Should have thrown error");
        } catch(NPipesException e) {
            assertThat(e.getMessage()).isEqualTo("vertex step requires an id value");
        }

        parameters.put("id", "1234");

        NodeStep step = new NodeStep(parameters);

        assertThat(step.getId()).isEqualTo("1234");
    }

    /**
     * getters
     */
    @Test
    public void getters_shouldWork() {
        NodeStep step = new NodeStep("1234");

        assertThat(step.getId()).isEqualTo("1234");
    }

    /**
     * execute
     */
    @Test
    public void execute_shouldSetStatusOnMissingNode() {
        Step step = new NodeStep("1234");

        step.execute(traversal, graph);

        assertThat(traversal.getStatus()).isEqualTo(Status.MISSING_ELEMENT);

    }

    @Test
    public void execute_shouldSetStatusOnBoundaryNode() {
        String id = SpecialProperty.generateId();
        Vertex v = tinkerGraph.addVertex(id);
        v.setProperty(SpecialProperty.ID, id);
        v.setProperty(SpecialProperty.LABEL, "label");
        v.setProperty(SpecialProperty.REPO, "externalRepo2");
        Node node = graph.getNode(id);

        Step step = new NodeStep(id);

        step.execute(traversal, graph);

        assertThat(traversal.getStatus()).isEqualTo(Status.BOUNDARY);

        assertThat(traversal.getPath().size()).isEqualTo(1);

        PathElement pathElement = traversal.getPath().get(0);

        assertThat(pathElement.getId()).isEqualTo(id);
        assertThat(pathElement.getType()).isEqualTo(PathElementType.BOUNDARY);
        assertThat(pathElement.getRepo()).isEqualTo("externalRepo2");
    }

    @Test
    public void execute_shouldWork() {
        Node node = graph.addNode("label");
        Step step = new NodeStep(node.getId());

        assertThat(traversal.getCurrentElement()).isNull();
        assertThat(traversal.getPath().size()).isEqualTo(0);

        step.execute(traversal, graph);

        assertThat(traversal.getCurrentElement()).isEqualTo(node);
        assertThat(traversal.getPath().size()).isEqualTo(1);

        PathElement pathElement = traversal.getPath().get(0);

        assertThat(pathElement.getId()).isEqualTo(node.getId());
        assertThat(pathElement.getType()).isEqualTo(PathElementType.NODE);
        assertThat(pathElement.getRepo()).isEqualTo(repo);
    }

    /**
     * toSerializableStep
     */
    @Test
    public void toSerializableStep_shouldWork() {
        NodeStep step = new NodeStep("1234");

        SerializableStep serializableStep = step.toSerializableStep();

        assertThat(serializableStep.getName()).isEqualTo("n");

        Map<String, Object> map = serializableStep.getParameters();

        assertThat(map.size()).isEqualTo(1);
        assertThat(map.get("id")).isEqualTo("1234");

    }
}
